"""NumPy batch evaluation of equal-length TLS-Huber support windows.

No model or threshold approximation is used: covariance, eigendecomposition,
MAD scales and Huber weights are evaluated along an extra batch dimension.
The caller retains scan order and all acceptance/merging decisions.
"""

from __future__ import annotations

import numpy as np

EPS = 1e-12


def tls_batch(points, weights=None):
    """Vectorized equivalent of feature.fit_line_tls_core for float64 windows."""
    if weights is None:
        weights = np.ones(points.shape[:2], dtype=np.float64)
    denom = np.maximum(np.sum(weights, axis=1), EPS)
    mu = np.sum(points * weights[..., None], axis=1) / denom[:, None]
    q = points - mu[:, None, :]
    cov = np.swapaxes(q * weights[..., None], 1, 2) @ q / denom[:, None, None]
    eigvals, eigvecs = np.linalg.eigh(cov)
    idx = np.argmax(eigvals, axis=1)
    direction = eigvecs[np.arange(len(points)), :, idx].copy()
    direction /= (np.linalg.norm(direction, axis=1) + EPS)[:, None]
    flip = (direction[:, 0] < 0.0) | ((np.abs(direction[:, 0]) < EPS) & (direction[:, 1] < 0.0))
    direction[flip] *= -1.0
    normal = np.column_stack((-direction[:, 1], direction[:, 0]))
    residual = (q @ normal[..., None])[..., 0]
    return mu, direction, residual, eigvals


def fit_windows(points, cfg, angle_increment, huber_iters, sensor_sigma):
    """Return (mu, direction, RMS, MaxRes, straightness) for each window."""
    ranges = np.linalg.norm(points, axis=2)
    r_med = np.median(ranges, axis=1)
    radial_steps = np.abs(np.diff(ranges, axis=1))
    radial_mad = 1.4826 * np.median(
        np.abs(radial_steps - np.median(radial_steps, axis=1)[:, None]), axis=1,
    )
    # Use the existing scalar sensor model so its rounding stays unchanged.
    sensor_scales = np.array([sensor_sigma(float(r), angle_increment, cfg) for r in r_med])
    mu, direction, residual, eigvals = tls_batch(points)
    residual_mad = 1.4826 * np.median(
        np.abs(residual - np.median(residual, axis=1)[:, None]), axis=1,
    )
    sigma = np.maximum.reduce([
        sensor_scales, radial_mad / np.sqrt(2.0), residual_mad,
        np.full(len(points), float(cfg.huber_min_scale_m)),
    ])
    weights = np.ones(points.shape[:2], dtype=np.float64)
    active = np.arange(len(points))
    for _ in range(max(1, int(huber_iters))):
        active_residual = residual[active]
        sigma_res = 1.4826 * np.median(
            np.abs(active_residual - np.median(active_residual, axis=1)[:, None]), axis=1,
        )
        delta = np.maximum(float(cfg.huber_min_delta_m), float(cfg.huber_sigma_gain) * np.maximum(sigma[active], sigma_res))
        abs_res = np.abs(active_residual)
        next_weights = np.where(abs_res <= delta[:, None], 1.0, delta[:, None] / (abs_res + EPS))
        changed = np.any(next_weights != weights, axis=1)
        if not np.any(changed):
            break
        active = active[changed]
        weights = next_weights[changed]
        update = tls_batch(points[active], weights)
        mu[active], direction[active], residual[active], eigvals[active] = update
    rms = np.sqrt(np.mean(residual ** 2, axis=1))
    max_res = np.max(np.abs(residual), axis=1)
    lam1 = np.maximum(eigvals[:, 1], 0.0)
    lam2 = np.maximum(eigvals[:, 0], 0.0)
    straightness = 1.0 - lam2 / (lam1 + lam2 + EPS)
    return mu, direction, rms, max_res, straightness
