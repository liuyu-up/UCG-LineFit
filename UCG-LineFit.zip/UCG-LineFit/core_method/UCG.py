#!/usr/bin/env python3
"""Uncertainty-aware and graph-optimized LiDAR line extraction.

This module is an extension layer over ``feature.py``.  It keeps the original
JSON input, ``Segment`` output, plotting and command-line interface, while
replacing three heuristic parts of the original pipeline:

1. point-gap and merge thresholds are derived from a calibrated sensor-noise
   model and a Gaussian confidence quantile;
2. the Huber transition point is coupled to a local robust noise estimate;
3. fragmented line candidates are connected with a minimum-cost path forest
   instead of relying only on hand-written fragment-chain rules.

The implementation intentionally reuses the well-tested geometric routines in
``feature.py``.  The module can therefore be used as a drop-in replacement:

    python feature_tour.py --input map_points.json --output-png tour.png

The sensor parameters are conservative defaults for a metre-scale 2-D LiDAR;
they should be calibrated from a static-wall sequence for a final experiment.
"""

from __future__ import annotations

import argparse
import math
from contextlib import contextmanager
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path
from statistics import NormalDist
from time import perf_counter
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

import feature as base
from feature_tour_batch import fit_windows, tls_batch
import feature_tour_native as native


EPS = 1e-12

# Keep references to the original functions before monkey-patching the base
# module.  The base implementation uses module globals internally, so a small
# scoped patch lets all of its candidate-growth routines use the new models.
_ORIGINAL_GAP_THR = base.gap_thr_m
_ORIGINAL_MEAN_GAP_THR = base.mean_gap_thr_m
_ORIGINAL_MERGE_GAP_THR = base.merge_gap_thr_m
_ORIGINAL_MERGE_PERP_THR = base.merge_perp_thr_m
_ORIGINAL_FIT = base.fit_line_tls_huber
_ORIGINAL_TLS_CORE = base.fit_line_tls_core
_ORIGINAL_BUILD_SEGMENT = base.build_segment_from_points
_ORIGINAL_EXTRACT = base.extract_segments
_ORIGINAL_EXTEND_SEGMENT = base.extend_segment_in_run
_ORIGINAL_CANDIDATES_RUN = base.extract_candidates_from_run
_ORIGINAL_PREPROCESS = base.preprocess_points
_ORIGINAL_LOCAL_MERGE = base.try_merge_two_segments

_ACTIVE_ARGS: Optional[argparse.Namespace] = None
_ACTIVE_ANGLE_INCREMENT: Optional[float] = None
_LAST_DIAGNOSTICS: Dict[str, float] = {}
_FALLBACK_ARGS: Optional[argparse.Namespace] = None
_FIT_CACHE: Optional[dict] = None
_NOISE_CACHE: Optional[dict] = None
_SEGMENT_CACHE: Optional[dict] = None
_FIT_CACHE_LIMIT = 8192
_MEASUREMENT_POINTS = None
_MEASUREMENT_LOOKUP = None
_MEASUREMENT_SUPPORT = None


def _support_key(segment):
    return (segment.idx_start, segment.idx_end, segment.p1.tobytes(), segment.p2.tobytes())


def _record_support(segment, points):
    if _MEASUREMENT_SUPPORT is not None:
        indices = set()
        for point in points:
            indices.update(_MEASUREMENT_LOOKUP.get(tuple(point), ()))
        _MEASUREMENT_SUPPORT[_support_key(segment)] = tuple(sorted(indices))
    return segment


def _support_indices(segment):
    if _MEASUREMENT_SUPPORT is None:
        return ()
    found = _MEASUREMENT_SUPPORT.get(_support_key(segment))
    if found is not None:
        return found
    # Compiled corner branches expose an original contiguous measurement span.
    if 0 <= segment.idx_start <= segment.idx_end < len(_MEASUREMENT_POINTS):
        return tuple(range(segment.idx_start, segment.idx_end+1))
    return ()


def _supported_merge_geometry(a, b, args, angle_limit):
    """Do not let sparsity relax direction or turn an empty gap into evidence."""
    if base.segment_included_angle_deg(a, b) > angle_limit:
        return False
    direction = base.seg_dir(a)
    normal = np.array([-direction[1], direction[0]])
    other_normal = np.array([-base.seg_dir(b)[1], base.seg_dir(b)[0]])
    perp = max(abs(float((p-a.p1) @ normal)) for p in (b.p1, b.p2))
    perp = max(perp, *(abs(float((p-b.p1) @ other_normal)) for p in (a.p1, a.p2)))
    radius = .5 * (np.linalg.norm(base.segment_midpoint(a)) + np.linalg.norm(base.segment_midpoint(b)))
    scale = adaptive_merge_scale_from_segments(a, b, _active_angle(), None, args)
    band = uncertainty_merge_perp_thr_m(radius, args.merge_perp_base_m, args.merge_perp_cr)
    if perp > min(args.global_map_merge_perp_m, band * math.sqrt(scale)):
        return False
    ta = sorted(float(p @ direction) for p in (a.p1, a.p2))
    tb = sorted(float(p @ direction) for p in (b.p1, b.p2))
    gap = max(0.0, max(ta[0], tb[0])-min(ta[1], tb[1]))
    limit = max(uncertainty_gap_thr_m(radius, _active_angle(), args.gap0_m, args.cgap),
                getattr(args, 'merge_gap_length_ratio', .75) * min(a.length, b.length))
    return gap <= limit


def _refit_parent_measurements(a, b, args):
    ids = sorted(set(_support_indices(a)) | set(_support_indices(b)))
    if not ids or not _support_indices(a) or not _support_indices(b):
        return None
    return base.build_segment_from_points(
        _MEASUREMENT_POINTS[ids], min(ids), max(ids), args.huber_delta, args.huber_iters, args=args)


def _try_local_merge(a, b, points, angle, args):
    if not _supported_merge_geometry(a, b, args, args.merge_angle_deg):
        return None
    proposal = _ORIGINAL_LOCAL_MERGE(a, b, points, angle, args)
    if proposal is None:
        return None
    refit = _refit_parent_measurements(a, b, args)
    if refit is not None:
        refit.is_feature, refit.is_fragment = proposal.is_feature, proposal.is_fragment
        refit.merged_from = proposal.merged_from
        proposal = refit
    return proposal


def _fit_line_tls_core(points, weights=None):
    """Same TLS arithmetic, avoiding all-one arrays and reduction dispatch."""
    if (not len(points) or points.dtype != np.float64
            or not points.flags.c_contiguous):
        return _ORIGINAL_TLS_CORE(points, weights)
    if weights is None:
        denom = float(len(points))
        mu = points.sum(axis=0) / denom
        q = points - mu
        cov = q.T @ q / denom
    else:
        denom = max(float(weights.sum()), EPS)
        mu = (points * weights[:, None]).sum(axis=0) / denom
        q = points - mu
        cov = (q * weights[:, None]).T @ q / denom
    eigvals, eigvecs = np.linalg.eigh(cov)
    direction = base.normalize(eigvecs[:, int(np.argmax(eigvals))])
    if direction[0] < 0.0 or (abs(direction[0]) < EPS and direction[1] < 0.0):
        direction = -direction
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    return mu, direction, q @ normal, eigvals


def _median_1d(values: np.ndarray) -> float:
    """Small 1-D median without NumPy's general axis-dispatch overhead."""
    values = np.asarray(values)
    if values.dtype != np.float64 or values.ndim != 1:
        return float(np.median(values))
    size = len(values)
    if not size:
        return float("nan")
    middle = size // 2
    kth = (middle, -1) if size % 2 else (middle - 1, middle, -1)
    ordered = np.partition(values, kth)
    if np.isnan(ordered[-1]):
        return float("nan")
    if size % 2:
        return float(ordered[middle])
    return float((ordered[middle - 1] + ordered[middle]) / 2.0)


@dataclass(frozen=True)
class FragmentEdge:
    """A candidate connection in the fragment graph."""

    i: int
    j: int
    cost: float
    angle_deg: float
    endpoint_gap_m: float
    axis_gap_m: float
    perp_sigma_m: float


def segment_mean_spacing_m(seg: base.Segment) -> float:
    """Average scan spacing along a segment support."""

    if seg.n_points <= 1:
        return float(max(seg.length, 0.0))
    return float(seg.length / max(seg.n_points - 1, 1))


def adaptive_merge_scale_from_segments(
    seg1: base.Segment,
    seg2: base.Segment,
    angle_increment: float,
    endpoint_gap_m: Optional[float] = None,
    args: Optional[argparse.Namespace] = None,
) -> float:
    """Widen merge thresholds when scan points are sparse."""

    cfg = _active_args(args)
    if not getattr(cfg, "adaptive_merge_enable", True):
        return 1.0

    da = _active_angle(angle_increment)
    r = 0.5 * (
        np.linalg.norm(base.segment_midpoint(seg1))
        + np.linalg.norm(base.segment_midpoint(seg2))
    )
    expected_step = max(2.0 * max(r, 0.05) * math.sin(0.5 * max(da, 1e-9)), 1e-6)
    spacing = 0.5 * (segment_mean_spacing_m(seg1) + segment_mean_spacing_m(seg2))
    sparsity = spacing / expected_step
    excess = max(0.0, sparsity - 1.0)

    gap_excess = 0.0
    if endpoint_gap_m is not None:
        gap_excess = max(0.0, float(endpoint_gap_m) / expected_step - 1.0)

    scale = 1.0
    scale += float(cfg.adaptive_merge_sparsity_gain) * (
        excess ** float(cfg.adaptive_merge_sparsity_power)
    )
    scale += 1.0 * float(cfg.adaptive_merge_sparsity_gain) * (gap_excess ** 1.0)
    return float(np.clip(scale, 1.0, float(cfg.adaptive_merge_scale_max)))


def _active_args(args: Optional[argparse.Namespace] = None) -> argparse.Namespace:
    global _FALLBACK_ARGS
    if args is not None:
        return args
    if _ACTIVE_ARGS is not None:
        return _ACTIVE_ARGS
    # The layout recovery pass also calls the patched functions outside the
    # per-frame extraction context. Construct its unchanged defaults only once
    # per request, rather than rebuilding a parser for every support window.
    if _FIT_CACHE is not None:
        if _FALLBACK_ARGS is None:
            _FALLBACK_ARGS = build_parser().parse_args([])
        return _FALLBACK_ARGS
    return build_parser().parse_args([])


def _active_angle(angle_increment: Optional[float] = None) -> float:
    if angle_increment is not None and angle_increment > 0.0:
        return float(angle_increment)
    if _ACTIVE_ANGLE_INCREMENT is not None and _ACTIVE_ANGLE_INCREMENT > 0.0:
        return float(_ACTIVE_ANGLE_INCREMENT)
    return math.radians(0.5)


@lru_cache(maxsize=32)
def _normal_quantile(confidence: float) -> float:
    """Return a two-sided Gaussian quantile without requiring SciPy."""

    c = float(np.clip(confidence, 0.500001, 0.999999))
    # A two-sided confidence interval has tail probability (1-c)/2.
    return float(NormalDist().inv_cdf(0.5 + 0.5 * c))


def sensor_point_sigma_m(
    r: float,
    angle_increment: float,
    args: Optional[argparse.Namespace] = None,
) -> float:
    """Model one Cartesian point's uncertainty in metres.

    The radial component follows ``sigma_r0 + sigma_r_slope*r``.  The angular
    component includes both beam quantisation and a sensor angular error.  The
    two components are combined conservatively by root-sum-square.
    """

    cfg = _active_args(args)
    rr = max(float(r), 0.05)
    sigma_r = max(float(cfg.sensor_range_noise_m), 1e-7) + max(
        float(cfg.sensor_range_noise_slope), 0.0
    ) * rr
    angular_sigma = math.sqrt(
        (max(float(angle_increment), 1e-9) / math.sqrt(12.0)) ** 2
        + max(float(cfg.sensor_angle_noise_rad), 0.0) ** 2
    )
    sigma_t = rr * angular_sigma
    return float(math.hypot(sigma_r, sigma_t))


def _uncertainty_gap_core(
    r: float,
    angle_increment: float,
    args: argparse.Namespace,
    scale: float,
) -> float:
    rr = max(float(r), 0.05)
    da = max(float(angle_increment), 1e-9)
    expected_step = 2.0 * rr * math.sin(0.5 * da)
    sigma = sensor_point_sigma_m(rr, da, args)
    # Difference of two independent point errors has sqrt(2) larger sigma.
    q = _normal_quantile(args.threshold_confidence)
    threshold = float(args.uncertainty_base_m) + scale * (
        expected_step + q * math.sqrt(2.0) * sigma
    )
    floor = max(float(args.uncertainty_floor_m), 0.5 * float(args.gap0_m))
    ceiling = max(float(args.uncertainty_cap_m), floor)
    return float(np.clip(threshold, floor, ceiling))


def uncertainty_gap_thr_m(
    r: float,
    angle_increment: float,
    gap0_m: float,
    cgap: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_GAP_THR(r, angle_increment, gap0_m, cgap)
    return _uncertainty_gap_core(r, angle_increment, cfg, cfg.uncertainty_gap_scale)


def uncertainty_mean_gap_thr_m(
    r: float,
    angle_increment: float,
    gap0_m: float,
    cmean: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_MEAN_GAP_THR(r, angle_increment, gap0_m, cmean)
    return _uncertainty_gap_core(r, angle_increment, cfg, cfg.uncertainty_mean_scale)


def uncertainty_merge_gap_thr_m(
    r: float,
    angle_increment: float,
    merge_gap0_m: float,
    merge_cgap: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_MERGE_GAP_THR(r, angle_increment, merge_gap0_m, merge_cgap)
    return _uncertainty_gap_core(r, angle_increment, cfg, cfg.uncertainty_merge_scale)


def uncertainty_merge_perp_thr_m(
    r: float,
    merge_perp_base_m: float,
    merge_perp_cr: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_MERGE_PERP_THR(r, merge_perp_base_m, merge_perp_cr)
    sigma = sensor_point_sigma_m(r, _active_angle(), cfg)
    q = _normal_quantile(cfg.threshold_confidence)
    floor = max(float(cfg.uncertainty_perp_floor_m), 0.5 * float(merge_perp_base_m))
    ceiling = max(float(cfg.uncertainty_perp_cap_m), floor)
    return float(np.clip(cfg.uncertainty_perp_scale * q * sigma, floor, ceiling))


def estimate_local_noise_sigma_m(
    points: np.ndarray,
    angle_increment: Optional[float] = None,
    args: Optional[argparse.Namespace] = None,
) -> float:
    """Estimate local Cartesian noise from residual and radial-step MAD."""

    return _local_noise_and_tls(points, angle_increment, args)[0]


def _local_noise_and_tls(
    points: np.ndarray,
    angle_increment: Optional[float] = None,
    args: Optional[argparse.Namespace] = None,
):
    """Return the noise scale and reusable all-one-weight provisional TLS."""

    cfg = _active_args(args)
    if len(points) < 3:
        return sensor_point_sigma_m(0.5, _active_angle(angle_increment), cfg), None

    da = _active_angle(angle_increment)
    key = None
    if _NOISE_CACHE is not None:
        key = (points.dtype.str, points.shape, points.strides, points.tobytes())
        cached = _NOISE_CACHE.get(key)
        if cached is not None:
            r_med, radial_mad, residual_mad, provisional = cached
            sensor_sigma = sensor_point_sigma_m(r_med, da, cfg)
            scale = max(sensor_sigma, radial_mad / math.sqrt(2.0), residual_mad, cfg.huber_min_scale_m)
            return float(scale), tuple(item.copy() for item in provisional) if provisional is not None else None
    ranges = np.linalg.norm(points, axis=1)
    r_med = _median_1d(ranges)
    radial_steps = np.abs(np.diff(ranges))
    radial_mad = 1.4826 * _median_1d(np.abs(radial_steps - _median_1d(radial_steps)))
    sensor_sigma = sensor_point_sigma_m(r_med, da, cfg)

    # A provisional TLS fit gives a second, geometry-aware scale estimate.
    provisional = None
    try:
        provisional = base.fit_line_tls_core(points)
        residual = provisional[2]
        residual_mad = 1.4826 * _median_1d(np.abs(residual - _median_1d(residual)))
    except (ValueError, FloatingPointError):
        residual_mad = 0.0

    if key is not None:
        if len(_NOISE_CACHE) >= _FIT_CACHE_LIMIT:
            _NOISE_CACHE.clear()
        _NOISE_CACHE[key] = (r_med, radial_mad, residual_mad,
                             tuple(item.copy() for item in provisional) if provisional is not None else None)
    return float(max(sensor_sigma, radial_mad / math.sqrt(2.0), residual_mad, cfg.huber_min_scale_m)), provisional


def _copy_line_fit(fit: base.LineFit) -> base.LineFit:
    # Cached arrays must never be exposed to a caller that may mutate them.
    return base.LineFit(fit.mu.copy(), fit.direction.copy(), fit.rms, fit.max_res, fit.straightness)


def _fit_key(points, huber_delta, huber_iters, cfg):
    return (
        points.dtype.str, points.shape, points.strides, points.tobytes(),
        huber_delta, huber_iters, _active_angle(),
        getattr(cfg, "adaptive_huber_enable", True),
        getattr(cfg, "native_enable", False),
        *(getattr(cfg, name, None) for name in (
            "sensor_range_noise_m", "sensor_range_noise_slope", "sensor_angle_noise_rad",
            "huber_min_scale_m", "huber_min_delta_m", "huber_sigma_gain",
        )),
    )


def _copy_segment(segment):
    return replace(segment, p1=segment.p1.copy(), p2=segment.p2.copy(),
                   merged_from=list(segment.merged_from))


def _base_median(values):
    if not len(values):
        return 0.0
    values = np.asarray(values, dtype=np.float64)
    if (values.ndim == 1 and values.flags.c_contiguous and values.flags.writeable
            and native._READY and native.AVAILABLE and getattr(_active_args(), "native_enable", False)):
        return float(native.median(values))
    return _median_1d(values)


def _base_mad(values):
    if not len(values):
        return 0.0
    values = np.asarray(values, dtype=np.float64)
    return _base_median(np.abs(values - _base_median(values)))


def _native_eligible(points, cfg):
    return (getattr(cfg, "native_enable", False) and native.AVAILABLE
            and points.dtype == np.float64 and points.flags.c_contiguous
            and points.flags.writeable
            and len(points) > 0 and np.isfinite(points).all()
            and np.max(np.abs(points)) < 1e6)


def _native_growth_configs(points, angle, args):
    cfg = _active_args()
    if (not _native_eligible(points, cfg) or not getattr(cfg, "adaptive_huber_enable", True)
            or args.huber_delta <= 0.0 or args.huber_iters <= 0):
        return None
    fc = native.FitConfig(_active_angle(), int(args.huber_iters), float(cfg.sensor_range_noise_m),
                          float(cfg.sensor_range_noise_slope), float(cfg.sensor_angle_noise_rad),
                          float(cfg.huber_min_scale_m), float(cfg.huber_min_delta_m), float(cfg.huber_sigma_gain))
    gc = native.GapConfig(bool(cfg.uncertainty_enable), float(cfg.sensor_range_noise_m),
                          float(cfg.sensor_range_noise_slope), float(cfg.sensor_angle_noise_rad),
                          _normal_quantile(cfg.threshold_confidence), float(cfg.uncertainty_base_m),
                          float(cfg.uncertainty_floor_m), float(cfg.uncertainty_cap_m),
                          float(cfg.uncertainty_gap_scale), float(cfg.uncertainty_mean_scale),
                          float(cfg.gap0_m), float(args.gap0_m), float(args.cgap), float(args.cmean))
    qc = native.GrowConfig(int(args.frag_min_pts if args.frag_enable else args.min_pts),
                           float(args.rms_a), float(args.rms_b), float(args.max_a), float(args.max_b),
                           float(args.straightness_min), float(args.grow_rms_relax),
                           float(args.grow_max_relax), float(args.grow_straightness_relax))
    return fc, gc, qc


def _extend_segment_in_run(points, start, end, angle, args):
    configs = _native_growth_configs(points, angle, args)
    if configs is None:
        return _ORIGINAL_EXTEND_SEGMENT(points, start, end, angle, args)
    return native.extend_segment(points, int(start), int(end), float(angle), *configs)


def _preprocess_points(points, angle, args):
    if not args.preclean_enable or len(points) < max(7, 2 * args.preclean_window + 3):
        return points
    configs = _native_growth_configs(points, angle, args)
    if configs is None or args.preclean_window < 1:
        return _ORIGINAL_PREPROCESS(points, angle, args)
    pc = native.PrecleanConfig(
        int(args.preclean_passes), int(args.preclean_window),
        float(args.preclean_run_gap_scale), float(args.preclean_isolated_gap_scale),
        float(args.preclean_gap_scale), float(args.preclean_residual_abs_m),
        float(args.preclean_residual_scale), float(args.preclean_radial_abs_m),
        float(args.preclean_radial_scale), int(args.preclean_small_run_max_pts),
        float(args.preclean_small_run_max_len_m), float(args.preclean_small_run_straightness),
    )
    return native.preprocess(points, float(angle), configs[1], pc)


def _extract_candidates_from_run(points, indices, angle, args):
    configs = _native_growth_configs(points, angle, args)
    if configs is None:
        return _ORIGINAL_CANDIDATES_RUN(points, indices, angle, args)
    # Candidate selection, branch searches and their lexicographic ordering
    # intentionally match feature.extract_candidates_from_run. Only the
    # numerical growth and branch-search loops cross into the compiled backend.
    ranges = np.linalg.norm(points, axis=1)
    cfg = _active_args()
    bc = native.BranchConfig(
        int(args.min_pts), int(args.frag_min_pts), float(args.frag_min_len_m),
        float(args.frag_straightness_min), float(args.straightness_min),
        float(args.rms_a), float(args.rms_b), float(args.merge_gap0_m),
        int(args.corner_branch_left_lookback_extra), float(args.merge_perp_base_m),
        float(args.merge_perp_cr), float(cfg.uncertainty_perp_floor_m),
        float(cfg.uncertainty_perp_cap_m), float(cfg.uncertainty_perp_scale),
    )
    grow_min_pts = args.frag_min_pts if args.frag_enable else args.min_pts
    # One bounded cache per immutable run/configuration; never reuse between
    # frames, callers or changed parameters. Collisions are checked in native.
    interval_cache = np.zeros((4096, 10), dtype=np.float64)
    candidates, start = [], 0
    while start < len(points) - 1:
        end = native.grow_window(points, ranges, start, float(angle), *configs, interval_cache)
        accepted = False
        if end - start + 1 >= grow_min_pts:
            ext_start, ext_end = native.extend_segment(points, start, end, float(angle), *configs, interval_cache)
            windows = [(ext_start, ext_end)]
            if (start, end) != (ext_start, ext_end):
                windows.append((start, end))
            best_seg, best_window, best_score = None, None, None
            for a, b in windows:
                segment = base.build_candidate_from_window(points, indices, ranges, a, b, angle, args)
                if segment is None:
                    continue
                score = (int(segment.is_feature), int(segment.is_fragment), segment.length,
                         segment.straightness, -segment.rms)
                if best_score is None or score > best_score:
                    best_seg, best_window, best_score = segment, (a, b), score
            if best_seg is not None:
                a, b = best_window
                candidates.append(best_seg)
                accepted = True
                direction = base.seg_dir(best_seg)
                branches = native.endpoint_branches(points, indices, a, b, direction, best_seg.p1, best_seg.p2, configs[0], bc, interval_cache)
                branches += native.corner_branches(points, indices, a, b, direction, configs[0], configs[1], bc, interval_cache)
                for branch in branches:
                    candidates.append(base.Segment(
                        idx_start=branch.start, idx_end=branch.end, p1=branch.p1, p2=branch.p2,
                        length=branch.length, rms=branch.rms, max_res=branch.max_res,
                        straightness=branch.straight, feature=float(branch.straight * np.exp(-branch.rms / 0.02)),
                        n_points=branch.count, is_fragment=True,
                    ))
        start = end + 1 if accepted else start + 1
    candidates.sort(key=lambda s: (s.idx_start, s.idx_end))
    return candidates


def _build_segment_from_points(seg_points, idx_start, idx_end, huber_delta, huber_iters, args=None):
    if _SEGMENT_CACHE is None:
        return _record_support(_ORIGINAL_BUILD_SEGMENT(seg_points, idx_start, idx_end, huber_delta, huber_iters, args), seg_points)
    key = (_fit_key(seg_points, huber_delta, huber_iters, _active_args()), idx_start, idx_end)
    cached = _SEGMENT_CACHE.get(key)
    if cached is not None:
        return _record_support(_copy_segment(cached), seg_points)
    segment = _ORIGINAL_BUILD_SEGMENT(seg_points, idx_start, idx_end, huber_delta, huber_iters, args)
    if len(_SEGMENT_CACHE) >= _FIT_CACHE_LIMIT:
        _SEGMENT_CACHE.clear()
    _SEGMENT_CACHE[key] = _copy_segment(segment)
    return _record_support(segment, seg_points)


def recover_noise_split_candidates(points, angle, args):
    """Recover measured line support lost by strict adjacent-return gap tests.

    Short ordered TLS-Huber seeds identify a perpendicular support band. Grow
    only connected projected support, splitting substantial empty intervals;
    later geometry checks decide whether separate pieces may be joined. No
    truth labels, scene coordinates, target counts or file access are used.
    """
    count = max(6, args.min_pts)
    proposals = {}
    for start in range(0, max(0, len(points)-count+1), max(1, count//2)):
        seed_ids = np.arange(start, start+count)
        seed = points[seed_ids]
        fit = fit_line_tls_huber_adaptive(seed, args.huber_delta, args.huber_iters)
        radius = float(np.median(np.linalg.norm(seed, axis=1)))
        if args.uncertainty_enable:
            band = max(args.huber_min_delta_m, _normal_quantile(args.threshold_confidence)
                       * sensor_point_sigma_m(radius, angle, args))
        else:
            band = _ORIGINAL_MERGE_PERP_THR(radius, args.merge_perp_base_m, args.merge_perp_cr)
        for _ in range(2):
            normal = np.array([-fit.direction[1], fit.direction[0]])
            near = np.abs((seed-fit.mu) @ normal) <= band
            if np.count_nonzero(near) < max(4, math.ceil(.6*count)):
                break
            fit = fit_line_tls_huber_adaptive(seed[near], args.huber_delta, args.huber_iters)
        else:
            normal = np.array([-fit.direction[1], fit.direction[0]])
            ids = np.flatnonzero(np.abs((points-fit.mu) @ normal) <= band)
            ordered = ids[np.argsort((points[ids]-fit.mu) @ fit.direction, kind="stable")]
            steps = np.diff((points[ordered]-fit.mu) @ fit.direction)
            positive = steps[steps > 1e-6]
            if not len(positive):
                continue
            gap_limit = max(uncertainty_gap_thr_m(radius, angle, args.gap0_m, args.cgap),
                            getattr(args, 'candidate_gap_spacing_factor', 2.0) * float(np.median(positive)))
            # A later point cluster can project into an earlier missing interval.
            # Preserve scan progression so such a return cannot fill a hole merely
            # because a global projection sort places it between two fragments.
            seed_steps = np.diff((seed[near]-fit.mu) @ fit.direction)
            forward = 1.0 if np.median(seed_steps) >= 0 else -1.0
            scan_steps = np.diff((points[ids]-fit.mu) @ fit.direction) * forward
            components = []
            for scan_run in np.split(ids, np.flatnonzero(scan_steps < -gap_limit)+1):
                ordered_run = scan_run[np.argsort((points[scan_run]-fit.mu) @ fit.direction, kind="stable")]
                run_steps = np.diff((points[ordered_run]-fit.mu) @ fit.direction)
                components.extend(np.split(ordered_run, np.flatnonzero(run_steps > gap_limit)+1))
            for part in components:
                if len(part) < count or len(np.intersect1d(part, seed_ids)) < 4:
                    continue
                part = np.sort(part)
                segment = base.build_segment_from_points(
                    points[part], int(part[0]), int(part[-1]), args.huber_delta, args.huber_iters, args=args)
                if (segment.length < args.frag_min_len_m or segment.rms > .6*band
                        or segment.max_res > 1.5*band):
                    continue
                segment.is_feature = (segment.length >= args.min_len_m
                                      or base.short_feature_candidate_ok(segment, radius, 0.0, args))
                segment.is_fragment = not segment.is_feature
                proposals[tuple(part)] = segment
    kept = []
    for indices, segment in sorted(proposals.items(), key=lambda item: (-len(item[0]), item[1].rms)):
        if any(len(set(indices) & set(old))/len(indices) > .8 for old, _ in kept):
            continue
        kept.append((indices, segment))
    _LAST_DIAGNOSTICS["noise_split_candidates"] = float(len(kept))
    return [segment for _, segment in kept]


def fit_line_tls_huber_adaptive(
    points: np.ndarray,
    huber_delta: float,
    huber_iters: int,
) -> base.LineFit:
    """TLS-Huber fit whose transition point follows local noise scale."""

    cfg = _active_args()
    if (
        not getattr(cfg, "adaptive_huber_enable", True)
        or huber_delta <= 0.0
        or huber_iters <= 0
        or len(points) < 2
    ):
        # These legacy paths also accept a minimal Namespace without any of
        # the adaptive sensor settings used in the cache key below.
        return _ORIGINAL_FIT(points, huber_delta, huber_iters)
    cache_key = None
    if _FIT_CACHE is not None:
        cache_key = _fit_key(points, huber_delta, huber_iters, cfg)
        cached = _FIT_CACHE.get(cache_key)
        if cached is not None:
            return _copy_line_fit(cached)
    result = _fit_line_tls_huber_adaptive_uncached(points, huber_delta, huber_iters, cfg)
    if cache_key is not None:
        if len(_FIT_CACHE) >= _FIT_CACHE_LIMIT:
            _FIT_CACHE.clear()
        _FIT_CACHE[cache_key] = _copy_line_fit(result)
    return result


def _fit_line_tls_huber_adaptive_uncached(
    points: np.ndarray,
    huber_delta: float,
    huber_iters: int,
    cfg: argparse.Namespace,
) -> base.LineFit:
    if (
        not getattr(cfg, "adaptive_huber_enable", True)
        or huber_delta <= 0.0
        or huber_iters <= 0
        or len(points) < 2
    ):
        return _ORIGINAL_FIT(points, huber_delta, huber_iters)

    if _native_eligible(points, cfg):
        result = native.fit(
            points, _active_angle(), int(huber_iters),
            float(cfg.sensor_range_noise_m), float(cfg.sensor_range_noise_slope),
            float(cfg.sensor_angle_noise_rad), float(cfg.huber_min_scale_m),
            float(cfg.huber_min_delta_m), float(cfg.huber_sigma_gain),
        )
        return base.LineFit(*result)

    weights = np.ones(len(points), dtype=np.float64)
    sigma_sensor, provisional = _local_noise_and_tls(points, _active_angle(), cfg)

    for iteration in range(max(1, int(huber_iters))):
        if iteration == 0 and provisional is not None:
            mu, direction, residual, eigvals = provisional
        else:
            mu, direction, residual, eigvals = base.fit_line_tls_core(points, weights=weights)
        med_res = _median_1d(residual)
        sigma_res = 1.4826 * _median_1d(np.abs(residual - med_res))
        local_sigma = max(sigma_sensor, sigma_res, float(cfg.huber_min_scale_m))
        delta_eff = max(
            float(cfg.huber_min_delta_m),
            float(cfg.huber_sigma_gain) * local_sigma,
        )
        abs_res = np.abs(residual)
        next_weights = np.where(abs_res <= delta_eff, 1.0, delta_eff / (abs_res + EPS))
        if np.array_equal(next_weights, weights):
            # Strict fixed point: every remaining iteration, including the
            # final TLS, would perform the identical arithmetic on these data.
            break
        weights = next_weights
    else:
        mu, direction, residual, eigvals = base.fit_line_tls_core(points, weights=weights)

    rms = float(np.sqrt(np.mean(residual**2)))
    max_res = float(np.max(np.abs(residual)))
    eigvals = np.sort(eigvals)[::-1]
    lam1 = float(max(eigvals[0], 0.0))
    lam2 = float(max(eigvals[1], 0.0))
    straightness = 1.0 - lam2 / (lam1 + lam2 + EPS)
    return base.LineFit(
        mu=mu,
        direction=direction,
        rms=rms,
        max_res=max_res,
        straightness=float(straightness),
    )


def _fragment_edge(
    a: base.Segment,
    b: base.Segment,
    points: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[FragmentEdge]:
    if b.idx_start < a.idx_start:
        a, b = b, a
    idx_gap = int(b.idx_start - a.idx_end)
    if idx_gap < 0 or idx_gap > int(args.graph_max_index_gap):
        return None

    angle_deg = base.segment_included_angle_deg(a, b)
    if angle_deg > float(args.graph_angle_deg):
        return None

    endpoint_gap = base.segment_endpoint_to_endpoint_distance(a, b)
    axis_gap = base.segment_support_axis_distance(a, b)
    r = 0.5 * (
        np.linalg.norm(base.segment_midpoint(a))
        + np.linalg.norm(base.segment_midpoint(b))
    )
    gap_thr = uncertainty_merge_gap_thr_m(r, angle_increment, args.merge_gap0_m, args.merge_cgap)
    merge_scale = adaptive_merge_scale_from_segments(a, b, angle_increment, endpoint_gap, args)
    gap_limit = max(float(args.graph_gap_scale), 1.0) * gap_thr * merge_scale
    sigma = sensor_point_sigma_m(r, angle_increment, args)
    q = _normal_quantile(args.threshold_confidence)
    perp_thr = (
        max(float(args.graph_perp_floor_m), float(args.graph_perp_sigma_scale) * q * sigma) * math.sqrt(merge_scale)
        + 0.75 * endpoint_gap
    )

    if endpoint_gap > gap_limit or axis_gap > perp_thr:
        return None

    angle_term = angle_deg / max(float(args.graph_angle_deg), 1e-6)
    gap_term = endpoint_gap / max(gap_limit, 1e-6)
    perp_term = axis_gap / max(perp_thr, 1e-6)
    index_term = idx_gap / max(float(args.graph_max_index_gap), 1.0)
    cost = (
        float(args.graph_weight_angle) * angle_term
        + float(args.graph_weight_gap) * gap_term
        + float(args.graph_weight_perp) * perp_term
        + float(args.graph_weight_index) * index_term
    )
    cost_limit = float(args.graph_edge_cost_max) * (1.0 + 0.25 * (merge_scale - 1.0))
    if cost > cost_limit:
        return None
    return FragmentEdge(
        i=-1,
        j=-1,
        cost=float(cost),
        angle_deg=float(angle_deg),
        endpoint_gap_m=float(endpoint_gap),
        axis_gap_m=float(axis_gap),
        perp_sigma_m=float(perp_thr),
    )


class _UnionFind:
    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> bool:
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1
        return True


def graph_recover_fragment_paths(
    points: np.ndarray,
    candidates: Sequence[base.Segment],
    features: Sequence[base.Segment],
    angle_increment: float,
    args: argparse.Namespace,
) -> List[base.Segment]:
    """Recover fragment chains with a degree-limited minimum-cost forest.

    Each candidate fragment is a graph node.  Edges encode angular, endpoint,
    perpendicular and scan-index consistency.  Kruskal selection with degree
    <= 2 produces path-like components, avoiding the arbitrary pair order of
    the original fragment-chain loop.
    """

    if not args.graph_recovery_enable:
        return list(features)

    fragments = [
        s
        for s in candidates
        if s.is_fragment and not s.is_feature and s.n_points >= args.frag_min_pts
    ]
    if len(fragments) < 2:
        _LAST_DIAGNOSTICS["graph_nodes"] = float(len(fragments))
        _LAST_DIAGNOSTICS["graph_edges"] = 0.0
        _LAST_DIAGNOSTICS["graph_components"] = 0.0
        _LAST_DIAGNOSTICS["graph_promoted"] = 0.0
        return list(features)

    edges: List[FragmentEdge] = []
    for i in range(len(fragments)):
        for j in range(i + 1, len(fragments)):
            if not _supported_merge_geometry(fragments[i], fragments[j], args, args.graph_angle_deg):
                continue
            raw = _fragment_edge(fragments[i], fragments[j], points, angle_increment, args)
            if raw is not None:
                edges.append(
                    FragmentEdge(
                        i=i,
                        j=j,
                        cost=raw.cost,
                        angle_deg=raw.angle_deg,
                        endpoint_gap_m=raw.endpoint_gap_m,
                        axis_gap_m=raw.axis_gap_m,
                        perp_sigma_m=raw.perp_sigma_m,
                    )
                )

    edges.sort(key=lambda e: e.cost)
    uf = _UnionFind(len(fragments))
    degree = [0] * len(fragments)
    selected: List[FragmentEdge] = []
    for edge in edges:
        if degree[edge.i] >= 2 or degree[edge.j] >= 2:
            continue
        if not uf.union(edge.i, edge.j):
            continue
        degree[edge.i] += 1
        degree[edge.j] += 1
        selected.append(edge)

    component_nodes: Dict[int, List[int]] = {}
    for idx in range(len(fragments)):
        root = uf.find(idx)
        component_nodes.setdefault(root, []).append(idx)

    recovered = list(features)
    promoted = 0
    for nodes in component_nodes.values():
        if len(nodes) < 2:
            continue
        ordered = sorted(nodes, key=lambda k: (fragments[k].idx_start, fragments[k].idx_end))
        idx_lo = min(fragments[k].idx_start for k in ordered)
        idx_hi = max(fragments[k].idx_end for k in ordered)
        if idx_lo < 0 or idx_hi >= len(points) or idx_hi <= idx_lo:
            continue

        ids = sorted({index for k in ordered for index in _support_indices(fragments[k])})
        support = points[ids] if ids else points[idx_lo : idx_hi + 1]
        if len(support) < int(args.graph_min_pts):
            continue
        dif = np.linalg.norm(np.diff(support, axis=0), axis=1)
        r_med = float(np.median(np.linalg.norm(support, axis=1)))
        gap_limit = uncertainty_gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
        support_scale = adaptive_merge_scale_from_segments(
            fragments[ordered[0]], fragments[ordered[-1]], angle_increment, None, args
        )
        if len(dif) and float(np.max(dif)) > float(args.graph_max_gap_scale) * gap_limit * support_scale:
            continue

        proposal = base.build_segment_from_points(
            support,
            idx_lo,
            idx_hi,
            args.huber_delta,
            args.huber_iters,
            args=args,
        )
        thr_rms = float(args.rms_a) + float(args.rms_b) * r_med
        thr_max = float(args.max_a) + float(args.max_b) * r_med
        quality_relax = max(float(args.graph_rms_relax), 1.0 + 0.5 * support_scale)
        local_sigma = estimate_local_noise_sigma_m(support, angle_increment, args)
        thr_rms = max(
            thr_rms * quality_relax,
            float(args.graph_rms_sigma_scale) * local_sigma,
        )
        thr_max = max(
            thr_max * max(float(args.graph_max_relax), quality_relax),
            1.25 * local_sigma,
        )
        old_length = max(fragments[k].length for k in ordered)
        if proposal.length < max(float(args.graph_min_len_m), old_length + float(args.graph_min_gain_m)):
            continue
        if proposal.rms > thr_rms:
            continue
        if proposal.max_res > thr_max:
            continue
        if proposal.straightness < float(args.graph_straightness_min):
            continue

        proposal.is_feature = True
        proposal.is_fragment = False
        proposal.merged_from = [
            (fragments[k].idx_start, fragments[k].idx_end) for k in ordered
        ]
        if base.segment_is_duplicate_like(proposal, recovered):
            continue
        recovered.append(proposal)
        promoted += 1

    _LAST_DIAGNOSTICS["graph_nodes"] = float(len(fragments))
    _LAST_DIAGNOSTICS["graph_edges"] = float(len(edges))
    _LAST_DIAGNOSTICS["graph_selected_edges"] = float(len(selected))
    _LAST_DIAGNOSTICS["graph_components"] = float(sum(len(v) >= 2 for v in component_nodes.values()))
    _LAST_DIAGNOSTICS["graph_promoted"] = float(promoted)
    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def adaptive_try_global_merge_two_segments(
    seg1: base.Segment,
    seg2: base.Segment,
    args: argparse.Namespace,
) -> Optional[Tuple[base.Segment, float, float]]:
    """Geometry-bounded merge refitted to unique original measurements."""

    if not _supported_merge_geometry(seg1, seg2, args, args.global_map_merge_angle_deg):
        return None

    a1 = seg1.p1.copy()
    b1 = seg1.p2.copy()
    a2 = seg2.p1.copy()
    b2 = seg2.p2.copy()

    d1 = base.normalize(b1 - a1)
    d2 = base.normalize(b2 - a2)

    dot = float(d1 @ d2)
    if dot < 0.0:
        d2 = -d2
        a2, b2 = b2, a2
        dot = -dot

    dot = float(np.clip(dot, -1.0, 1.0))
    angle_deg = float(np.degrees(np.arccos(dot)))
    if angle_deg > float(args.global_map_merge_angle_deg):
        return None
    endpoint_gap = base.segment_endpoint_to_endpoint_distance(seg1, seg2)
    merge_scale = adaptive_merge_scale_from_segments(seg1, seg2, _active_angle(), endpoint_gap, args)

    n1 = np.array([-d1[1], d1[0]], dtype=np.float64)
    perp_a2 = abs(float((a2 - a1) @ n1))
    perp_b2 = abs(float((b2 - a1) @ n1))
    perp_mid2 = abs(float((0.5 * (a2 + b2) - a1) @ n1))
    perp_err = max(perp_a2, perp_b2, perp_mid2)
    perp_limit = float(args.global_map_merge_perp_m)
    if perp_err > perp_limit:
        return None

    t1a = float(a1 @ d1)
    t1b = float(b1 @ d1)
    t2a = float(a2 @ d1)
    t2b = float(b2 @ d1)

    s1, e1 = min(t1a, t1b), max(t1a, t1b)
    s2, e2 = min(t2a, t2b), max(t2a, t2b)
    overlap = min(e1, e2) - max(s1, s2)
    gap_m = 0.0 if overlap >= -args.global_map_merge_overlap_tol_m else -overlap
    gap_limit = float(args.global_map_merge_endpoint_gap_m) * merge_scale
    if gap_m > gap_limit:
        return None

    merged = _refit_parent_measurements(seg1, seg2, args)
    if merged is None:
        # Layout-level callers can supply segments without a measurement scan.
        merge_pts = np.vstack([seg1.p1, seg1.p2, seg2.p1, seg2.p2])
        merged = base.build_segment_from_points(
            merge_pts, min(seg1.idx_start, seg2.idx_start), max(seg1.idx_end, seg2.idx_end),
            args.huber_delta, args.huber_iters, args=args)
        merged.n_points = max(merged.n_points, seg1.n_points + seg2.n_points)
    merged.feature = max(seg1.feature, seg2.feature)
    merged.is_feature = merged.length >= args.global_map_merge_min_len_m
    merged.is_fragment = not merged.is_feature
    if merged.length < args.global_map_merge_min_len_m:
        return None

    merged_from = list(seg1.merged_from) if seg1.merged_from else [(seg1.idx_start, seg1.idx_end)]
    merged_from.extend(seg2.merged_from if seg2.merged_from else [(seg2.idx_start, seg2.idx_end)])
    merged.merged_from = sorted(set(merged_from))
    return merged, gap_m, angle_deg


def adaptive_stitch_feature_chains(
    segments: List[base.Segment],
    args: argparse.Namespace,
) -> List[base.Segment]:
    """Aggressively connect collinear feature chains."""

    if not segments or not getattr(args, "global_map_merge_enable", True):
        return segments

    segs = list(segments)
    for _ in range(max(1, int(args.global_map_merge_max_passes))):
        changed = False
        while True:
            best_i = -1
            best_j = -1
            best_result: Optional[Tuple[base.Segment, float, float]] = None
            best_score: Optional[Tuple[float, float, float]] = None

            for i in range(len(segs)):
                for j in range(i + 1, len(segs)):
                    attempt = adaptive_try_global_merge_two_segments(segs[i], segs[j], args)
                    if attempt is None:
                        continue
                    merged, gap_m, angle_deg = attempt
                    length_gain = merged.length - max(segs[i].length, segs[j].length)
                    score = (length_gain, -gap_m, -angle_deg)
                    if best_score is None or score > best_score:
                        best_i, best_j, best_result = i, j, attempt
                        best_score = score

            if best_result is None:
                break

            merged, _, _ = best_result
            if best_i > best_j:
                best_i, best_j = best_j, best_i
            segs.pop(best_j)
            segs.pop(best_i)
            segs.append(merged)
            changed = True

        if not changed:
            break
        segs = base.sort_segments_by_mid_angle(base.deduplicate_segments(segs))

    return base.sort_segments_by_mid_angle(base.deduplicate_segments(segs))


def _dense_window_mask(points, args):
    """Batch-reject only windows safely outside the original quality gates.

    Survivors are fitted again by the scalar implementation before acceptance,
    retaining its exact endpoints and boundary decisions. Large coordinates,
    unusual dtypes and disabled adaptive Huber use the existing scalar path.
    """
    cfg = _active_args()
    if (not getattr(args, "batch_fit_enable", True)
            or not getattr(cfg, "adaptive_huber_enable", True)
            or args.huber_delta <= 0 or args.huber_iters <= 0
            or points.dtype != np.float64 or not np.isfinite(points).all()
            or float(np.max(np.abs(points))) > 1e6
            or args.dense_vertical_min_pts < 3):
        return None
    minimum = args.dense_vertical_min_pts
    maximum = min(args.dense_vertical_max_pts, len(points))
    configs = _native_growth_configs(points, _active_angle(), args)
    if configs is not None:
        dc = native.DenseConfig(int(minimum), int(maximum), float(args.dense_vertical_min_len_m),
                                float(args.dense_vertical_max_len_m), float(args.dense_vertical_abs_dir_y_min),
                                float(args.dense_vertical_rms_m), float(args.dense_vertical_max_res_m),
                                float(args.dense_vertical_straightness_min))
        return native.dense_window_mask(points, configs[0], dc)
    viable = np.zeros((len(points), max(0, maximum - minimum + 1)), dtype=bool)
    for width in range(minimum, maximum + 1):
        windows = np.lib.stride_tricks.sliding_window_view(points, (width, 2)).reshape(-1, width, 2)
        for start in range(0, len(windows), 256):
            group = windows[start:start + 256]
            span = group.max(axis=1) - group.min(axis=1)
            bounds = np.hypot(span[:, 0], span[:, 1])
            guard = 1e-10 * np.maximum(1.0, np.maximum(np.max(np.abs(group), axis=(1, 2)), bounds))
            selected = np.flatnonzero(bounds + guard >= args.dense_vertical_min_len_m)
            if not len(selected):
                continue
            residual = tls_batch(group[selected])[2]
            minimum_rms = np.sqrt(np.mean(residual ** 2, axis=1))
            selected = selected[minimum_rms <= args.dense_vertical_rms_m + guard[selected]]
            if not len(selected):
                continue
            support = group[selected]
            mu, direction, rms, max_res, straightness = fit_windows(
                support, cfg, _active_angle(), args.huber_iters, sensor_point_sigma_m,
            )
            projection = ((support - mu[:, None, :]) @ direction[..., None])[..., 0]
            p1 = mu + projection.min(axis=1)[:, None] * direction
            p2 = mu + projection.max(axis=1)[:, None] * direction
            lengths = np.linalg.norm(p2 - p1, axis=1)
            vertical = np.abs((p2 - p1)[:, 1] / (lengths + EPS))
            keep = ((lengths + guard[selected] >= args.dense_vertical_min_len_m)
                    & (lengths - guard[selected] <= args.dense_vertical_max_len_m)
                    & (vertical + 1e-9 >= args.dense_vertical_abs_dir_y_min)
                    & (rms <= args.dense_vertical_rms_m + guard[selected])
                    & (max_res <= args.dense_vertical_max_res_m + guard[selected])
                    & (straightness + 1e-9 >= args.dense_vertical_straightness_min))
            # Near repeated eigenvalues the principal direction is ill-defined;
            # leave those and sub-resolution supports to the scalar gates.
            keep |= ((np.abs(straightness - 0.5) < 1e-7)
                     | (lengths <= 100.0 * guard[selected]))
            viable[start + selected[keep], width - minimum] = True
    return viable


def _recover_dense_vertical_runs(
    points: np.ndarray,
    refs: Sequence[base.Segment],
    args: argparse.Namespace,
) -> List[base.Segment]:
    """Original recovery order with conservative impossible-length rejection.

    The distance between projected endpoints cannot exceed the support's
    bounding-box diagonal. Leave a coordinate-scaled rounding allowance so
    boundary cases still take the original fitting and acceptance path.
    """
    if not args.dense_vertical_recover_enable or len(points) < args.dense_vertical_min_pts:
        return []
    proposals: List[base.Segment] = []
    max_window = min(args.dense_vertical_max_pts, len(points))
    viable = _dense_window_mask(points, args)
    for start in range(len(points) - args.dense_vertical_min_pts + 1):
        for count in range(args.dense_vertical_min_pts, max_window + 1):
            end = start + count - 1
            if end >= len(points):
                break
            if viable is not None and not viable[start, count - args.dense_vertical_min_pts]:
                continue
            support = points[start:end + 1]
            if viable is None:
                lo, hi = np.min(support, axis=0), np.max(support, axis=0)
                bound = math.hypot(float(hi[0]) - float(lo[0]), float(hi[1]) - float(lo[1]))
                rounding = 32.0 * np.finfo(np.float64).eps * max(
                    1.0, float(np.max(np.abs(support))), bound,
                )
                if bound + rounding < args.dense_vertical_min_len_m:
                    continue
                _, _, residual, _ = base.fit_line_tls_core(support)
                minimum_rms = float(np.sqrt(np.mean(residual ** 2)))
                rms_guard = rounding + 1e-10 * max(1.0, bound)
                if minimum_rms > args.dense_vertical_rms_m + rms_guard:
                    continue
            seg = base.build_segment_from_points(
                support, start, end, args.huber_delta, args.huber_iters, args=args,
            )
            if seg.length < args.dense_vertical_min_len_m or seg.length > args.dense_vertical_max_len_m:
                continue
            if abs(base.seg_dir(seg)[1]) < args.dense_vertical_abs_dir_y_min:
                continue
            if seg.rms > args.dense_vertical_rms_m or seg.max_res > args.dense_vertical_max_res_m:
                continue
            if seg.straightness < args.dense_vertical_straightness_min:
                continue
            if base.segment_is_duplicate_like(seg, refs) or base.segment_is_duplicate_like(seg, proposals):
                continue
            seg.is_fragment = False
            seg.is_feature = True
            proposals.append(seg)
    proposals.sort(key=lambda s: (s.length, s.n_points, -s.rms), reverse=True)
    kept: List[base.Segment] = []
    for seg in proposals:
        if base.segment_is_duplicate_like(seg, kept):
            continue
        kept.append(seg)
        if len(kept) >= args.dense_vertical_max_segments:
            break
    return kept


def _extract_segments_core(
    points: np.ndarray,
    args: argparse.Namespace,
) -> Tuple[List[base.Segment], float]:
    global _ACTIVE_ARGS, _ACTIVE_ANGLE_INCREMENT
    global _MEASUREMENT_POINTS, _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT
    previous_args, previous_angle = _ACTIVE_ARGS, _ACTIVE_ANGLE_INCREMENT
    previous_measurements = (_MEASUREMENT_POINTS, _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT)
    _ACTIVE_ARGS = args
    angle_increment = float(args.angle_increment) if args.angle_increment is not None else base.estimate_angle_increment(points)
    _ACTIVE_ANGLE_INCREMENT = angle_increment
    try:
        points_for_extract = base.preprocess_points(points, angle_increment, args)
        _MEASUREMENT_POINTS = points_for_extract
        _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT = {}, {}
        for i, point in enumerate(points_for_extract):
            _MEASUREMENT_LOOKUP.setdefault(tuple(point), []).append(i)
        candidates = base.extract_all_candidates(points_for_extract, angle_increment, args)
        candidates += recover_noise_split_candidates(points_for_extract, angle_increment, args)

        if args.merge_enable:
            segments = base.merge_and_extend_candidates(
                points_for_extract, candidates, angle_increment, args
            )
        else:
            segments = [s for s in candidates if s.is_feature]

        # The graph optimizer replaces the original fragment-chain recovery.
        segments = graph_recover_fragment_paths(
            points_for_extract, candidates, segments, angle_increment, args
        )

        # Keep the original geometric global merge and deduplication as a final
        # conservative pass.  They now use uncertainty-driven thresholds due to
        # the scoped patch below.
        segments = base.attach_collinear_fragments_to_features(candidates, segments, args)
        segments = adaptive_stitch_feature_chains(segments, args)
        segments = base.sort_segments_by_mid_angle(segments)
        segments = base.deduplicate_segments(segments)
        segments = base.sort_segments_by_mid_angle(segments)
        segments = base.stitch_collinear_segments_global(segments, args)
        segments = base.sort_segments_by_mid_angle(base.deduplicate_segments(segments))
        return segments, angle_increment
    finally:
        _ACTIVE_ARGS = previous_args
        _ACTIVE_ANGLE_INCREMENT = previous_angle
        _MEASUREMENT_POINTS, _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT = previous_measurements


@contextmanager
def _patched_base(cfg=None):
    global _FALLBACK_ARGS, _FIT_CACHE, _NOISE_CACHE, _SEGMENT_CACHE
    previous_fallback, previous_cache = _FALLBACK_ARGS, _FIT_CACHE
    previous_noise_cache = _NOISE_CACHE
    previous_segment_cache = _SEGMENT_CACHE
    _FALLBACK_ARGS, _FIT_CACHE = None, {}
    if cfg is not None:
        _FALLBACK_ARGS = build_parser().parse_args([])
        _FALLBACK_ARGS.native_enable = getattr(cfg, "native_enable", False)
    _NOISE_CACHE = {}
    _SEGMENT_CACHE = {}
    names = {
        "gap_thr_m": uncertainty_gap_thr_m,
        "mean_gap_thr_m": uncertainty_mean_gap_thr_m,
        "merge_gap_thr_m": uncertainty_merge_gap_thr_m,
        "merge_perp_thr_m": uncertainty_merge_perp_thr_m,
        "fit_line_tls_huber": fit_line_tls_huber_adaptive,
        "fit_line_tls_core": _fit_line_tls_core,
        "build_segment_from_points": _build_segment_from_points,
        "median": _base_median,
        "mad": _base_mad,
        "preprocess_points": _preprocess_points,
        "extend_segment_in_run": _extend_segment_in_run,
        "extract_candidates_from_run": _extract_candidates_from_run,
        "try_global_merge_two_segments": adaptive_try_global_merge_two_segments,
        "try_merge_two_segments": _try_local_merge,
        "extract_segments": _extract_segments_core,
        "recover_dense_vertical_runs": _recover_dense_vertical_runs,
    }
    saved = {name: getattr(base, name) for name in names}
    try:
        for name, value in names.items():
            setattr(base, name, value)
        yield
    finally:
        for name, value in saved.items():
            setattr(base, name, value)
        _FALLBACK_ARGS, _FIT_CACHE = previous_fallback, previous_cache
        _NOISE_CACHE = previous_noise_cache
        _SEGMENT_CACHE = previous_segment_cache


def build_parser() -> argparse.ArgumentParser:
    parser = base.build_parser()
    parser.description = "Uncertainty-aware graph-optimized LiDAR line extraction"
    parser.set_defaults(adaptive_merge_scale_max=4.0)
    parser.add_argument("--candidate-gap-spacing-factor", type=float, default=2.0,
                        help="Maximum ordinary projected step relative to median spacing during candidate recovery")
    parser.add_argument("--merge-gap-length-ratio", type=float, default=0.75,
                        help="Bound unsupported merge gaps by the shorter measured segment length")
    parser.add_argument(
        "--native-enable", action=argparse.BooleanOptionalAction, default=True,
        help="Use optional compiled kernels (Numba/SciPy); --no-native-enable keeps NumPy",
    )
    parser.add_argument(
        "--batch-fit-enable", action=argparse.BooleanOptionalAction, default=True,
        help="Batch-screen dense recovery windows; accepted segments retain scalar fitting",
    )

    parser.add_argument(
        "--uncertainty-enable",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Use sensor uncertainty and confidence-quantile thresholds",
    )
    parser.add_argument("--sensor-range-noise-m", type=float, default=0.003)
    parser.add_argument("--sensor-range-noise-slope", type=float, default=0.001)
    parser.add_argument("--sensor-angle-noise-rad", type=float, default=0.0005)
    parser.add_argument("--threshold-confidence", type=float, default=0.9973)
    parser.add_argument("--uncertainty-base-m", type=float, default=0.003)
    parser.add_argument("--uncertainty-floor-m", type=float, default=0.008)
    parser.add_argument("--uncertainty-cap-m", type=float, default=0.80)
    parser.add_argument("--uncertainty-perp-floor-m", type=float, default=0.025)
    parser.add_argument("--uncertainty-perp-cap-m", type=float, default=0.30)
    parser.add_argument("--uncertainty-perp-scale", type=float, default=1.25)
    parser.add_argument("--uncertainty-gap-scale", type=float, default=1.20)
    parser.add_argument("--uncertainty-mean-scale", type=float, default=0.92)
    parser.add_argument("--uncertainty-merge-scale", type=float, default=1.35)

    parser.add_argument(
        "--adaptive-huber-enable",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Tie Huber transition point to the local robust noise estimate",
    )
    parser.add_argument("--huber-sigma-gain", type=float, default=1.75)
    parser.add_argument("--huber-min-scale-m", type=float, default=0.002)
    parser.add_argument("--huber-min-delta-m", type=float, default=0.006)
    parser.add_argument(
        "--graph-recovery-enable",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Recover fragment paths with a degree-limited minimum-cost forest",
    )
    parser.add_argument("--graph-angle-deg", type=float, default=10.0)
    parser.add_argument("--graph-max-index-gap", type=int, default=60)
    parser.add_argument("--graph-gap-scale", type=float, default=3.0)
    parser.add_argument("--graph-perp-floor-m", type=float, default=0.035)
    parser.add_argument("--graph-perp-sigma-scale", type=float, default=2.0)
    parser.add_argument("--graph-weight-angle", type=float, default=0.35)
    parser.add_argument("--graph-weight-gap", type=float, default=0.35)
    parser.add_argument("--graph-weight-perp", type=float, default=0.20)
    parser.add_argument("--graph-weight-index", type=float, default=0.10)
    parser.add_argument("--graph-edge-cost-max", type=float, default=1.0)
    parser.add_argument("--graph-min-pts", type=int, default=8)
    parser.add_argument("--graph-min-len-m", type=float, default=0.15)
    parser.add_argument("--graph-min-gain-m", type=float, default=0.015)
    parser.add_argument("--graph-max-gap-scale", type=float, default=2.5)
    parser.add_argument("--graph-rms-relax", type=float, default=2.0)
    parser.add_argument("--graph-max-relax", type=float, default=2.0)
    parser.add_argument("--graph-rms-sigma-scale", type=float, default=0.85)
    parser.add_argument("--graph-straightness-min", type=float, default=0.975)
    parser.add_argument("--adaptive-merge-sparsity-gain", type=float, default=1.15)
    parser.add_argument("--adaptive-merge-sparsity-power", type=float, default=1.0)
    return parser


def extract_segments(
    points: np.ndarray,
    args: Optional[argparse.Namespace] = None,
) -> Tuple[List[base.Segment], float]:
    """Drop-in extraction API compatible with ``feature.py``."""

    cfg = args if args is not None else build_parser().parse_args([])
    prepare_backend(cfg)
    with _patched_base(cfg):
        return _extract_segments_core(points, cfg)


def extract_segments_from_layout(
    points: np.ndarray,
    frame_layouts: Sequence[dict],
    args: Optional[argparse.Namespace] = None,
) -> Tuple[List[base.Segment], float, bool]:
    """Extract prepared data; call prepare_backend(cfg) before external timing.

    Input files are never read here. On first use, optional JIT/cache setup is
    automatic; preparing explicitly separates that one-time cost from logic.
    """
    cfg = args if args is not None else build_parser().parse_args([])
    prepare_backend(cfg)
    with _patched_base(cfg):
        return base.extract_segments_from_layout(points, frame_layouts, cfg)


def prepare_backend(args: argparse.Namespace) -> float:
    """Prepare optional JIT kernels, returning setup ms separately from logic."""
    start = perf_counter()
    if getattr(args, "native_enable", False):
        native.prepare()
    return (perf_counter() - start) * 1000.0


def run_cli(args: argparse.Namespace) -> None:
    """Run the original plotting/summary CLI and append graph diagnostics."""

    original_layout_extract = base.extract_segments_from_input_layout
    elapsed_ms = 0.0
    fallback_args = build_parser().parse_args([])
    fallback_args.native_enable = getattr(args, "native_enable", False)
    setup_ms = prepare_backend(args)

    def timed_layout_extract(points, input_path, cfg):
        nonlocal elapsed_ms
        global _FALLBACK_ARGS
        layouts = base.load_frame_layouts(input_path)
        _FALLBACK_ARGS = fallback_args
        started = perf_counter()
        result = base.extract_segments_from_layout(points, layouts, cfg)
        elapsed_ms = (perf_counter() - started) * 1000.0
        return result

    with _patched_base():
        try:
            base.extract_segments_from_input_layout = timed_layout_extract
            base.run_cli(args)
        finally:
            base.extract_segments_from_input_layout = original_layout_extract
    print(f"Algorithm runtime (excluding data loading and plotting): {elapsed_ms:.3f} ms")
    print(f"Acceleration backend: {'Numba' if native._READY and getattr(args, 'native_enable', False) else 'NumPy'}; setup (excluded above): {setup_ms:.3f} ms")
    if _LAST_DIAGNOSTICS:
        print("---- Uncertainty/graph diagnostics ----")
        for key in sorted(_LAST_DIAGNOSTICS):
            print(f"{key}: {_LAST_DIAGNOSTICS[key]:.3f}")


def main() -> None:
    args = build_parser().parse_args()
    run_cli(args)


if __name__ == "__main__":
    main()
