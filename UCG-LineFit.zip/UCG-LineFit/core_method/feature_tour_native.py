"""Optional compiled kernels; the model and its stopping rules stay unchanged.

Install requirements-feature-tour-fast.txt to enable. No fast-math, parallel
reductions, relaxed Huber convergence, or reduced iteration count is used.
Compilation/cache loading belongs to prepare(), never to reported core timing.
"""
from __future__ import annotations

import math
import numpy as np
from typing import NamedTuple

try:
    from numba import njit
    import scipy.linalg  # Numba's LAPACK bridge requires SciPy.
except ImportError:
    AVAILABLE = False
else:
    AVAILABLE = True

EPS = 1e-12
_READY = False


class FitConfig(NamedTuple):
    angle: float
    iters: int
    noise_r: float
    noise_slope: float
    noise_angle: float
    min_scale: float
    min_delta: float
    sigma_gain: float


class GapConfig(NamedTuple):
    enabled: bool
    noise_r: float
    noise_slope: float
    noise_angle: float
    quantile: float
    base: float
    floor: float
    cap: float
    gap_scale: float
    mean_scale: float
    config_gap0: float
    gap0: float
    cgap: float
    cmean: float


class GrowConfig(NamedTuple):
    min_pts: int
    rms_a: float
    rms_b: float
    max_a: float
    max_b: float
    straight_min: float
    rms_relax: float
    max_relax: float
    straight_relax: float


class BranchConfig(NamedTuple):
    min_pts: int
    frag_pts: int
    frag_len: float
    frag_straight: float
    straight_min: float
    rms_a: float
    rms_b: float
    merge_gap: float
    lookback: int
    perp_base: float
    perp_cr: float
    perp_floor: float
    perp_cap: float
    perp_scale: float


class Geometry(NamedTuple):
    p1: np.ndarray
    p2: np.ndarray
    length: float
    rms: float
    max_res: float
    straight: float
    count: int
    start: int
    end: int


class PrecleanConfig(NamedTuple):
    passes: int
    window: int
    run_gap_scale: float
    isolated_gap_scale: float
    gap_scale: float
    residual_abs: float
    residual_scale: float
    radial_abs: float
    radial_scale: float
    small_max_pts: int
    small_max_len: float
    small_straight: float


class DenseConfig(NamedTuple):
    min_pts: int
    max_pts: int
    min_len: float
    max_len: float
    min_vertical: float
    rms: float
    max_res: float
    straight: float


if AVAILABLE:
    @njit(cache=True)
    def median(values):
        return np.median(values)

    @njit(cache=True)
    def branch_support(points, seed_start, seed_end, search_start, search_end,
                       origin, direction, attach_point, perp_thr, proj_gap, back_tol):
        """Original 16-step projection growth, without intermediate masks."""
        window = points[search_start:search_end + 1]
        normal = np.array([-direction[1], direction[0]])
        proj = (window - origin) @ direction
        perp = np.abs((window - origin) @ normal)
        seed_proj = (points[seed_start:seed_end + 1] - origin) @ direction
        seed_lo, seed_hi = np.min(seed_proj), np.max(seed_proj)
        attach_proj = (attach_point - origin) @ direction
        low = abs(attach_proj - seed_lo) <= abs(attach_proj - seed_hi)
        lo, hi = seed_lo, seed_hi
        for _ in range(16):
            found = False
            edge = -np.inf if low else np.inf
            for i in range(len(window)):
                if perp[i] > perp_thr:
                    continue
                if low and seed_lo - back_tol <= proj[i] <= hi + proj_gap:
                    edge = max(edge, proj[i])
                    found = True
                elif not low and lo - proj_gap <= proj[i] <= seed_hi + back_tol:
                    edge = min(edge, proj[i])
                    found = True
            if not found:
                break
            if low:
                if edge <= hi + 1e-6:
                    break
                hi = edge
            else:
                if edge >= lo - 1e-6:
                    break
                lo = edge
        selected = np.empty(len(window), dtype=np.int64)
        count = 0
        for i in range(len(window)):
            inside = (seed_lo - back_tol <= proj[i] <= hi + 1e-9) if low else (lo - 1e-9 <= proj[i] <= seed_hi + back_tol)
            if perp[i] <= perp_thr and inside:
                selected[count] = search_start + i
                count += 1
        return selected[:count]

    @njit(cache=True)
    def tls_lapack(points, weights):
        """Reference path for nearly isotropic or non-finite covariance."""
        denom = max(np.sum(weights), EPS)
        mu = np.sum(points * weights[:, None], axis=0) / denom
        q = points - mu
        cov = (q * weights[:, None]).T @ q / denom
        eigvals, eigvecs = np.linalg.eigh(cov)
        direction = eigvecs[:, np.argmax(eigvals)].copy()
        direction /= np.sqrt(np.sum(direction * direction)) + EPS
        if direction[0] < 0.0 or (abs(direction[0]) < EPS and direction[1] < 0.0):
            direction = -direction
        normal = np.array([-direction[1], direction[0]])
        return mu, direction, q @ normal, eigvals

    @njit(cache=True)
    def tls(points, weights):
        """Two-pass 2-D TLS without temporary matrices or a LAPACK call.

        Center before accumulating covariance (no raw-moment subtraction).
        The analytic symmetric 2x2 eigensystem is algebraically identical to
        eigh; retain LAPACK where its repeated-eigenvalue convention matters.
        No fast-math or approximate convergence is used.
        """
        total, sx, sy = 0.0, 0.0, 0.0
        for i in range(len(points)):
            w = weights[i]
            total += w
            sx += points[i, 0] * w
            sy += points[i, 1] * w
        denom = max(total, EPS)
        mx, my = sx / denom, sy / denom
        xx, xy, yy = 0.0, 0.0, 0.0
        for i in range(len(points)):
            x, y = points[i, 0] - mx, points[i, 1] - my
            xx += (x * weights[i]) * x
            xy += (y * weights[i]) * x  # eigh reads the lower triangle.
            yy += (y * weights[i]) * y
        xx, xy, yy = xx / denom, xy / denom, yy / denom
        gap = math.hypot(xx - yy, 2.0 * xy)
        if not math.isfinite(gap) or gap <= 1e-6 * max(abs(xx), abs(yy), 1e-300):
            return tls_lapack(points, weights)
        # Choose the longer of the equivalent eigenvectors to avoid
        # cancellation when the principal axis is nearly horizontal/vertical.
        if xx >= yy:
            dx, dy = xx - yy + gap, 2.0 * xy
        else:
            dx, dy = 2.0 * xy, yy - xx + gap
        length = math.hypot(dx, dy)
        dx, dy = dx / length, dy / length
        length = math.sqrt(dx * dx + dy * dy) + EPS
        dx, dy = dx / length, dy / length
        if dx < 0.0 or (abs(dx) < EPS and dy < 0.0):
            dx, dy = -dx, -dy
        residual = np.empty(len(points))
        for i in range(len(points)):
            residual[i] = (points[i, 0] - mx) * -dy + (points[i, 1] - my) * dx
        eigvals = np.array([(xx + yy - gap) * 0.5, (xx + yy + gap) * 0.5])
        return np.array([mx, my]), np.array([dx, dy]), residual, eigvals

    @njit(cache=True)
    def fit(points, angle, iters, noise_r, noise_slope, noise_angle,
            min_scale, min_delta, sigma_gain):
        n = len(points)
        weights = np.ones(n)
        mu, direction, residual, eigvals = tls(points, weights)
        if n < 3:
            rr = 0.5
            radial_mad = 0.0
            residual_mad = 0.0
        else:
            ranges = np.sqrt(np.sum(points * points, axis=1))
            rr = max(np.median(ranges), 0.05)
            steps = np.abs(np.diff(ranges))
            radial_mad = 1.4826 * np.median(np.abs(steps - np.median(steps)))
            residual_mad = 1.4826 * np.median(np.abs(residual - np.median(residual)))
        sr = max(noise_r, 1e-7) + max(noise_slope, 0.0) * rr
        sa = math.sqrt((max(angle, 1e-9) / math.sqrt(12.0)) ** 2 + max(noise_angle, 0.0) ** 2)
        sigma = math.hypot(sr, rr * sa)
        if n >= 3:
            sigma = max(sigma, radial_mad / math.sqrt(2.0), residual_mad, min_scale)
        for _ in range(max(1, iters)):
            sigma_res = 1.4826 * np.median(np.abs(residual - np.median(residual)))
            delta = max(min_delta, sigma_gain * max(sigma, sigma_res, min_scale))
            changed = False
            for i in range(n):
                ar = abs(residual[i])
                weight = 1.0 if ar <= delta else delta / (ar + EPS)
                if weight != weights[i]:
                    changed = True
                weights[i] = weight
            if not changed:
                break
            mu, direction, residual, eigvals = tls(points, weights)
        rms = math.sqrt(np.mean(residual ** 2))
        max_res = np.max(np.abs(residual))
        lam1, lam2 = max(eigvals[1], 0.0), max(eigvals[0], 0.0)
        return mu, direction, rms, max_res, 1.0 - lam2 / (lam1 + lam2 + EPS)

    @njit(cache=True)
    def gap_threshold(r, angle, cfg, mean=False):
        rr, da = max(r, 0.05), max(angle, 1e-9)
        if not cfg.enabled:
            if mean:
                return max(cfg.gap0 + cfg.cmean * rr * angle, cfg.gap0 * 2.4)
            return max(cfg.gap0 + cfg.cgap * rr * angle, cfg.gap0 * 3.0)
        sr = max(cfg.noise_r, 1e-7) + max(cfg.noise_slope, 0.0) * rr
        sa = math.sqrt((da / math.sqrt(12.0)) ** 2 + max(cfg.noise_angle, 0.0) ** 2)
        sigma = math.hypot(sr, rr * sa)
        scale = cfg.mean_scale if mean else cfg.gap_scale
        value = cfg.base + scale * (2.0 * rr * math.sin(0.5 * da) + cfg.quantile * math.sqrt(2.0) * sigma)
        floor = max(cfg.floor, 0.5 * cfg.config_gap0)
        return min(max(value, floor), max(cfg.cap, floor))

    @njit(cache=True)
    def configured_fit(points, fc):
        return fit(points, fc.angle, fc.iters, fc.noise_r, fc.noise_slope,
                   fc.noise_angle, fc.min_scale, fc.min_delta, fc.sigma_gain)

    @njit(cache=True)
    def interval_fit(points, start, end, fc, cache):
        """Bounded, run-local exact memoization of overlapping support windows.

        The caller owns one immutable point array and one FitConfig for the
        cache lifetime. Both indices are checked, so hash collisions only
        evict old entries. No fitting results survive an extraction request.
        """
        slot = 0
        if cache is not None:
            slot = (start * 131 + end) % len(cache)
            row = cache[slot]
            if row[9] == 1.0 and row[0] == start and row[1] == end:
                return (np.array([row[2], row[3]]), np.array([row[4], row[5]]),
                        row[6], row[7], row[8])
        mu, direction, rms, max_res, straight = configured_fit(points[start:end + 1], fc)
        if cache is not None:
            row = cache[slot]
            row[0], row[1] = start, end
            row[2], row[3] = mu[0], mu[1]
            row[4], row[5] = direction[0], direction[1]
            row[6], row[7], row[8], row[9] = rms, max_res, straight, 1.0
        return mu, direction, rms, max_res, straight

    @njit(cache=True)
    def prune_small_runs(points, angle, gc, pc):
        if len(points) <= 2:
            return points
        keep = np.ones(len(points), dtype=np.bool_)
        start = 0
        for end in range(len(points)):
            if end + 1 < len(points):
                rr = 0.5 * (np.linalg.norm(points[end]) + np.linalg.norm(points[end + 1]))
                gap = np.linalg.norm(points[end + 1] - points[end])
                if gap <= gap_threshold(rr, angle, gc) * pc.run_gap_scale:
                    continue
            count = end - start + 1
            if count <= pc.small_max_pts:
                support = points[start:end + 1]
                _, _, _, eigenvalues = tls(support, np.ones(count))
                lam1, lam2 = max(eigenvalues[1], 0.0), max(eigenvalues[0], 0.0)
                straight = 1.0 - lam2 / (lam1 + lam2 + EPS)
                length = np.linalg.norm(points[end] - points[start])
                if length <= pc.small_max_len or straight <= pc.small_straight:
                    keep[start:end + 1] = False
            start = end + 1
        pruned = points[keep]
        return pruned if len(pruned) >= 2 else points

    @njit(cache=True)
    def preprocess(points, angle, gc, pc):
        """Unchanged local-MAD rejection, compiled as one per-frame operation."""
        filtered = points.copy()
        for _ in range(max(1, pc.passes)):
            if len(filtered) < max(7, 2 * pc.window + 3):
                break
            ranges = np.sqrt(np.sum(filtered * filtered, axis=1))
            distances = np.empty(len(filtered) - 1)
            for j in range(len(distances)):
                distances[j] = np.linalg.norm(filtered[j + 1] - filtered[j])
            keep = np.ones(len(filtered), dtype=np.bool_)
            for i in range(1, len(filtered) - 1):
                left = max(0, i - pc.window)
                right = min(len(filtered), i + pc.window + 1)
                d_prev, d_next = distances[i - 1], distances[i]
                run_gap = gap_threshold(max(ranges[i], 0.05), angle, gc) * pc.run_gap_scale
                if d_prev > run_gap:
                    left = i
                if d_next > run_gap:
                    right = i + 1
                while left < i and distances[left] > run_gap:
                    left += 1
                while right > i + 1 and distances[right - 2] > run_gap:
                    right -= 1
                if right - left < max(4, pc.window + 2):
                    continue
                size = right - left - 1
                if size < 3:
                    continue
                neighbors = np.empty((size, 2))
                local_ranges = np.empty(size)
                k = 0
                for j in range(left, right):
                    if j != i:
                        neighbors[k] = filtered[j]
                        local_ranges[k] = ranges[j]
                        k += 1
                mu, direction, _, _ = tls(neighbors, np.ones(size))
                residual = abs((filtered[i, 0] - mu[0]) * -direction[1]
                               + (filtered[i, 1] - mu[1]) * direction[0])
                r_med = np.median(local_ranges)
                gap = gap_threshold(r_med, angle, gc)
                mean_gap = gap_threshold(r_med, angle, gc, True)
                radial_sigma = 1.4826 * np.median(np.abs(local_ranges - r_med))
                radial_dev = abs(ranges[i] - r_med)
                isolated = d_prev > gap * pc.isolated_gap_scale and d_next > gap * pc.isolated_gap_scale
                bridge = d_prev > gap * pc.gap_scale or d_next > gap * pc.gap_scale
                deviated = residual > max(pc.residual_abs, mean_gap * pc.residual_scale)
                radial_bad = radial_dev > max(pc.radial_abs, (radial_sigma + gap) * pc.radial_scale)
                if isolated or (deviated and (bridge or radial_bad)):
                    keep[i] = False
            if np.all(keep):
                break
            candidate = filtered[keep]
            if len(candidate) < 2:
                break
            candidate = prune_small_runs(candidate, angle, gc, pc)
            if len(candidate) == len(filtered):
                break
            filtered = candidate
        return filtered if len(filtered) >= 2 else points

    @njit(cache=True)
    def dense_window_mask(points, fc, dc):
        """Conservative screening with original length, TLS and Huber gates.

        Survivors still take the existing scalar acceptance and deduplication
        path. Bounding boxes grow incrementally; no sliding-window tensor or
        batch temporary is materialized. The same roundoff guards are retained.
        """
        maximum = min(dc.max_pts, len(points))
        viable = np.zeros((len(points), max(0, maximum - dc.min_pts + 1)), dtype=np.bool_)
        for start in range(len(points) - dc.min_pts + 1):
            lo_x, hi_x = np.inf, -np.inf
            lo_y, hi_y = np.inf, -np.inf
            for width in range(1, min(maximum, len(points) - start) + 1):
                x, y = points[start + width - 1]
                lo_x, hi_x = min(lo_x, x), max(hi_x, x)
                lo_y, hi_y = min(lo_y, y), max(hi_y, y)
                if width < dc.min_pts:
                    continue
                bound = math.hypot(hi_x - lo_x, hi_y - lo_y)
                guard = 1e-10 * max(1.0, abs(lo_x), abs(hi_x), abs(lo_y), abs(hi_y), bound)
                if bound + guard < dc.min_len:
                    continue
                support = points[start:start + width]
                _, _, residual, _ = tls(support, np.ones(width))
                if math.sqrt(np.mean(residual ** 2)) > dc.rms + guard:
                    continue
                mu, direction, rms, max_res, straight = configured_fit(support, fc)
                projection = (support - mu) @ direction
                p1 = mu + np.min(projection) * direction
                p2 = mu + np.max(projection) * direction
                length = np.linalg.norm(p2 - p1)
                vertical = abs((p2[1] - p1[1]) / (length + EPS))
                keep = (length + guard >= dc.min_len and length - guard <= dc.max_len
                        and vertical + 1e-9 >= dc.min_vertical and rms <= dc.rms + guard
                        and max_res <= dc.max_res + guard and straight + 1e-9 >= dc.straight)
                keep = keep or abs(straight - 0.5) < 1e-7 or length <= 100.0 * guard
                viable[start, width - dc.min_pts] = keep
        return viable

    @njit(cache=True)
    def geometry(points, start, end, fc):
        return fitted_geometry(points, start, end, configured_fit(points, fc))

    @njit(cache=True)
    def fitted_geometry(points, start, end, fitted):
        mu, direction, rms, max_res, straight = fitted
        projection = (points - mu) @ direction
        p1, p2 = mu + np.min(projection) * direction, mu + np.max(projection) * direction
        return Geometry(p1, p2, np.linalg.norm(p2 - p1), rms, max_res, straight, len(points), start, end)

    @njit(cache=True)
    def interval_geometry(points, indices, start, end, fc, cache):
        fitted = interval_fit(points, start, end, fc, cache)
        return fitted_geometry(points[start:end + 1], indices[start], indices[end], fitted)

    @njit(cache=True)
    def segment_direction(segment):
        v = segment.p2 - segment.p1
        return v / (np.linalg.norm(v) + EPS)

    @njit(cache=True)
    def angle_between(a, b):
        return np.degrees(np.arccos(min(max(abs(a @ b), -1.0), 1.0)))

    @njit(cache=True)
    def range_median(points):
        return np.median(np.sqrt(np.sum(points * points, axis=1)))

    @njit(cache=True)
    def extend_branch(points, indices, seed_start, seed_end, search_start,
                      search_end, seed, attach, parent_dir, fc, gc, bc):
        if search_start > search_end or search_end - search_start + 1 < seed.count:
            return seed
        median_range = range_median(points[seed_start:seed_end + 1])
        if gc.enabled:
            rr = max(median_range, 0.05)
            sr = max(fc.noise_r, 1e-7) + max(fc.noise_slope, 0.0) * rr
            sa = math.sqrt((max(fc.angle, 1e-9) / math.sqrt(12.0)) ** 2 + max(fc.noise_angle, 0.0) ** 2)
            sigma = math.hypot(sr, rr * sa)
            floor = max(bc.perp_floor, 0.5 * bc.perp_base)
            perp = min(max(bc.perp_scale * gc.quantile * sigma, floor), max(bc.perp_cap, floor))
        else:
            perp = bc.perp_base + bc.perp_cr * max(median_range, 0.05)
        selected = branch_support(points, seed_start, seed_end, search_start, search_end,
                                  seed.p1, segment_direction(seed), attach, max(perp * 2.5, 0.07),
                                  max(bc.merge_gap * 2.1, 0.15), max(bc.merge_gap, 0.06))
        if len(selected) <= seed.count:
            return seed
        selected_points, selected_indices = points[selected], indices[selected]
        extended = geometry(selected_points, np.min(selected_indices), np.max(selected_indices), fc)
        angle = angle_between(segment_direction(extended), parent_dir)
        attach_dist = min(np.linalg.norm(extended.p1 - attach), np.linalg.norm(extended.p2 - attach))
        if not (45.0 <= angle <= 135.0):
            return seed
        if extended.straight < max(0.90, bc.frag_straight - 0.09):
            return seed
        if extended.rms > (bc.rms_a + bc.rms_b * range_median(selected_points)) * 2.4:
            return seed
        if attach_dist > max(bc.merge_gap * 2.2, 0.28) or extended.length <= seed.length + 0.01:
            return seed
        return extended

    @njit(cache=True)
    def endpoint_branches(points, indices, start, end, parent_dir, parent_p1, parent_p2, fc, bc, cache=None):
        result = []
        if end - start + 1 < max(bc.frag_pts + 1, 4):
            return result
        max_window = min(end - start + 1, max(bc.frag_pts + 10, bc.min_pts + 2))
        min_window = max(3, bc.frag_pts)
        for side in range(2):
            found = False
            best_score = (-np.inf, -np.inf, -np.inf, -np.inf)
            for win in range(min_window, max_window + 1):
                a, b = (start, start + win - 1) if side == 0 else (end - win + 1, end)
                attach = parent_p1 if side == 0 else parent_p2
                branch = interval_geometry(points, indices, a, b, fc, cache)
                angle = angle_between(parent_dir, segment_direction(branch))
                if not (45.0 <= angle <= 135.0):
                    continue
                if branch.length < bc.frag_len or branch.count < min_window:
                    continue
                if branch.straight < max(0.94, bc.frag_straight - 0.05):
                    continue
                if branch.rms > (bc.rms_a + bc.rms_b * range_median(points[a:b + 1])) * 1.9:
                    continue
                attach_dist = min(np.linalg.norm(branch.p1 - attach), np.linalg.norm(branch.p2 - attach))
                if attach_dist > max(bc.merge_gap * 1.6, 0.22):
                    continue
                score = (branch.length, -abs(angle - 90.0), branch.straight, -branch.rms)
                if not found or score > best_score:
                    best, best_score, found = branch, score, True
            if found:
                result.append(best)
        return result

    @njit(cache=True)
    def corner_branches(points, indices, start, end, parent_dir, fc, gc, bc, cache=None):
        result = []
        if end - start + 1 < max(bc.min_pts, 6):
            return result
        min_branch_pts = max(3, bc.frag_pts - 1)
        max_branch_pts = min(max(bc.frag_pts + 30, bc.min_pts + 12), end - start)
        for side in range(2):
            found = False
            best_score = (-np.inf, -np.inf, -np.inf)
            for count in range(min_branch_pts, max_branch_pts + 1):
                if side == 0:
                    a, b, t_start, t_end = start, start + count - 1, start + count - 1, end
                    attach = points[b]
                    search_start = max(0, start - max(bc.min_pts + 20, 52))
                    search_end = min(len(points) - 1, b + 5)
                else:
                    a, b, t_start, t_end = end - count + 1, end, start, end - count + 1
                    attach = points[a]
                    search_start = max(0, a - 8)
                    search_end = min(len(points) - 1, end + max(bc.min_pts + 30, 68))
                if t_end - t_start + 1 < max(bc.min_pts // 2, 4):
                    continue
                seed = interval_geometry(points, indices, a, b, fc, cache)
                seed_dir = segment_direction(seed)
                if side == 0 and abs(parent_dir[1]) >= 0.9 and abs(seed_dir[0]) >= 0.94:
                    search_start = max(0, search_start - bc.lookback)
                    search_end = min(len(points) - 1, search_end + 1)
                branch = extend_branch(points, indices, a, b, search_start, search_end,
                                       seed, attach, parent_dir, fc, gc, bc)
                trunk = interval_geometry(points, indices, t_start, t_end, fc, cache)
                angle = angle_between(segment_direction(branch), segment_direction(trunk))
                if not (45.0 <= angle <= 135.0):
                    continue
                if branch.length < max(bc.frag_len, 0.04) or branch.count < min_branch_pts:
                    continue
                if branch.straight < max(0.93, bc.frag_straight - 0.06):
                    continue
                if trunk.straight < max(bc.straight_min - 0.07, 0.90):
                    continue
                attach_dist = min(np.linalg.norm(branch.p1 - attach), np.linalg.norm(branch.p2 - attach))
                if attach_dist > 0.22:
                    continue
                score = (branch.length, -abs(angle - 90.0), branch.straight - branch.rms)
                if not found or score > best_score:
                    best, best_score, found = branch, score, True
            if found:
                result.append(best)
        return result

    @njit(cache=True)
    def grow_window(points, ranges, start, angle, fc, gc, qc, cache=None):
        end = start
        while end + 1 < len(points):
            r = 0.5 * (ranges[end] + ranges[end + 1])
            gap = np.linalg.norm(points[end + 1] - points[end])
            if gap > gap_threshold(r, angle, gc):
                break
            end += 1
            if end - start + 1 >= qc.min_pts:
                _, _, rms, max_res, straight = interval_fit(points, start, end, fc, cache)
                med_r = np.median(ranges[start:end + 1])
                if (rms > (qc.rms_a + qc.rms_b * med_r) * max(1.0, qc.rms_relax)
                        or max_res > (qc.max_a + qc.max_b * med_r) * max(1.0, qc.max_relax)
                        or straight < qc.straight_min - min(max(qc.straight_relax, 0.0), 0.20)):
                    end -= 1
                    break
        return end

    @njit(cache=True)
    def extend_segment(points, start, end, angle, fc, gc, qc, cache=None):
        if start < 0 or end >= len(points) or start >= end:
            return start, end
        ranges = np.sqrt(np.sum(points * points, axis=1))
        distances = np.empty(max(0, len(points) - 1))
        for i in range(len(distances)):
            distances[i] = np.sqrt(np.sum((points[i + 1] - points[i]) ** 2))
        changed = True
        while changed:
            changed = False
            for side in range(2):
                best_start, best_end, best_count, best_quality = start, end, -1, -np.inf
                for step in range(1, 6):
                    a = start - step if side == 0 else start
                    b = end if side == 0 else end + step
                    if a < 0 or b >= len(points):
                        continue
                    # Keep the original right-side boundary convention.
                    other = a + 1 if side == 0 else b - 1
                    r = 0.5 * (np.linalg.norm(points[a]) + np.linalg.norm(points[other]))
                    gap = np.linalg.norm(points[a] - points[other])
                    if gap > gap_threshold(r, angle, gc) * 1.18 * max(1.0, step * 0.9):
                        continue
                    med_r = np.median(ranges[a:b + 1])
                    dif = distances[a:b]
                    if (np.mean(dif) > gap_threshold(med_r, angle, gc, True) * 1.18 * max(1.0, step * 0.9)
                            or np.max(dif) > gap_threshold(med_r, angle, gc) * 1.18 * max(1.0, step * 1.2)):
                        continue
                    _, _, rms, max_res, straight = interval_fit(points, a, b, fc, cache)
                    if (rms > (qc.rms_a + qc.rms_b * med_r) * (max(1.0, qc.rms_relax) * 1.15)
                            or max_res > (qc.max_a + qc.max_b * med_r) * (max(1.0, qc.max_relax) * 1.20) * max(1.0, step * 1.15)
                            or straight < qc.straight_min - min(max(qc.straight_relax, 0.0), 0.20) - 0.015):
                        continue
                    count, quality = b - a + 1, straight - rms
                    if count > best_count or (count == best_count and quality > best_quality):
                        best_start, best_end, best_count, best_quality = a, b, count, quality
                if best_count >= 0:
                    start, end = best_start, best_end
                    changed = True
        return start, end


def prepare():
    """Load/compile all used signatures once; return backend availability."""
    global _READY
    if not AVAILABLE:
        return False
    if not _READY:
        points = np.array([[0.0, 0.0], [0.1, 0.01], [0.2, 0.0]])
        fit(points, 0.01, 6, 0.003, 0.001, 0.0005, 0.002, 0.006, 1.75)
        median(points[:, 0].copy())
        branch_support(points, 0, 1, 0, 2, points[0], np.array([1.0, 0.0]), points[0], 0.1, 0.2, 0.1)
        fc = FitConfig(0.01, 6, 0.003, 0.001, 0.0005, 0.002, 0.006, 1.75)
        gc = GapConfig(True, 0.003, 0.001, 0.0005, 3.0, 0.003, 0.008, 0.8, 1.2, 0.92, 0.01, 0.01, 1.0, 1.0)
        qc = GrowConfig(3, 0.01, 0.01, 0.02, 0.01, 0.98, 1.1, 1.1, 0.01)
        grow_window(points, np.linalg.norm(points, axis=1), 0, 0.01, fc, gc, qc)
        extend_segment(points, 0, 1, 0.01, fc, gc, qc)
        bc = BranchConfig(8, 3, 0.04, 0.98, 0.98, 0.01, 0.01, 0.05, 10, 0.02, 0.01, 0.025, 0.3, 1.25)
        indices, direction = np.arange(len(points)), np.array([1.0, 0.0])
        endpoint_branches(points, indices, 0, 2, direction, points[0], points[-1], fc, bc)
        corner_branches(points, indices, 0, 2, direction, fc, gc, bc)
        interval_cache = np.zeros((4096, 10))
        grow_window(points, np.linalg.norm(points, axis=1), 0, 0.01, fc, gc, qc, interval_cache)
        extend_segment(points, 0, 1, 0.01, fc, gc, qc, interval_cache)
        endpoint_branches(points, indices, 0, 2, direction, points[0], points[-1], fc, bc, interval_cache)
        corner_branches(points, indices, 0, 2, direction, fc, gc, bc, interval_cache)
        pc = PrecleanConfig(2, 2, 1.45, 2.8, 1.55, 0.028, 1.85, 0.06, 2.4, 4, 0.06, 0.90)
        preprocess(points, 0.01, gc, pc)
        dc = DenseConfig(3, 18, 0.34, 0.8, 0.93, 0.012, 0.020, 0.995)
        dense_window_mask(points, fc, dc)
        _READY = True
    return True
