#!/usr/bin/env python3
"""创新点一消融：移除不确定性校准及稀疏补偿，保留局部噪声 Huber 与图恢复。

本文件也提供三组实验共用的评价和绘图函数，以保证仅新增三个 .py 文件。
python ablation/ablation_no_uncertainty.py --all  # 重现六幅图和表5
默认数据是同目录 test.json；完整方法直接调用 ../core_method/UCG.py。
"""
from __future__ import annotations

import argparse
import copy
import gc
import hashlib
import importlib
import json
import math
import platform
import sys
from contextlib import contextmanager, nullcontext
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CORE = ROOT / "core_method"
sys.path.insert(0, str(CORE))
import UCG as full
import feature as base
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe

MIN_SUPPORT = 12
MIN_LENGTH = 0.30
METHODS = [
    ("full", "完整方法", "03_完整方法.png", "(c) Full method"),
    ("no_uncertainty", "移除不确定性校准与稀疏补偿", "04_消融一_无不确定性校准.png", "(d) Without uncertainty calibration"),
    ("no_adaptive_huber", "移除局部噪声自适应Huber", "05_消融二_固定Huber尺度.png", "(e) Fixed Huber scale"),
    ("no_graph", "移除图恢复及跨缺口拼接", "06_消融三_无图恢复.png", "(f) Without gap-bridging recovery"),
]


def configure(args):
    cfg = copy.deepcopy(args)
    cfg.uncertainty_enable = False
    cfg.adaptive_merge_enable = False
    return cfg


def _legacy_fragment_edge(a, b, points, angle_increment, args):
    """与原图边完全相同的门控和代价，仅用旧距离阈值替代校准阈值。

原 --no-uncertainty-enable 未覆盖图边中直接计算的 sigma 项，故须覆盖
此处；否则并未真正移除创新点一。图后验局部噪声质量检验仍保留。
"""
    if b.idx_start < a.idx_start:
        a, b = b, a
    idx_gap = int(b.idx_start - a.idx_end)
    if idx_gap < 0 or idx_gap > int(args.graph_max_index_gap):
        return None
    angle = base.segment_included_angle_deg(a, b)
    if angle > args.graph_angle_deg:
        return None
    gap = base.segment_endpoint_to_endpoint_distance(a, b)
    axis_gap = base.segment_support_axis_distance(a, b)
    r = 0.5 * (np.linalg.norm(base.segment_midpoint(a)) + np.linalg.norm(base.segment_midpoint(b)))
    gap_limit = max(args.graph_gap_scale, 1.0) * full._ORIGINAL_MERGE_GAP_THR(
        r, angle_increment, args.merge_gap0_m, args.merge_cgap)
    perp_limit = max(args.graph_perp_floor_m, full._ORIGINAL_MERGE_PERP_THR(
        r, args.merge_perp_base_m, args.merge_perp_cr)) + 0.75 * gap
    if gap > gap_limit or axis_gap > perp_limit:
        return None
    cost = (args.graph_weight_angle * angle / max(args.graph_angle_deg, 1e-6)
            + args.graph_weight_gap * gap / max(gap_limit, 1e-6)
            + args.graph_weight_perp * axis_gap / max(perp_limit, 1e-6)
            + args.graph_weight_index * idx_gap / max(args.graph_max_index_gap, 1))
    if cost > args.graph_edge_cost_max:
        return None
    return full.FragmentEdge(-1, -1, float(cost), float(angle), float(gap),
                             float(axis_gap), float(perp_limit))


@contextmanager
def ablation_context():
    saved = full._fragment_edge
    full._fragment_edge = _legacy_fragment_edge
    try:
        yield
    finally:
        full._fragment_edge = saved


def build_parser():
    return experiment_parser("no_uncertainty")


def extract_segments(points, args=None):
    cfg = configure(args if args is not None else full.build_parser().parse_args([]))
    # The reference NumPy path honors every scoped replacement; it is shared
    # by all four experimental conditions, including the unchanged full method.
    cfg.native_enable = False
    with ablation_context():
        return full.extract_segments(points, cfg)


def experiment_parser(variant):
    parser = full.build_parser()
    item = next(m for m in METHODS if m[0] == variant)
    parser.description = item[1] + "；共同评价口径为 article3.docx 第2.7.2节"
    parser.set_defaults(input=str(HERE / "test.json"), output_png=str(HERE / "runs" / item[2]), native_enable=False)
    parser.add_argument("--all", action="store_true", help="运行完整方法与三个消融并生成六张PNG和表5")
    parser.add_argument("--output-dir", default=str(HERE / "runs"))
    return parser


def _segment_key(s):
    # IDs and n_points can be changed by deduplication/endpoint merging.
    return (s.p1.tobytes(), s.p2.tobytes(), s.idx_start, s.idx_end,
            float(s.rms), float(s.max_res))


@contextmanager
def trace_support(raw_points):
    """Observe exact original support without modifying geometry or selection.

The optimized implementation refits unique original measurements. Also trace
the union of parent measurement indices independently, so the evaluator never
substitutes internal endpoint residuals for the original point-cloud residuals.
"""
    indices_by_xy = {}
    for i, xy in enumerate(raw_points):
        indices_by_xy.setdefault(tuple(xy), []).append(i)
    support = {}
    original_build = full._ORIGINAL_BUILD_SEGMENT
    original_merge = full.adaptive_try_global_merge_two_segments

    def observe_build(points, *args, **kwargs):
        s = original_build(points, *args, **kwargs)
        ids = set()
        for xy in points:
            ids.update(indices_by_xy.get(tuple(xy), []))
        support[_segment_key(s)] = ids
        return s

    def observe_merge(a, b, args):
        a_ids = support.get(_segment_key(a))
        b_ids = support.get(_segment_key(b))
        result = original_merge(a, b, args)
        if result is not None:
            if a_ids is None or b_ids is None:
                raise AssertionError("Missing parent support provenance")
            support[_segment_key(result[0])] = a_ids | b_ids
        return result

    full._ORIGINAL_BUILD_SEGMENT = observe_build
    full.adaptive_try_global_merge_two_segments = observe_merge
    try:
        yield support
    finally:
        full._ORIGINAL_BUILD_SEGMENT = original_build
        full.adaptive_try_global_merge_two_segments = original_merge


def run_condition(points, args, module=None):
    cfg = copy.deepcopy(args)
    cfg.native_enable = False
    if module is not None:
        cfg = module.configure(cfg)
    context = module.ablation_context() if module is not None else nullcontext()
    full._LAST_DIAGNOSTICS.clear()
    with context, trace_support(points) as support:
        segments, angle = full.extract_segments(points, cfg)
    diagnostics = dict(full._LAST_DIAGNOSTICS)
    kept, rejected = [], []
    for s in segments:
        ids = sorted(support.get(_segment_key(s), []))
        if not ids:
            raise AssertionError("Final segment has no original measurement support")
        item = {"p1": s.p1.tolist(), "p2": s.p2.tolist(), "length_m": float(s.length),
                "support_indices_0based": ids, "unique_support_count": len(ids),
                "reported_n_points": int(s.n_points), "internal_rms": float(s.rms),
                "internal_max_res": float(s.max_res), "idx_start": int(s.idx_start),
                "idx_end": int(s.idx_end), "merged_from": s.merged_from}
        if len(ids) >= MIN_SUPPORT and s.length >= MIN_LENGTH:
            item["id"] = len(kept) + 1
            kept.append(item)
        else:
            rejected.append(item)
    displayed = kept + [s for s in rejected if s["unique_support_count"] >= MIN_SUPPORT]
    result = {"segments": kept, "filtered_out": rejected, "display_segments": displayed,
              "angle_increment_rad": float(angle),
              "diagnostics": diagnostics, "parameters": vars(cfg).copy()}
    if module is not None and hasattr(module, "ablation_details"):
        result["ablation_details"] = module.ablation_details()
    return result


def truth_segments(data, valid_only=True):
    """Only the supplied noise-free generator truth is used, never fitted lines."""
    result = []
    for item in data["truth"]["segments"]:
        if item.get("kind") != "segment" or not item.get("is_target", True):
            continue
        a = np.array([item["p0"]["x"], item["p0"]["y"]], dtype=float)
        b = np.array([item["p1"]["x"], item["p1"]["y"]], dtype=float)
        count = sum(p.get("source_id") == item["id"] and p.get("point_type") in ("inlier", "edge")
                    for p in data["point_labels"])
        length = float(np.linalg.norm(b - a))
        if not valid_only or (length >= MIN_LENGTH and count >= MIN_SUPPORT):
            result.append({"id": int(item["id"]), "name": item["name"],
                           "p1": a.tolist(), "p2": b.tolist(), "support_count": count,
                           "length_m": length})
    return sorted(result, key=lambda g: g["id"])


def pair_geometry(pred, truth):
    p1, p2 = np.array(pred["p1"]), np.array(pred["p2"])
    g1, g2 = np.array(truth["p1"]), np.array(truth["p2"])
    u = (p2 - p1) / np.linalg.norm(p2 - p1)
    v = (g2 - g1) / np.linalg.norm(g2 - g1)
    angle = float(np.degrees(np.arccos(np.clip(abs(u @ v), 0, 1))))
    nu, nv = np.array([-u[1], u[0]]), np.array([-v[1], v[0]])
    perp = float((abs((p1-g1) @ nv) + abs((p2-g1) @ nv)
                  + abs((g1-p1) @ nu) + abs((g2-p1) @ nu)) / 4)
    a, b = sorted([float((p1-g1) @ v), float((p2-g1) @ v)])
    length = np.linalg.norm(g2-g1)
    overlap = max(0.0, min(b, length) - max(a, 0.0))
    iou = float(overlap / (length + b-a-overlap))
    epe = float(min(np.linalg.norm(p1-g1)+np.linalg.norm(p2-g2),
                    np.linalg.norm(p1-g2)+np.linalg.norm(p2-g1)) / 2)
    return {"AE_deg": angle, "normal_distance_m": perp, "IoU": iou, "EPE_m": epe,
            "eligible": angle <= 5.0 and perp <= 0.02 and iou >= 0.5}


def match_segments(predictions, truths):
    """Exact max-cardinality then min-EPE matching; stable ID tie breaking.

Bitmask DP is exact for this six-reference benchmark, unlike greedy matching.
"""
    if len(truths) > 20:
        raise ValueError("This benchmark matcher is limited to 20 reference lines")
    geometry = [[pair_geometry(p, g) for g in truths] for p in predictions]
    states = {0: (0.0, ())}
    for pi in range(len(predictions)):
        new = dict(states)
        for mask, (cost, pairs) in states.items():
            for gi, info in enumerate(geometry[pi]):
                if (mask >> gi) & 1 or not info["eligible"]:
                    continue
                key = mask | (1 << gi)
                value = (cost + info["EPE_m"], tuple(sorted(pairs + ((gi, pi),))))
                if key not in new or value < new[key]:
                    new[key] = value
        states = new
    mask, (_, pairs) = min(states.items(), key=lambda x: (-x[0].bit_count(), x[1][0], x[1][1]))
    return [{"truth_id": truths[gi]["id"], "prediction_id": predictions[pi]["id"],
             **geometry[pi][gi]} for gi, pi in pairs]


def evaluate(result, points, truths):
    segments = result["segments"]
    matches = match_segments(segments, truths)
    assigned = {}
    for s in segments:
        a, b = np.array(s["p1"]), np.array(s["p2"])
        d = (b-a) / np.linalg.norm(b-a)
        n = np.array([-d[1], d[0]])
        for idx in s["support_indices_0based"]:
            # Do not select by residual threshold and do not discard outliers.
            residual = float(abs((points[idx]-a) @ n))
            value = (residual, s["id"])
            if idx not in assigned or value < assigned[idx]:
                assigned[idx] = value
    residuals = np.array([value[0] for value in assigned.values()])
    G, P, T = len(truths), len(segments), len(matches)
    metrics = {"G": G, "P": P, "TP": T, "FP": P-T, "FN": G-T,
               "TruePos_percent": 100*T/G if G else None,
               "FalsePos_percent": 100*(P-T)/G if G else None,
               "RMSE_m": float(np.sqrt(np.mean(residuals**2))) if len(residuals) else None,
               "MaxRes_m": float(np.max(residuals)) if len(residuals) else None,
               "EPE_m": float(np.mean([m["EPE_m"] for m in matches])) if matches else None,
               "AE_deg": float(np.mean([m["AE_deg"] for m in matches])) if matches else None,
               "unique_evaluation_points": len(assigned)}
    result.update(metrics=metrics, matches=matches,
                  residual_assignments=[{"point_index_0based": i, "prediction_id": value[1],
                                         "absolute_residual_m": value[0]}
                                        for i, value in sorted(assigned.items())])
    return metrics


def plot_result(points, segments, path, title, numbered=False):
    """Match feature_points.pdf / feature2.pdf, including physical marker sizes."""
    settings = {"font.family": "Times New Roman", "font.size": 14,
                "axes.labelsize": 24, "xtick.labelsize": 20, "ytick.labelsize": 20,
                "axes.linewidth": 1.1, "figure.facecolor": "white"}
    with plt.rc_context(settings):
        fig, ax = plt.subplots(figsize=(16.8, 9.8), dpi=720)
        ax.set_facecolor("white")
        ax.scatter(points[:, 0], points[:, 1], s=148 if len(points) <= 220 else 112,
                   c="#0b1f5b", edgecolors="#111827", linewidths=1.55,
                   alpha=0.98, zorder=1, label="Raw points", antialiased=True)
        for i, s in enumerate(segments):
            a, b = np.array(s["p1"]), np.array(s["p2"])
            ax.plot([a[0], b[0]], [a[1], b[1]], color="#d26900", linewidth=7.2,
                    alpha=0.98, solid_capstyle="round", zorder=3, antialiased=True,
                    label=("Ideal segments" if numbered else "Extracted segments") if i == 0 else None)
            ax.scatter([a[0], b[0]], [a[1], b[1]], s=90, c="#d26900",
                       edgecolors="#111827", linewidths=1.10, zorder=4)
            if numbered:
                direction = (b-a) / np.linalg.norm(b-a)
                normal = np.array([-direction[1], direction[0]])
                if normal[1] < 0:
                    normal = -normal
                ax.annotate(str(s["id"]), (a+b)/2, xytext=42*normal,
                        textcoords="offset points", color="black", fontsize=26, fontweight="bold",
                        ha="center", va="center", zorder=5,
                        path_effects=[pe.withStroke(linewidth=3.0, foreground="white")])
        ax.set_xlabel("X (m)", fontsize=24, labelpad=10)
        ax.set_ylabel("Y (m)", fontsize=24, labelpad=10)
        ax.set_aspect("equal")
        ax.grid(True, linestyle="--", linewidth=0.8, alpha=0.36, zorder=0)
        ax.tick_params(axis="both", which="major", width=1.1, length=6, labelsize=20)
        for spine in ax.spines.values():
            spine.set_linewidth(1.1)
        # Derive identical limits from the shared raw cloud, as in the references.
        low, high = points.min(axis=0), points.max(axis=0)
        span = np.maximum(high-low, 1e-6)
        ax.set_xlim(low[0]-0.03*span[0], high[0]+0.18*span[0])
        ax.set_ylim(low[1]-0.05*span[1], high[1]+0.05*span[1])
        ax.legend(loc="lower right", bbox_to_anchor=(0.985, 0.06), borderaxespad=0,
                  frameon=True, framealpha=0.94, edgecolor="#d0d0d0", fontsize=24,
                  markerscale=1.45, borderpad=0.56, labelspacing=0.52,
                  handlelength=2.45, handletextpad=0.72)
        fig.text(0.5, 0.025, title.split()[0], ha="center", va="bottom", fontsize=34)
        fig.subplots_adjust(left=0.08, right=0.97, bottom=0.18, top=0.96)
        # Calculate tight bounds first, then release that full-canvas buffer.
        # savefig(bbox_inches='tight') otherwise holds two 720-dpi renderers.
        fig.canvas.draw()
        bounds = fig.get_tightbbox(fig.canvas.get_renderer()).padded(.03).frozen()
        del fig.canvas.renderer
        fig.canvas._lastKey = None
        gc.collect()
        fig.savefig(path, dpi=720, bbox_inches=bounds, facecolor="white")
        plt.close(fig)
        del ax, fig
        gc.collect()  # Release the large 720-dpi Agg buffers before the next panel.


def format_value(value, digits=4):
    return "N/A" if value is None else f"{value:.{digits}f}"


def write_table(results, output, report):
    header = ["方法", "RMSE (m)", "MaxRes (m)", "EPE (m)", "AE (°)"]
    rows = []
    for key, name, _, _ in METHODS:
        m = results[key]["metrics"]
        rows.append([name] + [format_value(m[k], d) for k, d in [
            ("RMSE_m", 6),
            ("MaxRes_m", 6), ("EPE_m", 6), ("AE_deg", 6)]])
    dataset_note = (f"数据：{Path(report['input']).name}，{report['input_points']}个点，"
                    f"{len(report['all_truth_segments'])}条生成真值，其中"
                    f"{len(report['truth_segments'])}条满足论文有效性条件。")
    excluded = "；".join(f"编号{s['id']}：{s['length_m']:.6f} m、{s['support_count']}个支持点"
                         for s in report['excluded_truth_segments'])
    exclusion_note = (f"有效性条件：至少{MIN_SUPPORT}个原始支持点、长度至少{MIN_LENGTH:.2f} m。"
                      + (f"不满足条件的真值为{excluded}，不纳入表5的定量评价；理想图仍展示并编号全部生成真值。"
                         if excluded else "全部生成真值均满足有效性条件。"))
    lines = ["# 表5 三个创新点的消融对比", "", dataset_note, exclusion_note, "",
             "| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    lines.extend("| " + " | ".join(row) + " |" for row in rows)
    lines += ["", "表5仅报告四项误差；检出与匹配明细保存在实验结果.json中。",
              "RMSE和MaxRes对全部有效输出的原始支持点去重后计算，包含未匹配输出和离群支持点，使用普通未加权正交残差。",
              "EPE和AE仅对一对一成功匹配对等权平均。匹配门限为5°、0.02 m和投影IoU≥0.5。", "",
              "| 方法 | 图中拟合段数 | 有效段数 | 成功匹配对数 | 残差点数 |",
              "|---|---:|---:|---:|---:|"]
    for key, name, _, _ in METHODS:
        m = results[key]["metrics"]
        lines.append("| " + " | ".join([name, str(len(results[key]['display_segments']))]
                                      + [str(m[k]) for k in ["P", "TP", "unique_evaluation_points"]]) + " |")
    scope_note = "第三种消融关闭图恢复，并限制局部合并、碎片附着及全局拼接跨越明显支持缺口；它检验跨缺口结构恢复流程，不是仅关闭图优化器的单组件消融。"
    angle = results['full']['angle_increment_rad']
    evidence_note = ("图中展示所有至少含12个原始支持点的可靠拟合段，包括短于0.30 m的线段；表5仍执行0.30 m有效性门限。短片段保存在filtered_out中。"
                     f"四组统一使用角增量{angle:.8g} rad，来源为{report['angle_increment_source']}。")
    lines += ["", scope_note, evidence_note,
              "不同方法的匹配对象和支持点数可能不同，应结合配套明细解释误差；不能以更少支持点带来的残差降低代替结构完整性判断。"]
    (output / "表5_消融对比.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    html_rows = "\n".join("<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>" for row in rows)
    html = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>表5 三个创新点的消融对比</title>'
    html += '<style>body{font:16px "Microsoft YaHei",sans-serif;max-width:1200px;margin:48px auto;color:#182333;padding:0 24px}h1{font-size:26px}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th{background:#233b59;color:white}th,td{padding:14px 12px;border:1px solid #d9dfe7;text-align:right}th:first-child,td:first-child{text-align:left}tr:nth-child(even){background:#f2f5f8}p{line-height:1.8;color:#415268}</style>'
    html += '<h1>表5 三个创新点的消融对比</h1><p>' + dataset_note + '</p><p>' + exclusion_note + '</p><table><thead><tr>'
    html += ''.join(f'<th>{s}</th>' for s in header) + '</tr></thead><tbody>' + html_rows + '</tbody></table>'
    html += '<p>RMSE和MaxRes采用全部有效输出的原始支持点，去重后计算未加权正交残差；EPE和AE仅对一对一匹配线段计算。结构与匹配明细保存在实验结果.json中。</p>'
    html += '<p>' + scope_note + '</p><p>' + evidence_note + '</p></html>'
    (output / "表5_消融对比.html").write_text(html, encoding="utf-8")


def main_for(variant, argv=None):
    args = experiment_parser(variant).parse_args(argv)
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    # Match UCG.py's CLI input handling; do not infer beam spacing
    # from this benchmark's groupwise rather than angular ordering.
    angle_source = "command_line"
    if args.angle_increment is None:
        args.angle_increment = data.get("metadata", {}).get("recommended_angle_increment_rad")
        angle_source = "metadata.recommended_angle_increment_rad" if args.angle_increment is not None else "estimated_from_points"
    points = np.array([[p["x"], p["y"]] for p in data["points"]], dtype=np.float64)
    assert len(points) == len(data["point_labels"])
    assert np.array_equal(points, np.array([[p["x"], p["y"]] for p in data["point_labels"]]))
    modules = {key: importlib.import_module("ablation_" + key) for key, _, _, _ in METHODS[1:]}
    selected = METHODS if args.all else [item for item in METHODS if item[0] == variant]
    # Run extraction using ONLY measurement coordinates and public parameters.
    results = {}
    for key, name, filename, title in selected:
        result = run_condition(points, args, modules.get(key))
        results[key] = result
        plot_result(points, result["display_segments"], output/filename if args.all else Path(args.output_png), title)
    # Reference labels and coordinates enter only the evaluator and ideal plot.
    truths = truth_segments(data)
    for key, name, _, _ in selected:
        metrics = evaluate(results[key], points, truths)
        print(name + ": " + json.dumps(metrics, ensure_ascii=False))
    report = {"input": str(Path(args.input).resolve()),
              "input_points": len(points), "angle_increment_source": angle_source,
              "input_sha256": hashlib.sha256(Path(args.input).read_bytes()).hexdigest(),
              "source_sha256": {p: hashlib.sha256((CORE/p).read_bytes()).hexdigest() for p in
                                ["UCG.py", "feature.py", "feature_tour_batch.py", "feature_tour_native.py"]},
              "environment": {"python": sys.version, "platform": platform.platform(), "numpy": np.__version__},
              "protocol": {"min_unique_support_points": MIN_SUPPORT, "min_length_m": MIN_LENGTH,
                           "angle_deg_max": 5, "normal_distance_m_max": .02, "projection_iou_min": .5,
                           "backend": "NumPy for all conditions; same geometry as reference implementation",
                           "matching": "max cardinality, then minimum total EPE, then fixed truth/prediction IDs",
                           "residuals": "unique original support points, unweighted; smallest residual wins duplicates"},
              "all_truth_segments": truth_segments(data, valid_only=False),
              "excluded_truth_segments": [s for s in truth_segments(data, valid_only=False)
                                          if s["id"] not in {g["id"] for g in truths}],
              "truth_segments": truths, "results": results}
    name = "实验结果.json" if args.all else variant + "_结果.json"
    (output/name).write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    if args.all:
        plot_result(points, [], output/"01_原始点云.png", "(a) Original point cloud")
        plot_result(points, report['all_truth_segments'], output/"02_标准理想线段_编号.png", "(b) Numbered ideal segments", numbered=True)
        write_table(results, output, report)
    return report


if __name__ == "__main__":
    main_for("no_uncertainty")
