#!/usr/bin/env python3
"""创新点三相关流程消融：关闭图恢复，并禁止其余合并路径跨越明显支持缺口。

只关闭图开关时，局部合并和全局拼接仍会恢复同一断裂结构。本版本保留
连续支持内的合并，对所有位置统一检查量测支持的投影间隙；不使用真值、
区域坐标或指定输出段数。它是跨缺口恢复流程消融，不是图优化器单独消融。
"""
import copy
from contextlib import contextmanager
import numpy as np
import ablation_no_uncertainty as common

SUPPORT_GAP_SPACING_FACTOR = 3.0
_LAST_GAP_AUDIT = []


def configure(args):
    cfg = copy.deepcopy(args)
    cfg.graph_recovery_enable = False
    return cfg


def support_break(segment, points, angle_increment, args):
    """Find a significant empty interval on the proposal's measured support.

    The calibrated perpendicular band is ONLY a connectivity test. It never
    removes measurements from fitting or from the common residual evaluator.
    Requiring both the calibrated gap and 3x median spacing prevents ordinary
    nonuniform sampling and single missing returns being treated as breaks.
    """
    if segment.length <= 0:
        return None
    lo, hi = segment.idx_start, segment.idx_end
    if lo < 0 or hi >= len(points) or hi <= lo:
        raise ValueError("Merge support indices are outside the preprocessed scan")
    support = points[lo:hi + 1]
    direction = (segment.p2 - segment.p1) / segment.length
    normal = np.array([-direction[1], direction[0]])
    r = float(np.median(np.linalg.norm(support, axis=1)))
    band = common.full.uncertainty_merge_perp_thr_m(
        r, args.merge_perp_base_m, args.merge_perp_cr)
    in_band = np.abs((support - segment.p1) @ normal) <= band
    support = support[in_band]
    if len(support) < 2:
        return None  # Existing geometry/quality checks retain responsibility.
    order = np.argsort((support - segment.p1) @ direction, kind="stable")
    support = support[order]
    steps = np.diff((support - segment.p1) @ direction)
    positive = steps[steps > 1e-9]
    if not len(positive):
        return None
    typical = float(np.median(positive))
    for i, gap in enumerate(steps):
        r = 0.5 * (np.linalg.norm(support[i]) + np.linalg.norm(support[i + 1]))
        calibrated = common.full.uncertainty_gap_thr_m(
            r, angle_increment, args.gap0_m, args.cgap)
        limit = max(calibrated, SUPPORT_GAP_SPACING_FACTOR * typical)
        if gap > limit:
            return {"support_index_span": [int(lo), int(hi)],
                    "gap_endpoints": support[i:i + 2].tolist(),
                    "projected_gap_m": float(gap), "gap_limit_m": float(limit),
                    "median_spacing_m": typical, "calibrated_gap_m": float(calibrated),
                    "connectivity_band_m": float(band)}
    return None


@contextmanager
def ablation_context():
    """Guard both merge APIs, including attachment and both stitching passes."""
    base, full = common.base, common.full
    original_extract = base.extract_all_candidates
    original_local = full._try_local_merge
    original_global = full.adaptive_try_global_merge_two_segments
    scan = {}
    _LAST_GAP_AUDIT.clear()

    def capture_scan(points, angle, args):
        scan.update(points=points, angle=angle)
        return original_extract(points, angle, args)

    def rejected(proposal, args, stage):
        info = support_break(proposal, scan["points"], scan["angle"], args)
        if info is None:
            return False
        _LAST_GAP_AUDIT.append({"stage": stage, **info})
        key = "support_gap_" + stage + "_rejections"
        full._LAST_DIAGNOSTICS[key] = full._LAST_DIAGNOSTICS.get(key, 0.0) + 1.0
        return True

    def local_merge(a, b, points, angle, args):
        proposal = original_local(a, b, points, angle, args)
        if proposal is not None and rejected(proposal, args, "local"):
            return None
        return proposal

    def global_merge(a, b, args):
        result = original_global(a, b, args)
        if result is not None and rejected(result[0], args, "global"):
            return None
        return result

    base.extract_all_candidates = capture_scan
    full._try_local_merge = local_merge
    full.adaptive_try_global_merge_two_segments = global_merge
    try:
        yield
    finally:
        base.extract_all_candidates = original_extract
        full._try_local_merge = original_local
        full.adaptive_try_global_merge_two_segments = original_global


def ablation_details():
    return {"scope": "graph recovery off; support-gap guards on local and global merge APIs",
            "spacing_factor": SUPPORT_GAP_SPACING_FACTOR,
            "rejected_merge_attempts": copy.deepcopy(_LAST_GAP_AUDIT)}


def build_parser():
    return common.experiment_parser("no_graph")


def extract_segments(points, args=None):
    cfg = configure(args if args is not None else common.full.build_parser().parse_args([]))
    cfg.native_enable = False
    with ablation_context():
        return common.full.extract_segments(points, cfg)


if __name__ == "__main__":
    common.main_for("no_graph")
