#!/usr/bin/env python3
"""创新点二消融：保留TLS与Huber，只将局部自适应转折点改为固定0.02 m。

不替换为OLS，也不关闭预处理、校准阈值、图恢复或全局拼接。
"""
import copy
from contextlib import nullcontext
import ablation_no_uncertainty as common


def configure(args):
    cfg = copy.deepcopy(args)
    cfg.adaptive_huber_enable = False
    return cfg


def ablation_context():
    return nullcontext()


def build_parser():
    return common.experiment_parser("no_adaptive_huber")


def extract_segments(points, args=None):
    cfg = configure(args if args is not None else common.full.build_parser().parse_args([]))
    cfg.native_enable = False
    return common.full.extract_segments(points, cfg)


if __name__ == "__main__":
    common.main_for("no_adaptive_huber")
