# UCG-LineFit

UCG-LineFit extracts line segments from 2D LiDAR point clouds using sensor-uncertainty calibration, locally adaptive Huber fitting, and graph-based fragment recovery.

## Resources

```text
UCG-LineFit/
  core_method/
    UCG.py                       # Main algorithm, copied from feature_tour.py
    feature.py                   # Required geometry, I/O and plotting routines
    feature_tour_batch.py         # Required batch-fitting helper
    feature_tour_native.py        # Optional acceleration backend wrapper
    Algorithm_Parameters.docx     # All 148 CLI defaults in three-line tables
  datasets/
    Lab/                         # Lab_points.json, Lab_points.png, single_frame.json
    map_points.json              # Single-frame real-world scan, 1,166 points
    test.json                    # Synthetic stress scene, 167 points
  ablation/
    ablation_no_uncertainty.py    # Calibration/sparsity ablation and shared evaluator
    ablation_no_adaptive_huber.py # Fixed Huber scale ablation
    ablation_no_graph.py          # Gap-bridging recovery ablation
    test.json                    # Exact copy of datasets/test.json
    latest_records/              # Original records from 2026-10-11
  README.md
```

`Lab_points.json` contains 2,532 points. `Lab/single_frame.json` and `map_points.json` are identical. Keep the four Python files in `core_method` together.

## Setup and use

Python 3.10+ is recommended; the release was checked with Python 3.12, NumPy 2.4.4 and Matplotlib 3.10.9.

```bash
python -m pip install numpy matplotlib
```

Run these commands from the `UCG-LineFit` directory:

```bash
python core_method/UCG.py --input datasets/map_points.json --output-png real_result.png --no-native-enable
python core_method/UCG.py --input datasets/test.json --output-png synthetic_result.png --no-native-enable
python core_method/UCG.py --input datasets/Lab/Lab_points.json --output-png lab_result.png --no-native-enable
python core_method/UCG.py --help
```

Each run saves the fitted-line image and a `points.png` image alongside it, and prints segment statistics, runtime and diagnostics. Runs in the same output directory overwrite `points.png`; create the output directory first when specifying a new directory.

Input JSON must contain `{"points": [{"x": 0.0, "y": 0.0}, ...]}` with coordinates in metres. Preserve scan order. The CLI uses an explicit `--angle-increment` (radians), otherwise a supported metadata hint, otherwise an estimate from the points. The supplied synthetic scene specifies `0.0098` rad in metadata.

To change a parameter, append its CLI option, for example `--min-len-m 0.30`. Boolean options accept `--name` / `--no-name`. The Word document lists the effective defaults, including inherited parameters. Always specify `--input` when running from the release root.

For optional Numba acceleration, install `numba scipy` and omit `--no-native-enable`. Without these optional packages, the backend falls back to NumPy; initial compilation time is reported separately.

Python API example, also run from the release root:

```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path("core_method").resolve()))
import UCG

path = Path("datasets/test.json")
args = UCG.build_parser().parse_args(["--no-native-enable"])
args.angle_increment = UCG.base.load_angle_increment_hint(path)
points = UCG.base.load_points(path)
segments, angle_increment = UCG.extract_segments(points, args)
for segment in segments:
    print(segment.p1, segment.p2, segment.length)
```

The API returns `Segment` objects and the angle increment; the CLI does not export segment JSON. Call the API sequentially because extraction temporarily replaces module-level functions.

## Ablation experiments

```bash
python ablation/ablation_no_uncertainty.py --all
python ablation/ablation_no_adaptive_huber.py
python ablation/ablation_no_graph.py
```

The default input is `ablation/test.json`. Results go to `ablation/runs/`; `--all` runs the full method and all three ablations, producing six PNGs, a JSON report and a Markdown/HTML comparison. Original records remain in `latest_records/`: the comparison table, detailed results, validation record, dataset-design audit and gap-recovery scope note. Historical paths and `feature_tour.py` in those records refer to the original workspace; `UCG.py` is a byte-identical renamed copy. Only imports and file paths in the shared ablation script were adapted for this layout.

All conditions use NumPy and the same evaluation protocol: at least 12 original support points and 0.30 m length; matching requires angle ≤5°, normal distance ≤0.02 m and projection IoU ≥0.5. The third ablation disables graph recovery and restricts gap bridging in other merge stages, so it evaluates the broader recovery pipeline.

The synthetic scene was selected after examining 316 candidate configurations to illustrate specific mechanism differences. It is not an independent unbiased benchmark. Preserve this context when reporting its results. The archived records contain design details and support/matching counts needed to interpret the errors.
