# Reproduction Data

- `parameter_list.docx`: Complete default parameters of `sensitivity_experiment/feature.py`.

## Intel_data_experiment

- `feature.py`: UCG LineFit implementation for the Intel dataset.
- `iepf.py`, `ransac.py`, `srg.py`: IEPF, RANSAC, and SRG comparison methods.
- `inter.json`: Two Intel scans arranged side by side for visualization.
- `fig9_new.pdf`: Intel line extraction comparison figure.
- `line_segment_mark/data/*.json`: Intel scan data, reference segments, algorithm predictions, and evaluation records.
- `line_segment_mark/*.pdf`: Intel scan annotation figures.

## Self_test_experiment

- `feature.py`: UCG LineFit implementation for the R2000 dataset.
- `iepf.py`, `ransac.py`, `srg.py`: IEPF, RANSAC, and SRG comparison methods.
- `Corridor/`, `Hall/`, `Office/`: ROS 2 scan recordings in `.db3` files and recording metadata in `metadata.yaml`.
- `data/*.json`: Individual corridor, hall, and office scans with acquisition metadata.
- `Lab/single_frame.json`: A laboratory point cloud frame.
- `line_segment_mark/`: Annotated scan JSON files and corresponding PDF figures.

## error_calibration

- `Inter/analyze_inter.py`: Entry script for the Intel calibration analysis.
- `Inter/config.json`: Intel calibration and sensitivity analysis settings.
- `Inter/reproducibility.zip`: Archived calibration scripts, analysis data, configurations, and results.
- `Inter/result.txt`: Intel calibration results.
- `Inter/model_diagnostics.png`: Intel noise model diagnostic plots.
- `Inter/extraction_sensitivity.png`: Line extraction sensitivity to the Intel noise scale.
- `R2000/result.txt`: R2000 calibration results.
- `R2000/short/`, `R2000/middle/`, `R2000/far/`: Calibration recordings at three distances, with `.db3` scan data and `metadata.yaml` recording metadata.

## ablation_experiment

- `ablation_no_uncertainty.py`: Distance heuristic ablation and shared evaluation code.
- `ablation_no_adaptive_huber.py`: Ablation using a fixed Huber transition value.
- `ablation_no_graph.py`: Ablation with graph recovery disabled.
- `selected_frames/*.json`: Selected scans with reference annotations and evaluation records.
- `ablation_d.pdf`, `ablation_e.pdf`, `ablation_f.pdf`: Figures for the uncertainty, adaptive Huber, and graph recovery ablations.
- `ablation_combined.pdf`: Combined ablation figure.

## sensitivity_experiment

- `feature.py`: UCG LineFit implementation with the default sensitivity experiment parameters.
- `ablation_no_graph.py`: Direction gate sensitivity and graph recovery ablation experiments.
- `selected_frames/*.json`: Selected scans with reference annotations and evaluation records.
- `Intel_fragment_candidates/*.json`: Intel scans selected for fragment recovery inspection.
- `Intel_fragment_candidates/*.pdf`: Corresponding fragment recovery inspection figures.
- `fig13_sensitivity_confidence.pdf`: Sensitivity to the Gaussian quantile parameter.
- `fig14_sensitivity_huber_gain.pdf`: Sensitivity to the local noise scale gain.
- `fig15_sensitivity_graph_angle.pdf`: Sensitivity to the graph direction gate.
- `fig15_preview.pdf`: Preview of the updated direction gate experiment.
