#!/usr/bin/env python3
"""(e) TLS + Huber IRLS with a fixed 0.02 m transition; other stages retained.

python ablation_no_adaptive_huber.py --input selected_frames/inter1.json
python ablation_no_adaptive_huber.py --all
"""
import sys
sys.dont_write_bytecode=True
import copy
from contextlib import nullcontext
import ablation_no_uncertainty as common

def configure(args):
    cfg=copy.deepcopy(args)
    cfg.adaptive_huber_enable=False
    cfg.huber_delta=.02
    return cfg

def ablation_context(raw_points=None): return nullcontext()

def extract_segments(points,args=None):
    cfg=configure(args if args is not None else common.full.build_parser().parse_args([]))
    cfg.native_enable=False
    return common.full.extract_segments(points,cfg)

if __name__=='__main__': common.main_for('e')
