#!/usr/bin/env python3
"""(f) Graph recovery disabled; all existing merge and fitting stages retained.

python ablation_no_graph.py --input selected_frames/inter1.json
python ablation_no_graph.py --all
"""
import sys
sys.dont_write_bytecode=True
import copy
from contextlib import nullcontext
import ablation_no_uncertainty as common

def configure(args):
    cfg=copy.deepcopy(args)
    cfg.graph_recovery_enable=False
    return cfg

def ablation_context(raw_points=None): return nullcontext()

def extract_segments(points,args=None):
    cfg=configure(args if args is not None else common.full.build_parser().parse_args([]))
    cfg.native_enable=False
    return common.full.extract_segments(points,cfg)

if __name__=='__main__': common.main_for('f')
