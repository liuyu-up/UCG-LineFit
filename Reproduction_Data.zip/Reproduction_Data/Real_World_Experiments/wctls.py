# -*- coding: utf-8 -*-
"""WCTLS (Prieto-Fernandez et al., CMES 2026), independent paper reproduction.

Reference: https://doi.org/10.32604/cmes.2026.080540
The characteristic point Q follows WCLM (2023), Eqs. (17)-(21), and the
normalized line and covariance follow WCTLS (2026), Eqs. (16)-(25).
This is the published conformal estimator, NOT a generic weighted PCA fit.

Pipeline: per-scan IEPF -> optional adjacent TLS partition refinement ->
WCLM Q -> WCTLS normalization -> line and corner covariance.

Implementation details:
* The IEPF and adjacent-refinement residual thresholds are in metres.
  A zero adjacent-refinement threshold disables merging.
* The final size filters use a minimum support count and length.
* finite endpoints are extrema of support projections onto the fitted line;
* inter.json display translations are undone before fitting each scan;
* default noise values are S1 values reported by the paper interpreted as
  standard deviations for an illustrative covariance, NOT Intel calibration.
  Constant sigma values cancel from geometric weights, but affect covariance.
* IEPF children share the split point. Corner output includes both the paper's
  independent-line covariance and a supplementary shared-support covariance.

Only numpy and matplotlib are required. Existing source files are not imported.
Run: python wctls.py --input inter.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
PAPER_DOI = "10.32604/cmes.2026.080540"
WCLM_DOI = "10.1109/TIM.2023.3284143"
VERSION = "1.0.0"

plt.rcParams.update({
    "font.family": "Times New Roman", "font.size": 11,
    "axes.labelsize": 12, "axes.titlesize": 14, "legend.fontsize": 10,
    "xtick.labelsize": 10, "ytick.labelsize": 10,
    "svg.fonttype": "path", "pdf.fonttype": 42,
})


@dataclass(frozen=True)
class Parameters:
    iepf_threshold: float = 0.063
    merge_max_residual: float = 0.045
    merge_angle_deg: float = 8.0
    min_line_points: int = 12
    min_line_length: float = 0.30
    sigma_range: float = 0.05
    sigma_angle_rad: float = math.radians(0.391)
    max_condition: float = 1e12
    corner_sine_min: float = 1e-8

    def validate(self) -> None:
        values = asdict(self)
        if not all(np.isfinite(v) for v in values.values()):
            raise ValueError("All parameters must be finite")
        if self.merge_max_residual < 0 or not 0 <= self.merge_angle_deg <= 90:
            raise ValueError("Invalid adjacent-refinement limits")
        if self.iepf_threshold <= 0 or self.min_line_points < 2:
            raise ValueError("Require iepf-threshold > 0 and min-line-points >= 2")
        if self.min_line_length < 0 or min(self.sigma_range, self.sigma_angle_rad) <= 0:
            raise ValueError("Require min-line-length >= 0 and positive noise standard deviations")
        if self.max_condition <= 1 or not 0 < self.corner_sine_min < 1:
            raise ValueError("Invalid numerical conditioning limits")


@dataclass
class LineFit:
    q: np.ndarray
    coefficients: np.ndarray
    covariance_q: np.ndarray
    covariance: np.ndarray
    jacobian_polar: np.ndarray  # 3 x (2N), columns rho_0, theta_0, ...
    relative_weights: np.ndarray
    condition_number: float
    p0: np.ndarray
    p1: np.ndarray
    rms: float
    max_residual: float
    length: float
    straightness: float


@dataclass
class FittedSegment:
    line_id: int
    frame_id: int
    leaf_index: int
    point_indices: np.ndarray
    p0: np.ndarray
    p1: np.ndarray
    coefficients_global: np.ndarray
    covariance_global: np.ndarray
    display_shift: np.ndarray
    fit: LineFit


def load_input(path: Path) -> tuple[np.ndarray, list[dict], dict]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or not isinstance(data.get("points"), list):
        raise ValueError("Expected a JSON object with a points list")
    points = np.asarray([[float(p["x"]), float(p["y"])] for p in data["points"]])
    if points.ndim != 2 or points.shape[1] != 2 or len(points) < 2:
        raise ValueError("At least two 2D points are required")
    if not np.isfinite(points).all():
        raise ValueError("Nonfinite input; clean invalid returns explicitly before evaluation")
    metadata = data.get("metadata", {})
    raw_frames = metadata.get("frames", [])
    if not raw_frames:
        return points, [{"frame_id": 1, "start": 0, "count": len(points),
                         "shift": np.zeros(2), "source_scan_index": None}], metadata
    frames, covered, ids = [], np.zeros(len(points), dtype=int), set()
    for item in raw_frames:
        start, count = int(item["point_start"]), int(item["point_count"])
        frame_id = int(item["frame_id"])
        if start < 0 or count < 2 or start + count > len(points) or frame_id in ids:
            raise ValueError("Invalid, repeated or out-of-range frame metadata")
        ids.add(frame_id)
        center = np.array([item["source_center"]["x"], item["source_center"]["y"]], float)
        offset = np.array([item["layout_offset"]["x"], item["layout_offset"]["y"]], float)
        if not np.isfinite(np.r_[center, offset]).all():
            raise ValueError("Nonfinite frame translation")
        covered[start:start + count] += 1
        frames.append({"frame_id": frame_id, "start": start, "count": count,
                       "shift": offset - center,
                       "source_scan_index": item.get("source_scan_index")})
        local = points[start:start + count] - (offset - center)
        for p, xy in zip(data["points"][start:start + count], local):
            if "range_m" in p and not np.isclose(np.linalg.norm(xy), p["range_m"], atol=1e-9, rtol=1e-9):
                raise ValueError("Frame transform disagrees with the stored range_m")
    if not np.all(covered == 1):
        raise ValueError("Frame metadata must cover every point exactly once")
    return points, frames, metadata


def iepf_partition(points: np.ndarray, threshold: float) -> list[tuple[int, int]]:
    """Classical endpoint-line IEPF; shared split point, no merging/gap heuristics.

    Iterative stack avoids recursion-depth failure. Size filtering happens after
    the geometric partition, not during recursion. Output intervals are inclusive.
    """
    if threshold <= 0:
        raise ValueError("IEPF threshold must be positive")
    if len(points) < 2:
        return []
    leaves, stack = [], [(0, len(points) - 1)]
    while stack:
        lo, hi = stack.pop()
        if hi - lo <= 1:
            leaves.append((lo, hi))
            continue
        delta = points[hi] - points[lo]
        length = np.linalg.norm(delta)
        interior = points[lo + 1:hi] - points[lo]
        if length <= 1e-12:
            distances = np.linalg.norm(interior, axis=1)
        else:
            normal = np.array([-delta[1], delta[0]]) / length
            distances = np.abs(interior @ normal)
        pivot = int(np.argmax(distances))
        if distances[pivot] > threshold:
            mid = lo + 1 + pivot
            stack.extend([(mid, hi), (lo, mid)])
        else:
            leaves.append((lo, hi))
    return leaves



def refine_adjacent_intervals(points, intervals, max_residual, angle_deg=8.0):
    """Bidirectional scan-adjacent TLS checks; reference annotations are unused."""
    if max_residual <= 0 or len(intervals)<2:
        return list(intervals)
    cache={}
    def fit(lo,hi):
        key=(lo,hi)
        if key not in cache:
            p=points[lo:hi+1]; centered=p-p.mean(axis=0)
            _,vectors=np.linalg.eigh(centered.T@centered)
            d=vectors[:,-1]; n=np.array([-d[1],d[0]])
            residual=centered@n
            cache[key]=(d,float(np.max(np.abs(residual))),float(residual@residual))
        return cache[key]
    def sweep(order):
        out=[]
        for lo,hi in order:
            if out:
                a,b=out[-1]
                if max(a,lo)<=min(b,hi)+1:
                    d1,_,_=fit(a,b);d2,_,_=fit(lo,hi)
                    angle=np.degrees(np.arccos(np.clip(abs(d1@d2),0.,1.)))
                    start,end=min(a,lo),max(b,hi)
                    if angle<=angle_deg and fit(start,end)[1]<=max_residual:
                        out[-1]=(start,end)
                        continue
            out.append((lo,hi))
        return sorted(out)
    forward=sweep(intervals)
    backward=sweep(reversed(intervals))
    # Prefer fewer admissible fragments; use total TLS SSE to break ties.
    def score(parts):
        return len(parts),sum(fit(lo,hi)[2] for lo,hi in parts),parts
    return min((forward,backward),key=score)


def normalize_q(q: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """WCTLS Eqs. (19)-(23), c > 0 in the SENSOR frame."""
    qx, qy = q
    norm = np.linalg.norm(q)
    if not np.isfinite(norm) or norm <= 1e-14:
        raise ValueError("Degenerate conformal Q")
    coefficients = np.array([-qx, qy, 1.0]) / norm
    jacobian = np.array([[-qy*qy, qx*qy], [-qx*qy, qx*qx], [-qx, -qy]]) / norm**3
    return coefficients, jacobian


def fit_wctls(points: np.ndarray, params: Parameters = Parameters()) -> LineFit:
    """Published Q estimator plus analytic first-order polar covariance.

    WCLM Eqs. (18),(19) can be evaluated stably by solving
       A Q = b, A = B.T W B, b = B.T W 1, B_i = [x_i, -y_i].
    W_i = 1/(sigma_r * rho_i * sigma_theta)^2 (WCTLS Eq. 8).
    A common scale on W cancels. We differentiate the full rho-dependent
    weights, rather than incorrectly holding them fixed in the covariance.
    For z_i = B_i, dz_i/dtheta = [-y_i, -x_i], e_i = 1 - z_i Q:
       dQ/drho_i = A^-1 (-w_i z_i/rho_i)
       dQ/dtheta_i = A^-1 w_i (dz_i e_i - z_i (dz_i Q)).
    These are derivatives of WCLM Eqs. (18),(19), used in its Eq. (21).
    """
    params.validate()
    points = np.asarray(points, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2 or len(points) < 2 or not np.isfinite(points).all():
        raise ValueError("fit_wctls expects at least two finite 2D sensor-frame points")
    ranges = np.linalg.norm(points, axis=1)
    if np.min(ranges) <= 1e-12:
        raise ValueError("Conformal inversion requires nonzero sensor range")
    # Equal sigma_r, sigma_theta for this scan: their common factor cancels.
    weights = (np.min(ranges) / ranges)**2
    design = points * np.array([1.0, -1.0])
    normal_matrix = design.T @ (weights[:, None] * design)
    eigenvalues = np.linalg.eigvalsh(normal_matrix)
    if eigenvalues[0] <= 0:
        raise ValueError("Singular conformal fit (e.g. a line through the sensor origin)")
    condition = float(eigenvalues[-1] / eigenvalues[0])
    if condition > params.max_condition:
        raise ValueError(f"Ill-conditioned conformal fit: condition={condition:.6g}")
    q = np.linalg.solve(normal_matrix, design.T @ weights)
    coefficients, jac_normalize = normalize_q(q)
    error = 1.0 - design @ q
    dtheta_design = np.column_stack((-points[:, 1], -points[:, 0]))
    rhs_rho = -weights[:, None] * design / ranges[:, None]
    rhs_theta = weights[:, None] * (
        dtheta_design * error[:, None] - design * (dtheta_design @ q)[:, None])
    dq_rho = np.linalg.solve(normal_matrix, rhs_rho.T)
    dq_theta = np.linalg.solve(normal_matrix, rhs_theta.T)
    covariance_q = (params.sigma_range**2 * dq_rho @ dq_rho.T
                    + params.sigma_angle_rad**2 * dq_theta @ dq_theta.T)
    covariance = jac_normalize @ covariance_q @ jac_normalize.T
    covariance = (covariance + covariance.T) / 2
    jac_polar = np.empty((3, 2 * len(points)))
    jac_polar[:, 0::2] = jac_normalize @ dq_rho
    jac_polar[:, 1::2] = jac_normalize @ dq_theta
    normal = coefficients[:2]
    direction = np.array([-normal[1], normal[0]])
    if np.dot(points[-1] - points[0], direction) < 0:
        direction *= -1
    foot = -coefficients[2] * normal
    projected = points @ direction
    p0, p1 = foot + projected.min() * direction, foot + projected.max() * direction
    residuals = points @ normal + coefficients[2]
    centered = points - points.mean(axis=0)
    scatter_eigenvalues = np.maximum(np.linalg.eigvalsh(centered.T @ centered), 0)
    total = float(scatter_eigenvalues.sum())
    return LineFit(q, coefficients, covariance_q, covariance, jac_polar, weights, condition,
                   p0, p1, float(np.sqrt(np.mean(residuals**2))),
                   float(np.max(np.abs(residuals))), float(np.linalg.norm(p1 - p0)),
                   float(scatter_eigenvalues[-1] / total) if total else 0.0)


def line_intersection(first: np.ndarray, second: np.ndarray,
                      sine_min: float = 1e-8) -> tuple[np.ndarray, np.ndarray]:
    """WCTLS Eqs. (24),(25) and 2x6 Jacobian via implicit differentiation."""
    matrix = np.array([first[:2], second[:2]])
    if abs(np.linalg.det(matrix)) <= sine_min:
        raise ValueError("Parallel/near-parallel adjacent lines")
    corner = np.linalg.solve(matrix, -np.array([first[2], second[2]]))
    rhs = np.zeros((2, 6))
    rhs[0, :3] = -np.r_[corner, 1.0]
    rhs[1, 3:] = -np.r_[corner, 1.0]
    return corner, np.linalg.solve(matrix, rhs)


def extract_segments(points: np.ndarray, frames: list[dict], params: Parameters
                     ) -> tuple[list[FittedSegment], list[dict], list[dict]]:
    params.validate()
    segments, corners, diagnostics = [], [], []
    variances = np.array([params.sigma_range**2, params.sigma_angle_rad**2])
    for frame in frames:
        start, count, shift = frame["start"], frame["count"], np.asarray(frame["shift"])
        local = points[start:start + count] - shift
        leaves = iepf_partition(local, params.iepf_threshold)
        leaves = refine_adjacent_intervals(local, leaves, params.merge_max_residual, params.merge_angle_deg)
        accepted, rejected = [], []
        transform = np.eye(3)
        transform[2, :2] = -shift
        for leaf_index, (lo, hi) in enumerate(leaves):
            reason = None
            if hi - lo + 1 < params.min_line_points:
                reason = "min_line_points"
            else:
                try:
                    fit = fit_wctls(local[lo:hi + 1], params)
                    if fit.length < params.min_line_length:
                        reason = "min_line_length"
                except ValueError as exc:
                    reason = str(exc)
            if reason:
                rejected.append({"leaf_index": leaf_index, "point_start": lo + start,
                                 "point_end": hi + start, "reason": reason})
                continue
            segment = FittedSegment(len(segments) + 1, frame["frame_id"], leaf_index,
                                    np.arange(start + lo, start + hi + 1), fit.p0 + shift,
                                    fit.p1 + shift, transform @ fit.coefficients,
                                    transform @ fit.covariance @ transform.T, shift, fit)
            segments.append(segment)
            accepted.append(segment)
        skipped_corners = []
        for left, right in zip(accepted, accepted[1:]):
            try:
                corner, jac = line_intersection(left.fit.coefficients, right.fit.coefficients,
                                                params.corner_sine_min)
            except ValueError as exc:
                skipped_corners.append({"line_ids": [left.line_id, right.line_id], "reason": str(exc)})
                continue
            block = np.zeros((6, 6))
            block[:3, :3], block[3:, 3:] = left.fit.covariance, right.fit.covariance
            independent_cov = jac @ block @ jac.T
            shared, li, ri = np.intersect1d(left.point_indices, right.point_indices, return_indices=True)
            cross = np.zeros((3, 3))
            for i, j in zip(li, ri):
                jl = left.fit.jacobian_polar[:, 2*i:2*i + 2]
                jr = right.fit.jacobian_polar[:, 2*j:2*j + 2]
                cross += (jl * variances) @ jr.T
            block[:3, 3:], block[3:, :3] = cross, cross.T
            joint_cov = jac @ block @ jac.T
            independent_cov = (independent_cov + independent_cov.T) / 2
            joint_cov = (joint_cov + joint_cov.T) / 2
            corners.append({
                "corner_id": len(corners) + 1, "frame_id": frame["frame_id"],
                "line_ids": [left.line_id, right.line_id], "xy_local": corner.tolist(),
                "xy_global": (corner + shift).tolist(),
                "covariance_paper_independent_lines": independent_cov.tolist(),
                "covariance_with_shared_support": joint_cov.tolist(),
                "std_xy_paper_m": np.sqrt(np.maximum(np.diag(independent_cov), 0)).tolist(),
                "one_sigma_ellipse_area_paper_m2": float(np.pi * np.sqrt(max(np.linalg.det(independent_cov), 0))),
                "shared_support_points": shared.tolist(),
                "discarded_leaves_between": right.leaf_index - left.leaf_index - 1,
                "interpretation": "adjacent retained support-line intersection; not a ground-truth corner",
            })
        diagnostics.append({"frame_id": frame["frame_id"], "point_count": count,
                            "source_scan_index": frame["source_scan_index"],
                            "iepf_leaf_count": len(leaves), "accepted_segments": len(accepted),
                            "rejected_leaves": rejected, "skipped_corner_pairs": skipped_corners})
    return segments, corners, diagnostics


def plot_segments(points: np.ndarray, segments: list[FittedSegment], out_path: Path,
                  show_segments: bool = True,
                  caption: str = "(f) WCTLS Line Extraction Result") -> None:
    """Draw the scan and fitted WCTLS segments."""
    fig, ax = plt.subplots(figsize=(16.8, 9.8), dpi=720)
    point_size = 148.0 if len(points) <= 220 else 112.0
    line_width = 7.2 if show_segments else 0.0
    segment_color = "#ff8c00"
    ax.set_facecolor("#ffffff")
    ax.scatter(points[:, 0], points[:, 1], s=point_size, c="#0b1f5b",
               edgecolors="#111827", linewidths=1.55, alpha=0.98,
               label="Raw points", zorder=1, antialiased=True)
    if show_segments:
        drawn = False
        for seg in segments:
            ax.plot([seg.p0[0], seg.p1[0]], [seg.p0[1], seg.p1[1]],
                    color=segment_color, linewidth=line_width, alpha=0.98,
                    solid_capstyle="round", label="Extracted segments" if not drawn else None,
                    zorder=3, antialiased=True)
            ax.scatter([seg.p0[0], seg.p1[0]], [seg.p0[1], seg.p1[1]],
                       s=90.0, c=segment_color, edgecolors="#111827", linewidths=1.10,
                       zorder=4, antialiased=True)
            drawn = True
    ax.set_xlabel("X (m)", fontsize=24, labelpad=10)
    ax.set_ylabel("Y (m)", fontsize=24, labelpad=10)
    ax.set_aspect("equal")
    ax.grid(True, linestyle="--", linewidth=0.8, alpha=0.36, zorder=0)
    ax.tick_params(axis="both", which="major", width=1.1, length=6, labelsize=20)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.1)
    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    y_min, y_max = np.min(points[:, 1]), np.max(points[:, 1])
    x_span, y_span = max(x_max - x_min, 1e-6), max(y_max - y_min, 1e-6)
    ax.set_xlim(x_min - 0.03 * x_span, x_max + 0.18 * x_span)
    ax.set_ylim(y_min - 0.05 * y_span, y_max + 0.05 * y_span)
    if caption:
        fig.text(0.5, 0.181, caption, ha="center", va="bottom", fontsize=34)
    fig.subplots_adjust(left=0.08, right=0.97, bottom=0.18, top=0.96)
    fig.canvas.draw()
    tight_bbox = fig.get_tightbbox(fig.canvas.get_renderer()).padded(0.03)
    output_bbox = matplotlib.transforms.Bbox.from_extents(
        tight_bbox.x0, tight_bbox.y0, tight_bbox.x1, tight_bbox.y1 + 55.0 / 720.0)
    fig.savefig(out_path, dpi=720, bbox_inches=output_bbox, pad_inches=0.0, facecolor="#ffffff", metadata=({"Creator": None, "Producer": None, "Author": None, "CreationDate": None, "ModDate": None} if Path(out_path).suffix.lower() == ".pdf" else {"Creator": None, "Date": None} if Path(out_path).suffix.lower() in (".svg", ".svgz") else {"Software": None} if Path(out_path).suffix.lower() in ("", ".png") else None))
    plt.close(fig)


def result_record(input_path: Path, points: np.ndarray, segments: list[FittedSegment],
                  corners: list[dict], diagnostics: list[dict], params: Parameters,
                  runtime_ms: float, noise_provenance: str) -> dict:
    supports = sum(len(s.point_indices) for s in segments)
    metrics = {
        "num_segments": len(segments), "support_count_with_shared_points": supports,
        "unique_support_points": len(set(int(i) for s in segments for i in s.point_indices)),
        "support_rmse_m": float(np.sqrt(sum(len(s.point_indices) * s.fit.rms**2 for s in segments) / supports)) if supports else None,
        "max_support_residual_m": max((s.fit.max_residual for s in segments), default=None),
        "evaluation_scope": "descriptive residuals on method-selected supports, not an unbiased comparison metric",
    }
    segment_records = []
    for s in segments:
        f = s.fit
        segment_records.append({
            "line_id": s.line_id, "frame_id": s.frame_id, "leaf_index": s.leaf_index,
            "point_indices": s.point_indices.tolist(), "n_points": len(s.point_indices),
            "p0": {"x": float(s.p0[0]), "y": float(s.p0[1])},
            "p1": {"x": float(s.p1[0]), "y": float(s.p1[1])},
            "length": f.length, "rms": f.rms, "max_residual": f.max_residual,
            "straightness": f.straightness,
            "q_sensor_frame": f.q.tolist(), "relative_weights": f.relative_weights.tolist(),
            "line_abc_sensor_frame": f.coefficients.tolist(),
            "line_abc_display_frame": s.coefficients_global.tolist(),
            "covariance_q": f.covariance_q.tolist(),
            "covariance_line_sensor_frame": f.covariance.tolist(),
            "covariance_line_display_frame": s.covariance_global.tolist(),
            "normal_matrix_condition": f.condition_number,
        })
    return {
        "runs": [{"timestamp": datetime.now(timezone.utc).isoformat(),
                  "input_file": Path(os.path.relpath(input_path, ROOT)).as_posix(),
                  "input_sha256": hashlib.sha256(input_path.read_bytes()).hexdigest(),
                  "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "method": "WCTLS (2026), independent equation-based reproduction",
                  "version": VERSION, "paper_doi": PAPER_DOI, "foundation_doi": WCLM_DOI,
                  "parameters": asdict(params), "noise_provenance": noise_provenance,
                  "frame_layout_mode": "per-frame sensor-coordinate fitting, translated back for display",
                  "frame_count": len(diagnostics), "num_input_points": len(points),
                  "num_segments": len(segments), "num_corner_candidates": len(corners),
                  "runtime_ms": runtime_ms,
                  "runtime_scope": "IEPF + WCTLS + line/corner covariance; excludes JSON I/O and plotting; one call, not a benchmark",
                  "summary": metrics, "frames": diagnostics, "segments": segment_records,
                  "corners": corners,
                  "adaptations": ["12-point / 0.30-m size defaults follow archived IEPF and SRG, not the paper",
                                  "finite endpoints are support projection extrema",
                                  "no gap prepartition, merging, outlier filter, or minimum-angle corner heuristic",
                                  "first-order covariance conditions on the selected supports and excludes segmentation uncertainty",
                                  "paper independent-line corner covariance and supplemental shared-point covariance are both saved"],
                  "coverage_validated_on_intel": False}],
    }


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", default="20_Frames_Reference_Segments_and_Annotations/Scan_Data_and_Annotations/Corridor01.json")
    p.add_argument("--output-png", "--output", default="06_WCTLS_fit.png")
    p.add_argument("--output-json", default="wctls_results/wctls_inter.json")
    p.add_argument("--points-png", default="wctls_results/points.png")
    p.add_argument("--output-svg", default=None)
    p.add_argument("--caption", default="(f) WCTLS Line Extraction Result")
    p.add_argument("--iepf-threshold", type=float, default=0.063, help="Experiment threshold in m; paper uses 0.04")
    p.add_argument("--merge-max-residual", type=float, default=0.045, help="Adjacent TLS residual gate in m; 0 disables refinement")
    p.add_argument("--merge-angle-deg", type=float, default=8.0)
    p.add_argument("--min-line-points", type=int, default=12, help="Experiment size filter, not paper-specified")
    p.add_argument("--min-line-length", type=float, default=0.30, help="Experiment size filter, metres")
    p.add_argument("--sigma-range", type=float, default=0.05, help="Constant range SD in m; paper S1 proxy, NOT Intel calibration")
    p.add_argument("--sigma-angle-rad", type=float, default=math.radians(0.391), help="Angle SD in radians; paper S1 proxy, NOT Intel calibration")
    p.add_argument("--noise-provenance", default="Paper S1 figures (5 cm, 0.391 deg), interpreted as SDs for illustration; not Intel-calibrated. Angular resolution is not generally an angular-noise SD.")
    p.add_argument("--max-condition", type=float, default=1e12)
    p.add_argument("--corner-sine-min", type=float, default=1e-8)
    return p


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    for name in ("input", "output_png", "output_json", "points_png", "output_svg"):
        value = getattr(args, name)
        if value is not None:
            path = Path(value)
            setattr(args, name, path if path.is_absolute() else ROOT / path)
    params = Parameters(**{key: getattr(args, key) for key in Parameters.__dataclass_fields__})
    input_path = Path(args.input)
    outputs = [Path(args.output_png), Path(args.output_json), Path(args.points_png)]
    if args.output_svg:
        outputs.append(Path(args.output_svg))
    if len({p.resolve() for p in [input_path, Path(__file__), *outputs]}) != len(outputs) + 2:
        parser.error("Input, script and every output must have distinct paths")
    try:
        params.validate()
        points, frames, _ = load_input(input_path)
        t0 = perf_counter()
        segments, corners, diagnostics = extract_segments(points, frames, params)
        elapsed_ms = (perf_counter() - t0) * 1000
        for path in outputs:
            path.parent.mkdir(parents=True, exist_ok=True)
        plot_segments(points, segments, Path(args.output_png), caption=args.caption)
        plot_segments(points, [], Path(args.points_png), show_segments=False,
                      caption="(a) Original Point Cloud")
        if args.output_svg:
            plot_segments(points, segments, Path(args.output_svg), caption=args.caption)
        report = result_record(input_path, points, segments, corners, diagnostics, params,
                               elapsed_ms, args.noise_provenance)
        Path(args.output_json).write_text(json.dumps(report, ensure_ascii=False, indent=2,
                                                     allow_nan=False) + "\n", encoding="utf-8")
    except (ValueError, OSError, KeyError, TypeError) as exc:
        parser.error(str(exc))
    print(f"WCTLS: {len(frames)} frames, {len(points)} points, {len(segments)} segments")
    print("Per frame: " + ", ".join(f"{d['frame_id']} -> {d['accepted_segments']} segments" for d in diagnostics))
    print(f"Core processing: {elapsed_ms:.3f} ms (single call; excludes plotting/I/O)")
    print(f"Noise provenance: {args.noise_provenance}")
    print(f"Visualization: {Path(os.path.relpath(args.output_png, ROOT)).as_posix()}")
    print(f"Results: {Path(os.path.relpath(args.output_json, ROOT)).as_posix()}")


if __name__ == "__main__":
    main()
