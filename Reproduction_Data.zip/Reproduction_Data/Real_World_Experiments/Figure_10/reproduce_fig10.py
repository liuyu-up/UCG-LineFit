"""Recompute separate vector PDFs for each method in Figure 10.
Run all available methods: python reproduce_fig10.py
Run selected methods: python reproduce_fig10.py --methods RANSAC WCTLS
Dependencies: numpy, matplotlib; numba enables UCG-LineFit acceleration.
Paths are relative to this script. Selected methods are imported on demand.
"""
import os
import sys

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import importlib.util
import json
import math
from functools import lru_cache
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def relative_path(value):
    path = Path(value)
    return path if path.is_absolute() else HERE / path


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def method_path(stem):
    if stem == "wctls":
        return HERE.parents[1] / "WCTLS" / HERE.parent.name / HERE.name / "wctls.py"
    return HERE / (stem + ".py")


@lru_cache(maxsize=None)
def load_method(stem):
    path = method_path(stem)
    spec = importlib.util.spec_from_file_location("_reproduction_" + stem, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sensor_config(feature, dataset, angle=None, profile="standard"):
    cfg = feature.build_parser().parse_args([])
    if dataset == "R2000":
        cfg.sensor_range_noise_m = 0.007332930140722351
        cfg.sensor_angle_noise_rad = 0.0012673763
        cfg.angle_increment = 0.0026179938577115536
    elif dataset == "Intel":
        cfg.sensor_range_noise_m = 0.006210466855951062
        cfg.sensor_angle_noise_rad = 0.0012414863603140256
        cfg.angle_increment = 0.017453293006
    else:
        raise ValueError(f"Unknown dataset: {dataset}")
    cfg.sensor_range_noise_slope = 0.0
    if angle is not None:
        cfg.angle_increment = abs(float(angle))
    if profile == "r2000":
        cfg.fast_search_enable = True
        cfg.fast_search_step = 14
        cfg.noise_split_recovery_enable = True
        cfg.continuity_enable = True
    elif profile == "figure":
        for key, value in feature.FIGURE_LAYOUT_PARAMETERS.items():
            setattr(cfg, key, value)
    elif profile == "lab":
        for key, value in feature.LAB_SCAN_PARAMETERS.items():
            setattr(cfg, key, value)
    return cfg


def segment_endpoints(segment):
    if hasattr(segment, "p2"):
        return segment.p1, segment.p2
    return segment.p0, segment.p1


def segment_size(segment):
    count = int(segment.n_points) if hasattr(segment, "n_points") else len(segment.point_indices)
    return count, math.dist(*segment_endpoints(segment))


def segment_info(segment):
    first, last = segment_endpoints(segment)
    count, length = segment_size(segment)
    return {
        "id": int(getattr(segment, "id", getattr(segment, "line_id", 0))),
        "p1": np.asarray(first).tolist(), "p2": np.asarray(last).tolist(),
        "n_points": count, "length": length,
    }


def effective_segments(segments):
    result = []
    for segment in segments:
        count, length = segment_size(segment)
        if count >= 12 and math.isfinite(length) and length >= 0.30:
            result.append(segment)
    return result


def serialize(segments):
    rows = [segment_info(segment) for segment in segments]
    for index, row in enumerate(rows, 1):
        if row["id"] == 0:
            row["id"] = index
    return sorted(rows, key=lambda row: row["id"])


METHOD_FILES = {"UCG-LineFit": "feature", "RANSAC": "ransac", "IEPF": "iepf", "SRG": "srg", "WCTLS": "wctls"}


def build_runner(method, path, dataset, profile="standard"):
    module = load_method(METHOD_FILES[method])
    if method == "UCG-LineFit":
        angle = module.load_angle_increment_hint(path)
        cfg = sensor_config(module, dataset, angle, profile)
        layouts = module.load_frame_layouts(path)
        return lambda points: module.extract_segments_from_layout(points, layouts, cfg)[0], vars(cfg)
    if method == "RANSAC":
        previous = sys.argv
        try:
            sys.argv = [str(HERE / "ransac.py")]
            cfg = module.parse_args()
        finally:
            sys.argv = previous
        def run(points):
            return module.ransac_segments(
                points, cfg.distance_threshold, cfg.max_iterations, cfg.min_inliers,
                cfg.max_lines, cfg.projection_gap, cfg.seed, cfg.min_length,
                cfg.min_straightness, cfg.merge_angle_deg, cfg.merge_offset, cfg.merge_gap)
        return run, vars(cfg)
    if method == "IEPF":
        cfg = module.build_arg_parser().parse_args([])
        def run(points):
            runs = module.split_runs(points, cfg.gap_scale, cfg.gap_abs, cfg.min_run_points)
            intervals = []
            epsilon = cfg.eps_a + cfg.eps_b * np.median(np.linalg.norm(points, axis=1))
            for first, last in runs or [(0, len(points) - 1)]:
                parts = []
                module.iepf_split(points, first, last, epsilon, cfg.iepf_min_points, parts)
                if hasattr(module, "refine_adjacent_intervals"):
                    parts = module.refine_adjacent_intervals(
                        points, parts, cfg.merge_max_residual, cfg.merge_angle_deg)
                intervals.extend(parts)
            intervals = module.simple_feature_filter(
                points, intervals, cfg.feature_min_points, cfg.feature_min_len)
            return [module.fit_segment(points, first, last) for first, last in intervals]
        return run, vars(cfg)
    if method == "SRG":
        cfg = module.Parameters()
        layouts = module.load_frame_layouts(path)
        return lambda points: module.srg_segments_from_layout(points, layouts, cfg)[0], vars(cfg)
    cfg = module.Parameters(iepf_threshold=0.04, merge_max_residual=0.0) if profile in ("figure", "lab") else module.Parameters()
    _, frames, _ = module.load_input(path)
    return lambda points: module.extract_segments(points, frames, cfg)[0], vars(cfg)

FIGURE = 10
DATASET = "R2000"
INPUT = "single_frame.json"
PROFILE = "lab"

def draw_method(points, segments, method, destination, png=False):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 11, "axes.labelsize": 11, "axes.titlesize": 12,
        "xtick.labelsize": 10, "ytick.labelsize": 10, "legend.fontsize": 9,
        "axes.unicode_minus": True, "pdf.fonttype": 42,
    })
    fig, ax = plt.subplots(figsize=(8.0, 3.8) if FIGURE == 9 else (10.0, 2.8))
    raw_color, line_color = ("#0b1f5b", "#ff8c00") if FIGURE == 9 else ("#ff0000", "#ffff00")
    ax.scatter(points[:, 0], points[:, 1], s=9 if FIGURE == 9 else 4, color=raw_color,
               edgecolors="none", label="Raw points", zorder=2)
    for index, segment in enumerate(segments):
        a, b = segment["p1"], segment["p2"]
        ax.plot([a[0], b[0]], [a[1], b[1]], color=line_color, linewidth=1.9,
                label="Extracted segments" if index == 0 else None, zorder=3)
        if FIGURE == 9:
            ax.scatter([a[0], b[0]], [a[1], b[1]], s=8, color=line_color,
                       edgecolors="#111827", linewidths=0.3, zorder=4)
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_title(method)
    ax.grid(True, linestyle="--", color="#e5e7eb", linewidth=0.45, zorder=0)
    margin = (points.max(axis=0) - points.min(axis=0)) * np.array([0.04, 0.12])
    ax.set_xlim(points[:, 0].min() - margin[0], points[:, 0].max() + margin[0])
    ax.set_ylim(points[:, 1].min() - margin[1], points[:, 1].max() + margin[1])
    ax.legend(loc="lower right", fontsize=9)
    fig.tight_layout()
    fig.savefig(destination)
    if png:
        fig.savefig(destination.with_suffix(".png"), dpi=200)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default=INPUT, help="Point-cloud JSON, relative to this script")
    parser.add_argument("--output-dir", default="reproduced", help="Path relative to this script")
    parser.add_argument("--methods", nargs="+", choices=METHOD_FILES,
                        help="Methods to run. By default, use all method files present in this folder")
    parser.add_argument("--png", action="store_true", help="Also save PNG previews")
    args = parser.parse_args()
    methods = args.methods or [name for name, stem in METHOD_FILES.items() if method_path(stem).is_file()]
    if not methods:
        parser.error("No method files found")
    path = relative_path(args.input)
    data = read_json(path)
    points = np.array([[p["x"], p["y"]] for p in data["points"]], dtype=float)
    if len(points) == 0:
        parser.error("Input point cloud is empty")
    output = relative_path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    results = {}
    for name in dict.fromkeys(methods):
        runner, parameters = build_runner(name, path, DATASET, PROFILE)
        if name == "UCG-LineFit":
            load_method("feature").prepare_backend(sensor_config(
                load_method("feature"), DATASET, load_method("feature").load_angle_increment_hint(path), PROFILE))
        segments = serialize(effective_segments(runner(points.copy())))
        stem = METHOD_FILES[name] if name != "UCG-LineFit" else "ucg_linefit"
        destination = output / f"fig{FIGURE}_{stem}.pdf"
        draw_method(points, segments, name, destination, args.png)
        results[name] = {"segments": segments, "parameters": parameters, "pdf": destination.name}
        print(f"{name}: {len(segments)} segments -> {destination.name}", flush=True)
    write_json(output / f"fig{FIGURE}_segments.json", {"input": path.name, "methods": results})


if __name__ == "__main__":
    main()

