"""Recompute all 57 sensitivity settings and vector Figures 13-15.
Run: python reproduce_fig13_15.py
Resume: python reproduce_fig13_15.py --resume
Dependencies: numpy, scipy, matplotlib; numba enables acceleration.
All paths are resolved relative to this script.
"""
import os
import sys

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import csv
import hashlib
import importlib.util
import json
import math
from concurrent.futures import ProcessPoolExecutor, as_completed
from functools import lru_cache
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def relative_path(value):
    path = Path(value)
    return path if path.is_absolute() else HERE / path


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


@lru_cache(maxsize=None)
def load_method(stem):
    path = HERE / (stem + ".py")
    spec = importlib.util.spec_from_file_location("_reproduction_" + stem, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sensor_config(feature, dataset, angle=None, profile="standard"):
    cfg = feature.build_parser().parse_args([])
    if dataset == "R2000":
        cfg.sensor_range_noise_m = 0.007332930140722351
        cfg.sensor_angle_noise_rad = 0.0012673763
        cfg.angle_increment = 0.0026179938577115536
    elif dataset == "Intel":
        cfg.sensor_range_noise_m = 0.006210466855951062
        cfg.sensor_angle_noise_rad = 0.0012414863603140256
        cfg.angle_increment = 0.017453293006
    else:
        raise ValueError(f"Unknown dataset: {dataset}")
    cfg.sensor_range_noise_slope = 0.0
    if angle is not None:
        cfg.angle_increment = abs(float(angle))
    if profile == "r2000":
        cfg.fast_search_enable = True
        cfg.fast_search_step = 14
        cfg.noise_split_recovery_enable = True
        cfg.continuity_enable = True
    elif profile == "figure":
        for key, value in feature.FIGURE_LAYOUT_PARAMETERS.items():
            setattr(cfg, key, value)
    elif profile == "lab":
        for key, value in feature.LAB_SCAN_PARAMETERS.items():
            setattr(cfg, key, value)
    return cfg


def segment_endpoints(segment):
    if hasattr(segment, "p2"):
        return segment.p1, segment.p2
    return segment.p0, segment.p1


def segment_size(segment):
    count = int(segment.n_points) if hasattr(segment, "n_points") else len(segment.point_indices)
    return count, math.dist(*segment_endpoints(segment))


def segment_info(segment):
    first, last = segment_endpoints(segment)
    count, length = segment_size(segment)
    return {
        "id": int(getattr(segment, "id", getattr(segment, "line_id", 0))),
        "p1": np.asarray(first).tolist(), "p2": np.asarray(last).tolist(),
        "n_points": count, "length": length,
    }


def effective_segments(segments):
    result = []
    for segment in segments:
        count, length = segment_size(segment)
        if count >= 12 and math.isfinite(length) and length >= 0.30:
            result.append(segment)
    return result


def serialize(segments):
    rows = [segment_info(segment) for segment in segments]
    for index, row in enumerate(rows, 1):
        if row["id"] == 0:
            row["id"] = index
    return sorted(rows, key=lambda row: row["id"])
def geometry(p,g):
    a,b,c,d=map(np.asarray,[p['p1'],p['p2'],g['p1'],g['p2']])
    lp,lg=np.linalg.norm(b-a),np.linalg.norm(d-c)
    if min(lp,lg)<=1e-12:return {'eligible':False}
    u,v=(b-a)/lp,(d-c)/lg
    angle=float(np.degrees(np.arccos(np.clip(abs(u@v),0.,1.))))
    nu,nv=np.array([-u[1],u[0]]),np.array([-v[1],v[0]])
    normal=float((abs((a-c)@nv)+abs((b-c)@nv)+abs((c-a)@nu)+abs((d-a)@nu))/4)
    lo,hi=sorted([(a-c)@v,(b-c)@v]);overlap=max(0.,min(hi,lg)-max(lo,0.))
    iou=float(overlap/(lg+hi-lo-overlap))
    endpoint=float(min(np.linalg.norm(a-c)+np.linalg.norm(b-d),np.linalg.norm(a-d)+np.linalg.norm(b-c))/2)
    return {'eligible':angle<=5. and normal<=.02 and iou>=.5,
            'angle_deg':angle,'normal_m':normal,'iou':iou,'endpoint_mean_m':endpoint}

def matching(pred,refs):
    from scipy.optimize import linear_sum_assignment

    stats={(gi,pi):geometry(p,g) for gi,g in enumerate(refs) for pi,p in enumerate(pred)}
    eligible={k:v['endpoint_mean_m'] for k,v in stats.items() if v['eligible']}
    # An unmatched penalty exceeds the maximum possible total eligible cost,
    # so cardinality has strict priority over endpoint distance.
    penalty=(min(len(pred),len(refs))+1)*(max(eligible.values(),default=0.)+1.)
    def solve(gs,ps):
        if not gs:return 0,0.,{}
        cost=np.full((len(gs),len(ps)+len(gs)),penalty)
        cost[:,:len(ps)]=penalty*3
        for r,gi in enumerate(gs):
            for c,pi in enumerate(ps):
                if (gi,pi) in eligible:cost[r,c]=eligible[gi,pi]
        ii,jj=linear_sum_assignment(cost)
        pairs={gs[i]:ps[j] for i,j in zip(ii,jj) if j<len(ps) and (gs[i],ps[j]) in eligible}
        return len(pairs),math.fsum(eligible[k] for k in pairs.items()),pairs
    gs=list(range(len(refs)));ps=list(range(len(pred)))
    target_n,target_cost,_=solve(gs,ps)
    ans={}
    # Lexicographic reference ID then prediction ID, with unmatched last.
    # Re-solving the residual assignment avoids epsilon perturbing costs.
    for gi in gs:
        remaining=[g for g in gs if g>gi]
        choices=[p for p in ps if (gi,p) in eligible]+[None]
        for pi in choices:
            rest=[p for p in ps if p!=pi]
            n,c,_=solve(remaining,rest)
            own=0. if pi is None else eligible[gi,pi]
            if n+(pi is not None)==target_n and math.isclose(c+own,target_cost,rel_tol=1e-13,abs_tol=1e-12):
                if pi is not None:
                    ans[gi]=pi;ps.remove(pi);target_n-=1
                target_cost-=own
                break
        else:raise AssertionError('No canonical optimal assignment')
    return ans,stats

def distances(points,pred):
    x=np.asarray(points);a,b=np.asarray(pred['p1']),np.asarray(pred['p2']);v=b-a
    t=np.clip((x-a)@v/(v@v),0.,1.)
    return np.linalg.norm(x-a-t[:,None]*v,axis=1)

def reference_samples(refs):
    samples = []
    for ref in refs:
        length = math.dist(ref["p1"], ref["p2"])
        if not math.isfinite(length) or length <= 0:
            raise ValueError(f"Invalid reference segment {ref['id']}")
        samples.append(np.linspace(ref["p1"], ref["p2"], math.ceil(length / 0.01) + 1))
    return samples


def evaluate_predictions(refs, predictions, samples=None):
    if samples is None:
        samples = reference_samples(refs)
    pairs, details = matching(predictions, refs)
    matches = {}
    for gi, pi in sorted(pairs.items()):
        ref = refs[gi]
        error = distances(samples[gi], predictions[pi])
        matches[str(gi)] = {
            "prediction_index": pi, "reference_id": ref["id"],
            "N": len(error), "sum_sq": float(error @ error), "MaxRes": float(error.max()),
            "geometry": details[gi, pi],
        }
    count = len(pairs)
    return {"TP": count, "FP": len(predictions) - count, "FN": len(refs) - count, "matches": matches}


def summarize(rows, common):
    tp = sum(row["TP"] for row in rows)
    fp = sum(row["FP"] for row in rows)
    fn = sum(row["FN"] for row in rows)
    errors = [row["matches"][str(index)] for row, indices in zip(rows, common) for index in indices]
    count = sum(error["N"] for error in errors)
    return {
        "TP": tp, "FP": fp, "FN": fn,
        "Precision": 100 * tp / (tp + fp) if tp + fp else 0.0,
        "Recall": 100 * tp / (tp + fn) if tp + fn else 0.0,
        "F1": 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0,
        "RMSE": math.sqrt(math.fsum(error["sum_sq"] for error in errors) / count) if count else None,
        "MaxRes": max((error["MaxRes"] for error in errors), default=None),
        "N_eval": count,
    }


GROUP_DIRS = {
    "group1": "01_Gaussian_Quantile_and_Local_Noise_Scale_Gain_30_Frames",
    "group2": "02_Graph_Recovery_Angle_Threshold_30_Frames",
}
GRIDS = {
    "c": [0.8, 0.85, 0.9, 0.925, 0.95, 0.975, 0.99, 0.995, 0.9973, 0.999, 0.9995, 0.9999],
    "gamma": [0.1, 0.15, 0.2, 0.25, 0.35, 0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6],
    "angle": [0.1, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6, 7, 8, 9, 10, 10.5, 11,
              11.5, 12, 13, 14, 16, 18, 20, 24, 27, 30],
}
OPTIONS = {"c": "threshold_confidence", "gamma": "huber_sigma_gain", "angle": "graph_angle_deg"}


def prepare_worker():
    feature = load_method("feature")
    feature.prepare_backend(sensor_config(feature, "Intel"))


def sweep_frame(task):
    group, filename = task
    path = Path(filename)
    data = read_json(path)
    points = np.array([[p["x"], p["y"]] for p in data["points"]], dtype=float)
    refs = sorted(data["reference_segments"], key=lambda row: row["id"])
    samples = reference_samples(refs)
    feature = load_method("feature")
    layouts = feature.load_frame_layouts(path)
    angle = feature.load_angle_increment_hint(path)
    runs = []
    for kind in (("c", "gamma") if group == "group1" else ("angle",)):
        for value in GRIDS[kind]:
            cfg = sensor_config(feature, data["dataset"], angle)
            setattr(cfg, OPTIONS[kind], value)
            segments = feature.extract_segments_from_layout(points.copy(), layouts, cfg)[0]
            predictions = serialize(effective_segments(segments))
            runs.append({
                "kind": kind, "value": value, "predictions": predictions,
                "evaluation": evaluate_predictions(refs, predictions, samples),
            })
    return {"group": group, "frame": path.stem, "references": len(refs), "runs": runs}


def frame_sweeps(tasks, workers):
    if not tasks:
        return
    if workers == 1:
        prepare_worker()
        for task in tasks:
            yield sweep_frame(task)
        return
    with ProcessPoolExecutor(max_workers=workers, initializer=prepare_worker) as pool:
        futures = [pool.submit(sweep_frame, task) for task in tasks]
        for future in as_completed(futures):
            yield future.result()


def collect_results(frames):
    common = {}
    for frame in frames:
        key = frame["group"] + "/" + frame["frame"]
        common[key] = sorted(set.intersection(
            *(set(run["evaluation"]["matches"]) for run in frame["runs"])), key=int)
    groups = {}
    runs = []
    for group in GROUP_DIRS:
        selected = sorted((f for f in frames if f["group"] == group), key=lambda f: f["frame"])
        indices = [common[group + "/" + f["frame"]] for f in selected]
        groups[group] = {
            "frames": len(selected), "references": sum(f["references"] for f in selected),
            "common_references": sum(map(len, indices)),
        }
        for kind in (("c", "gamma") if group == "group1" else ("angle",)):
            for value in GRIDS[kind]:
                rows = [next(r["evaluation"] for r in f["runs"] if r["kind"] == kind and r["value"] == value)
                        for f in selected]
                runs.append({"kind": kind, "value": value, "group": group, "summary": summarize(rows, indices)})
    return {"groups": groups, "runs": runs, "common_reference_indices": common, "per_frame": frames}


def draw_figures(result, output, png=False):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter, NullLocator
    plt.rcParams.update({
        "font.family": "Times New Roman", "font.size": 11, "mathtext.fontset": "stix",
        "axes.labelsize": 13, "xtick.labelsize": 10.5, "ytick.labelsize": 10.5, "pdf.fonttype": 42,
    })
    styles = {
        "Precision": ("#245d9f", "o", "-"), "Recall": ("#009e83", "s", "--"),
        "F1": ("#e88a00", "^", "-."), "RMSE": ("#884bc1", "D", "-"), "MaxRes": ("#e72b40", "v", "--"),
    }
    specs = (
        ("c", "fig13", 0.9973, r"Quantile parameter $c$ [$-\log_{10}(1-c)$ spacing]"),
        ("gamma", "fig14", 0.25, r"Local noise scale gain $\gamma$ (log scale)"),
        ("angle", "fig15", 11.0, r"Graph orientation gate $\tau_g$ (deg, log scale)"),
    )
    for kind, stem, default, xlabel in specs:
        rows = sorted((r for r in result["runs"] if r["kind"] == kind), key=lambda r: r["value"])
        values = np.array([r["value"] for r in rows])
        x = -np.log10(1 - values) if kind == "c" else values
        fig, ax = plt.subplots(figsize=(9.4, 5.35))
        right = ax.twinx()
        fig.subplots_adjust(left=0.105, right=0.885, bottom=0.165, top=0.845)
        if kind != "c":
            ax.set_xscale("log")
        right.set_yscale("log")
        handles = []
        for metric, (color, marker, linestyle) in styles.items():
            y = np.array([row["summary"][metric] for row in rows], dtype=float)
            if not np.isfinite(y).all():
                raise ValueError(f"Undefined {metric} for {stem}")
            axis = ax if metric in ("Precision", "Recall", "F1") else right
            if axis is right and (y <= 0).any():
                raise ValueError(f"A logarithmic error axis requires positive {metric}")
            line, = axis.plot(x, y, color=color, marker=marker, linestyle=linestyle, linewidth=1.65,
                              markersize=4.5, markerfacecolor="white", markeredgewidth=1.2, label=metric)
            handles.append(line)
        accuracy = [row["summary"][metric] for row in rows for metric in ("Precision", "Recall", "F1")]
        lower = 5 * math.floor((min(accuracy) - 1) / 5)
        ax.set_ylim(lower, 100)
        ax.set_yticks(np.arange(lower, 101, 5))
        error = [row["summary"][metric] for row in rows for metric in ("RMSE", "MaxRes")]
        low_error = min(0.02 if kind == "angle" else 0.05, min(error) * 0.75)
        high_error = max(error) * 1.35
        right.set_ylim(low_error, high_error)
        ticks = np.array([0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10])
        right.set_yticks(ticks[(ticks >= low_error) & (ticks <= high_error)])
        right.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
        right.yaxis.set_minor_locator(NullLocator())
        if kind == "c":
            ticks = np.array([0.8, 0.95, 0.99, 0.9973, 0.9999])
            ax.set_xticks(-np.log10(1 - ticks), ["0.80", "0.95", "0.99", "0.9973", "0.9999"])
            default_x = -np.log10(1 - default)
        else:
            ticks = [0.1, 0.25, 0.5, 1, 2, 4, 6] if kind == "gamma" else [0.1, 0.25, 0.5, 1, 2, 5, 11, 20, 30]
            ax.set_xticks(ticks, [f"{value:g}" for value in ticks])
            default_x = default
        ax.xaxis.set_minor_locator(NullLocator())
        ax.margins(x=0.035)
        ax.axvline(default_x, color="#727a84", linewidth=0.9, linestyle=(0, (3, 3)), zorder=1)
        ax.annotate("default", xy=(default_x, 0.23), xycoords=("data", "axes fraction"),
                    xytext=(7, 0), textcoords="offset points", fontsize=9, color="#626b77", va="center")
        ax.set_xlabel(xlabel, labelpad=9)
        ax.set_ylabel("Precision / Recall / F1 (%)", labelpad=9)
        right.set_ylabel("RMSE / MaxRes (m, log scale)", labelpad=13)
        ax.grid(axis="y", color="#cbd7e8", linewidth=0.55)
        for axis in (ax, right):
            axis.spines["top"].set_visible(False)
            axis.tick_params(length=3, width=0.7)
            for spine in axis.spines.values():
                spine.set_linewidth(0.7)
        fig.legend(handles, list(styles), loc="upper center", bbox_to_anchor=(0.5, 0.985),
                   ncol=5, frameon=False, fontsize=10.5, handlelength=2.2, columnspacing=1.35)
        fig.savefig(output / (stem + ".pdf"))
        if png:
            fig.savefig(output / (stem + ".png"), dpi=180)
        plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", default="reproduced", help="Path relative to this script")
    parser.add_argument("--workers", type=int, default=1,
                        help="Frame sweep workers; each worker initializes its own extraction backend")
    parser.add_argument("--resume", action="store_true", help="Resume a checkpoint after checking source and input hashes")
    parser.add_argument("--png", action="store_true", help="Also save preview PNG files")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    tasks = [(group, str(path)) for group, folder in GROUP_DIRS.items() for path in sorted((HERE / folder).glob("*.json"))]
    if any(sum(group == item[0] for item in tasks) != 30 for group in GROUP_DIRS):
        parser.error("Each sensitivity group must contain 30 JSON files")
    output = relative_path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    for path in [Path(__file__), HERE / "feature.py", *(Path(name) for _, name in tasks)]:
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    signature = digest.hexdigest()
    checkpoint = output / "sensitivity_checkpoint.json"
    frames = []
    if args.resume and checkpoint.exists():
        cached = read_json(checkpoint)
        if cached["signature"] != signature:
            parser.error("Checkpoint source or input files have changed")
        frames = cached["frames"]
    done = {(frame["group"], frame["frame"]) for frame in frames}
    pending = [task for task in tasks if (task[0], Path(task[1]).stem) not in done]
    for frame in frame_sweeps(pending, args.workers):
        frames.append(frame)
        temporary = checkpoint.with_suffix(".tmp")
        write_json(temporary, {"signature": signature, "frames": frames})
        temporary.replace(checkpoint)
        print(f"Completed {len(frames)}/60 frame sweeps: {frame['group']}/{frame['frame']}", flush=True)
    frames.sort(key=lambda frame: (frame["group"], frame["frame"]))
    result = collect_results(frames)
    result["signature"] = signature
    result["configurations"] = sum(map(len, GRIDS.values()))
    result["fits"] = sum(len(frame["runs"]) for frame in frames)
    write_json(output / "sensitivity_results.json", result)
    fields = ("kind", "value", "group", "TP", "FP", "FN", "Precision", "Recall", "F1", "RMSE", "MaxRes", "N_eval")
    with (output / "sensitivity_results.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for run in result["runs"]:
            writer.writerow({**{key: run[key] for key in fields[:3]}, **run["summary"]})
    draw_figures(result, output, args.png)
    print(json.dumps(result["groups"], ensure_ascii=False), flush=True)
    print(f"Saved fig13.pdf, fig14.pdf and fig15.pdf in {output}", flush=True)


if __name__ == "__main__":
    main()

