import os
import sys

sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'BLIS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS', 'NUMBA_NUM_THREADS'):
    os.environ[key] = '1'
os.environ.setdefault('MPLBACKEND', 'Agg')

import argparse
import importlib.util
import math
import subprocess
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
from time import perf_counter_ns

import numpy as np

HERE = Path(__file__).resolve().parent
STAGES = ('Preprocessing', 'Candidate search / gating', 'Standalone TLS-Huber fitting', 'Endpoints + merge / optimization')


class ExclusiveStages:

    def __init__(self):
        self.totals_ns = [0, 0, 0, 0]
        self.stack = []
        self.wrapped_bindings = 0

    @contextmanager
    def section(self, category):
        if self.stack and self.stack[-1][0] == 0:
            category = 0
        frame = [category, perf_counter_ns(), 0]
        self.stack.append(frame)
        try:
            yield
        finally:
            elapsed = perf_counter_ns() - frame[1]
            self.stack.pop()
            self.totals_ns[category] += elapsed - frame[2]
            if self.stack:
                self.stack[-1][2] += elapsed

    @contextmanager
    def install(self, core):
        names = {0: ('_preprocess_points', 'preprocess_points', 'prune_small_noise_runs', '_ORIGINAL_PREPROCESS'), 1: ('extract_all_candidates', 'extract_candidates_from_run', '_extract_candidates_from_run', '_ORIGINAL_CANDIDATES_RUN', 'build_candidate_from_window', 'extract_endpoint_branch_candidates', 'split_corner_branches_from_segment', 'extend_branch_with_run_context', 'extend_segment_in_run', '_extend_segment_in_run', '_ORIGINAL_EXTEND_SEGMENT', 'recover_noise_split_candidates', '_recover_noise_split_candidates_python', 'recover_dense_vertical_runs', '_recover_dense_vertical_runs', '_recover_dense_vertical_runs_python', '_dense_window_mask'), 2: ('fit_line_tls_huber', 'fit_line_tls_huber_adaptive', '_fit_line_tls_huber_adaptive_uncached', 'fit_line_tls_core', '_fit_line_tls_core', '_ORIGINAL_FIT', '_ORIGINAL_TLS_CORE', 'estimate_local_noise_sigma_m', '_local_noise_and_tls', 'robust_refine_segment_points', 'fit_windows', 'tls_batch'), 3: ('build_segment_from_points', '_build_segment_from_points', '_build_segment_geometry', '_ORIGINAL_BUILD_SEGMENT', 'extend_high_quality_segment_support', 'merge_and_extend_candidates', 'try_merge_two_segments', '_try_local_merge', '_ORIGINAL_LOCAL_MERGE', 'try_global_merge_two_segments', 'adaptive_try_global_merge_two_segments', 'graph_recover_fragment_paths', '_fragment_edge', 'attach_collinear_fragments_to_features', 'adaptive_stitch_feature_chains', 'stitch_collinear_segments_global', 'deduplicate_segments', 'sort_segments_by_mid_angle', 'recover_collinear_corner_fragments', '_recover_measured_endpoints', '_finish_measured_segments', '_remove_contained_segments', '_consolidate_observed_lines', '_consolidate_observed_lines_impl', '_grow_observed_line')}
        modules = [core, core.base, core._batch]
        categories = {}
        for category, identifiers in names.items():
            for module in modules:
                for identifier in identifiers:
                    value = getattr(module, identifier, None)
                    if callable(value):
                        categories[id(value)] = category
        wrappers = {}
        saved = []

        def wrap(function, category):

            @wraps(function)
            def timed(*args, **kwargs):
                with self.section(category):
                    return function(*args, **kwargs)
            return timed
        try:
            for module in modules:
                for name, value in list(vars(module).items()):
                    category = categories.get(id(value))
                    if category is None:
                        continue
                    if id(value) not in wrappers:
                        wrappers[id(value)] = wrap(value, category)
                    saved.append((module, name, value))
                    setattr(module, name, wrappers[id(value)])
            self.wrapped_bindings = len(saved)
            yield
        finally:
            for module, name, value in reversed(saved):
                setattr(module, name, value)

def load_experiment(folder, table):
    path = HERE.parent / folder / f'reproduce_table{table}.py'
    name = f'_runtime_table{table}'
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def benchmark(folder, table, profile_repeats, reuse_table_results=False):
    experiment = load_experiment(folder, table)
    log = experiment.HERE / 'experiment_log_new.txt'
    if not reuse_table_results or not log.is_file():
        subprocess.run([sys.executable, '-B', str(experiment.HERE / f'reproduce_table{table}.py')], check=True)
    baseline_rows = [line.split('|') for line in log.read_text(encoding='utf-8').splitlines() if line.startswith('UCG-LineFit |')]
    if len(baseline_rows) != 1 or len(baseline_rows[0]) != 8:
        raise ValueError(f'Invalid Table {table} runtime summary')
    baseline = float(baseline_rows[0][-1])
    if not math.isfinite(baseline) or baseline <= 0:
        raise ValueError(f'Invalid Table {table} runtime baseline')
    feature = experiment.load_method('feature')
    config = experiment.sensor_config(feature, experiment.DATASET, profile=experiment.PROFILE)
    feature.prepare_backend(config)
    paths = sorted((experiment.HERE / experiment.DATA_DIR).glob('*.json'))
    if len(paths) != experiment.FRAME_COUNT:
        raise ValueError(f'Expected {experiment.FRAME_COUNT} frames, found {len(paths)}')
    totals = [0, 0, 0, 0]
    for index, path in enumerate(paths):
        data = experiment.read_json(path)
        if data['dataset'] != experiment.DATASET:
            raise ValueError(f'Unexpected dataset in {path.name}')
        points = np.asarray([[p['x'], p['y']] for p in data['points']], dtype=float)
        runner, _ = experiment.build_runner('UCG-LineFit', path, experiment.DATASET, experiment.PROFILE)
        expected = experiment.serialize(experiment.effective_segments(runner(points.copy())))
        profiler = ExclusiveStages()
        with profiler.install(feature):
            if not profiler.wrapped_bindings:
                raise RuntimeError('No extraction stages were instrumented')
            for repeat in range(profile_repeats):
                inputs = points.copy()
                profiler.totals_ns[:] = [0, 0, 0, 0]
                with profiler.section(3):
                    result = experiment.effective_segments(runner(inputs))
                if profiler.stack or any(value < 0 for value in profiler.totals_ns):
                    raise RuntimeError('Invalid exclusive stage timing')
                if experiment.serialize(result) != expected:
                    raise RuntimeError(f'Instrumentation changed output: {path.stem}')
                totals = [total + value for total, value in zip(totals, profiler.totals_ns)]
        print(f'{experiment.DATASET}: completed {index + 1}/{len(paths)}', flush=True)
    total_ns = sum(totals)
    if total_ns <= 0:
        raise RuntimeError('No measured stage duration')
    shares = [value / total_ns for value in totals]
    mean = baseline
    normalized = [mean * share for share in shares]
    if not math.isclose(sum(normalized), mean, rel_tol=1e-12):
        raise RuntimeError('Normalized times do not sum to the total')
    return {'dataset': experiment.DATASET, 'frames': len(paths), 'uninstrumented_repeats': experiment.REPEATS,
            'profile_calls': len(paths) * profile_repeats, 'mean_ms': mean, 'shares': shares,
            'normalized_ms': normalized, 'exclusive_ms': [value / (len(paths) * profile_repeats) / 1e6 for value in totals]}


def save_log(results, output):
    intel, real = results
    lines = ['Figure 11 runtime results', '',
             'Dataset | Frames | Uninstrumented repetitions per frame | Instrumented calls | Mean uninstrumented time (ms/frame)']
    for result in results:
        lines.append(f"{result['dataset']} | {result['frames']} | {result['uninstrumented_repeats']} | {result['profile_calls']} | {result['mean_ms']:.6f}")
    lines += ['', 'Stage | Intel share (%) | R2000 share (%) | Intel normalized time (ms/frame) | R2000 normalized time (ms/frame)']
    for index, stage in enumerate(STAGES):
        lines.append(f"{stage} | {100 * intel['shares'][index]:.6f} | {100 * real['shares'][index]:.6f} | {intel['normalized_ms'][index]:.6f} | {real['normalized_ms'][index]:.6f}")
    lines.append(f"Total | 100.000000 | 100.000000 | {intel['mean_ms']:.6f} | {real['mean_ms']:.6f}")
    lines += ['', 'Stage | Intel instrumented exclusive time (ms/frame) | R2000 instrumented exclusive time (ms/frame)']
    for index, stage in enumerate(STAGES):
        lines.append(f"{stage} | {intel['exclusive_ms'][index]:.6f} | {real['exclusive_ms'][index]:.6f}")
    (output / 'experiment_log_new.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def draw_figure(results, output):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman', 'DejaVu Serif'], 'pdf.fonttype': 42})
    fig = plt.figure(figsize=(680 / 72, 420 / 72))
    colors = ('#2d7060', '#8d6d1e', '#6d4c91', '#963e32')
    for panel, result in enumerate(results):
        cx, cy, radius = 170 + 340 * panel, 144, 94
        axis = fig.add_axes([(cx-radius)/680, (420-cy-radius)/420, 2*radius/680, 2*radius/420])
        axis.pie(result['shares'], colors=colors, startangle=90, counterclock=False,
                 wedgeprops={'linewidth': .9, 'edgecolor': 'white'},
                 autopct=lambda value: f'{value:.2f}%' if value >= 10 else '', pctdistance=.63,
                 textprops={'fontsize': 16, 'color': 'white', 'weight': 'bold'})
        axis.set(aspect='equal', xlim=(-1, 1), ylim=(-1, 1))
        title = 'Intel Research Lab' if panel == 0 else 'R2000'
        fig.text(cx/680, 1-23/420, title, ha='center', va='baseline', fontsize=19, weight='bold')
        fig.text(cx/680, 1-45/420, f"Mean total: {result['mean_ms']:.2f} ms/frame", ha='center', va='baseline', fontsize=15.5, weight='bold')
        for index, stage in enumerate(STAGES):
            y = 263 + 33 * index
            fig.add_artist(Rectangle(((cx-143)/680, 1-(y+1)/420), 9/680, 9/420, transform=fig.transFigure, color=colors[index], linewidth=0))
            fig.text((cx-125)/680, 1-y/420, stage, va='baseline', fontsize=13.5)
            fig.text((cx-125)/680, 1-(y+15)/420,
                     f"{result['normalized_ms'][index]:.2f} ms  |  {100*result['shares'][index]:.2f}%", va='baseline', fontsize=13.5, weight='bold')
        fig.text(cx/680, 1-407/420, f'({chr(97+panel)})', ha='center', va='baseline', fontsize=17)
    fig.savefig(output / 'fig11_new.pdf', metadata={'Title': 'Figure 11. UCG-LineFit runtime allocation', 'Creator': None, 'Producer': None, 'Author': None, 'CreationDate': None, 'ModDate': None})
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', default='.')
    parser.add_argument('--reuse-table-results', action='store_true', help='Use Table 3 and Table 4 logs from immediately preceding runs')
    args = parser.parse_args()
    output = Path(args.output_dir)
    if not output.is_absolute():
        output = HERE / output
    output.mkdir(parents=True, exist_ok=True)
    results = [benchmark('Open_Dataset_Experiments', 3, 10, args.reuse_table_results), benchmark('Real_World_Experiments', 4, 10, args.reuse_table_results)]
    save_log(results, output)
    draw_figure(results, output)
    print('Saved experiment_log_new.txt and fig11_new.pdf', flush=True)


if __name__ == '__main__':
    main()
