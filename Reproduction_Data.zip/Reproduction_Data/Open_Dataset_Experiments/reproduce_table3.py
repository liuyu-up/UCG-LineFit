"""Recompute Table 3. Run: python reproduce_table3.py
Dependencies: numpy, scipy, matplotlib; numba enables the accelerated backend.
Paths are relative to this script. Timing starts with in-memory points and
layout and ends after final segment screening. Preparation, input copying,
file I/O, evaluation, result serialization and plotting are outside the interval.
"""
import os
import sys

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS",
                 "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import csv
import importlib.util
import json
import math
import time
from functools import lru_cache
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def relative_path(value):
    path = Path(value)
    return path if path.is_absolute() else HERE / path


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


@lru_cache(maxsize=None)
def load_method(stem):
    path = HERE / (stem + ".py")
    spec = importlib.util.spec_from_file_location("_reproduction_" + stem, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def sensor_config(feature, dataset, angle=None, profile="standard"):
    cfg = feature.build_parser().parse_args([])
    if dataset == "R2000":
        cfg.sensor_range_noise_m = 0.007332930140722351
        cfg.sensor_angle_noise_rad = 0.0012673763
        cfg.angle_increment = 0.0026179938577115536
    elif dataset == "Intel":
        cfg.sensor_range_noise_m = 0.006210466855951062
        cfg.sensor_angle_noise_rad = 0.0012414863603140256
        cfg.angle_increment = 0.017453293006
    else:
        raise ValueError(f"Unknown dataset: {dataset}")
    cfg.sensor_range_noise_slope = 0.0
    if angle is not None:
        cfg.angle_increment = abs(float(angle))
    if profile == "r2000":
        cfg.fast_search_enable = True
        cfg.fast_search_step = 14
        cfg.noise_split_recovery_enable = True
        cfg.continuity_enable = True
    elif profile == "figure":
        for key, value in feature.FIGURE_LAYOUT_PARAMETERS.items():
            setattr(cfg, key, value)
    elif profile == "lab":
        for key, value in feature.LAB_SCAN_PARAMETERS.items():
            setattr(cfg, key, value)
    return cfg


def segment_endpoints(segment):
    if hasattr(segment, "p2"):
        return segment.p1, segment.p2
    return segment.p0, segment.p1


def segment_size(segment):
    count = int(segment.n_points) if hasattr(segment, "n_points") else len(segment.point_indices)
    return count, math.dist(*segment_endpoints(segment))


def segment_info(segment):
    first, last = segment_endpoints(segment)
    count, length = segment_size(segment)
    return {
        "id": int(getattr(segment, "id", getattr(segment, "line_id", 0))),
        "p1": np.asarray(first).tolist(), "p2": np.asarray(last).tolist(),
        "n_points": count, "length": length,
    }


def effective_segments(segments):
    result = []
    for segment in segments:
        count, length = segment_size(segment)
        if count >= 12 and math.isfinite(length) and length >= 0.30:
            result.append(segment)
    return result


def serialize(segments):
    rows = [segment_info(segment) for segment in segments]
    for index, row in enumerate(rows, 1):
        if row["id"] == 0:
            row["id"] = index
    return sorted(rows, key=lambda row: row["id"])


METHOD_FILES = {"UCG-LineFit": "feature", "RANSAC": "ransac", "IEPF": "iepf", "SRG": "srg", "WCTLS": "wctls"}


def build_runner(method, path, dataset, profile="standard"):
    module = load_method(METHOD_FILES[method])
    if method == "UCG-LineFit":
        angle = module.load_angle_increment_hint(path)
        cfg = sensor_config(module, dataset, angle, profile)
        layouts = module.load_frame_layouts(path)
        return lambda points: module.extract_segments_from_layout(points, layouts, cfg)[0], vars(cfg)
    if method == "RANSAC":
        previous = sys.argv
        try:
            sys.argv = [str(HERE / "ransac.py")]
            cfg = module.parse_args()
        finally:
            sys.argv = previous
        def run(points):
            return module.ransac_segments(
                points, cfg.distance_threshold, cfg.max_iterations, cfg.min_inliers,
                cfg.max_lines, cfg.projection_gap, cfg.seed, cfg.min_length,
                cfg.min_straightness, cfg.merge_angle_deg, cfg.merge_offset, cfg.merge_gap)
        return run, vars(cfg)
    if method == "IEPF":
        cfg = module.build_arg_parser().parse_args([])
        def run(points):
            runs = module.split_runs(points, cfg.gap_scale, cfg.gap_abs, cfg.min_run_points)
            intervals = []
            epsilon = cfg.eps_a + cfg.eps_b * np.median(np.linalg.norm(points, axis=1))
            for first, last in runs or [(0, len(points) - 1)]:
                parts = []
                module.iepf_split(points, first, last, epsilon, cfg.iepf_min_points, parts)
                if hasattr(module, "refine_adjacent_intervals"):
                    parts = module.refine_adjacent_intervals(
                        points, parts, cfg.merge_max_residual, cfg.merge_angle_deg)
                intervals.extend(parts)
            intervals = module.simple_feature_filter(
                points, intervals, cfg.feature_min_points, cfg.feature_min_len)
            return [module.fit_segment(points, first, last) for first, last in intervals]
        return run, vars(cfg)
    if method == "SRG":
        cfg = module.Parameters()
        layouts = module.load_frame_layouts(path)
        return lambda points: module.srg_segments_from_layout(points, layouts, cfg)[0], vars(cfg)
    cfg = module.Parameters(iepf_threshold=0.04, merge_max_residual=0.0) if profile in ("figure", "lab") else module.Parameters()
    _, frames, _ = module.load_input(path)
    return lambda points: module.extract_segments(points, frames, cfg)[0], vars(cfg)
def geometry(p,g):
    a,b,c,d=map(np.asarray,[p['p1'],p['p2'],g['p1'],g['p2']])
    lp,lg=np.linalg.norm(b-a),np.linalg.norm(d-c)
    if min(lp,lg)<=1e-12:return {'eligible':False}
    u,v=(b-a)/lp,(d-c)/lg
    angle=float(np.degrees(np.arccos(np.clip(abs(u@v),0.,1.))))
    nu,nv=np.array([-u[1],u[0]]),np.array([-v[1],v[0]])
    normal=float((abs((a-c)@nv)+abs((b-c)@nv)+abs((c-a)@nu)+abs((d-a)@nu))/4)
    lo,hi=sorted([(a-c)@v,(b-c)@v]);overlap=max(0.,min(hi,lg)-max(lo,0.))
    iou=float(overlap/(lg+hi-lo-overlap))
    endpoint=float(min(np.linalg.norm(a-c)+np.linalg.norm(b-d),np.linalg.norm(a-d)+np.linalg.norm(b-c))/2)
    return {'eligible':angle<=5. and normal<=.02 and iou>=.5,
            'angle_deg':angle,'normal_m':normal,'iou':iou,'endpoint_mean_m':endpoint}

def matching(pred,refs):
    from scipy.optimize import linear_sum_assignment

    stats={(gi,pi):geometry(p,g) for gi,g in enumerate(refs) for pi,p in enumerate(pred)}
    eligible={k:v['endpoint_mean_m'] for k,v in stats.items() if v['eligible']}
    # An unmatched penalty exceeds the maximum possible total eligible cost,
    # so cardinality has strict priority over endpoint distance.
    penalty=(min(len(pred),len(refs))+1)*(max(eligible.values(),default=0.)+1.)
    def solve(gs,ps):
        if not gs:return 0,0.,{}
        cost=np.full((len(gs),len(ps)+len(gs)),penalty)
        cost[:,:len(ps)]=penalty*3
        for r,gi in enumerate(gs):
            for c,pi in enumerate(ps):
                if (gi,pi) in eligible:cost[r,c]=eligible[gi,pi]
        ii,jj=linear_sum_assignment(cost)
        pairs={gs[i]:ps[j] for i,j in zip(ii,jj) if j<len(ps) and (gs[i],ps[j]) in eligible}
        return len(pairs),math.fsum(eligible[k] for k in pairs.items()),pairs
    gs=list(range(len(refs)));ps=list(range(len(pred)))
    target_n,target_cost,_=solve(gs,ps)
    ans={}
    # Lexicographic reference ID then prediction ID, with unmatched last.
    # Re-solving the residual assignment avoids epsilon perturbing costs.
    for gi in gs:
        remaining=[g for g in gs if g>gi]
        choices=[p for p in ps if (gi,p) in eligible]+[None]
        for pi in choices:
            rest=[p for p in ps if p!=pi]
            n,c,_=solve(remaining,rest)
            own=0. if pi is None else eligible[gi,pi]
            if n+(pi is not None)==target_n and math.isclose(c+own,target_cost,rel_tol=1e-13,abs_tol=1e-12):
                if pi is not None:
                    ans[gi]=pi;ps.remove(pi);target_n-=1
                target_cost-=own
                break
        else:raise AssertionError('No canonical optimal assignment')
    return ans,stats

def distances(points,pred):
    x=np.asarray(points);a,b=np.asarray(pred['p1']),np.asarray(pred['p2']);v=b-a
    t=np.clip((x-a)@v/(v@v),0.,1.)
    return np.linalg.norm(x-a-t[:,None]*v,axis=1)

def reference_samples(refs):
    samples = []
    for ref in refs:
        length = math.dist(ref["p1"], ref["p2"])
        if not math.isfinite(length) or length <= 0:
            raise ValueError(f"Invalid reference segment {ref['id']}")
        samples.append(np.linspace(ref["p1"], ref["p2"], math.ceil(length / 0.01) + 1))
    return samples


def evaluate_predictions(refs, predictions, samples=None):
    if samples is None:
        samples = reference_samples(refs)
    pairs, details = matching(predictions, refs)
    matches = {}
    for gi, pi in sorted(pairs.items()):
        ref = refs[gi]
        error = distances(samples[gi], predictions[pi])
        matches[str(gi)] = {
            "prediction_index": pi, "reference_id": ref["id"],
            "N": len(error), "sum_sq": float(error @ error), "MaxRes": float(error.max()),
            "geometry": details[gi, pi],
        }
    count = len(pairs)
    return {"TP": count, "FP": len(predictions) - count, "FN": len(refs) - count, "matches": matches}


def summarize(rows, common):
    tp = sum(row["TP"] for row in rows)
    fp = sum(row["FP"] for row in rows)
    fn = sum(row["FN"] for row in rows)
    errors = [row["matches"][str(index)] for row, indices in zip(rows, common) for index in indices]
    count = sum(error["N"] for error in errors)
    return {
        "TP": tp, "FP": fp, "FN": fn,
        "Precision": 100 * tp / (tp + fp) if tp + fp else 0.0,
        "Recall": 100 * tp / (tp + fn) if tp + fn else 0.0,
        "F1": 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0,
        "RMSE": math.sqrt(math.fsum(error["sum_sq"] for error in errors) / count) if count else None,
        "MaxRes": max((error["MaxRes"] for error in errors), default=None),
        "N_eval": count,
    }


def print_table(summary):
    print("Method | TP | FP | FN | Precision (%) | Recall (%) | F1 (%) | RMSE (m) | MaxRes (m) | Mean (ms/frame)")
    for name, row in summary.items():
        values = [str(row[key]) for key in ("TP", "FP", "FN")]
        values += [f'{row[key]:.2f}' for key in ("Precision", "Recall", "F1")]
        values += ["N/A" if row[key] is None else f'{row[key]:.6f}' for key in ("RMSE", "MaxRes")]
        values += [f'{row["mean_ms"]:.2f}'] if "mean_ms" in row else ["N/A"]
        print(name + " | " + " | ".join(values))


def save_table(output, stem, result):
    lines = [f"Table {result['table']} results", "",
             f"Frames={result['frames']}; Reference segments={result['references']}; Common reference segments={result['common_references']}.",
             f"Timed repetitions per frame and method={result['repeats']}; Backend initialization={result['backend_setup_ms']:.6f} ms.", "",
             "Method | TP/FP/FN | Precision(%) | Recall(%) | F1(%) | RMSE(m) | MaxRes(m) | Mean time (ms/frame)"]
    def fmt(value):
        return "N/A" if value is None else f"{value:.12f}"
    def errors(matches):
        count = sum(row['N'] for row in matches)
        return count, math.sqrt(math.fsum(row['sum_sq'] for row in matches) / count) if count else None, max((row['MaxRes'] for row in matches), default=None)
    for method, row in result['summary'].items():
        lines.append(f"{method} | {row['TP']}/{row['FP']}/{row['FN']} | {row['Precision']:.6f} | {row['Recall']:.6f} | {row['F1']:.6f} | {fmt(row['RMSE'])} | {fmt(row['MaxRes'])} | {row['mean_ms']:.6f}")
    lines += ["", f"Per-frame matches, errors, and fitting times (mean of {result['repeats']} runs per frame)"]
    for frame in result['per_frame']:
        lines += ["", f"{frame['frame']}: Source frame index={frame['source_frame_index']}; Raw point count={frame['point_count']}; Reference segments={frame['references']}.",
                  f"Common reference IDs: {frame['common_reference_ids']}."]
        refs = frame['reference_segments']
        for method, row in frame['evaluation'].items():
            matches = row['matches']
            n, rmse, maximum = errors([matches[str(index)] for index in frame['common_reference_indices']])
            tp, fp, fn = row['TP'], row['FP'], row['FN']
            precision = 100 * tp / (tp + fp) if tp + fp else 0.
            recall = 100 * tp / (tp + fn) if tp + fn else 0.
            f1 = 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.
            lines.append(f"{method}: TP={tp}, FP={fp}, FN={fn}; Precision={precision:.6f}%, Recall={recall:.6f}%, F1={f1:.6f}%; Common-set RMSE={fmt(rmse)} m, MaxRes={fmt(maximum)} m, Sample count={n}; Fitting time={frame['frame_mean_ms'][method]:.6f} ms.")
            n, rmse, maximum = errors(list(matches.values()))
            lines.append(f"  All matched segments: Sample count={n}, RMSE={fmt(rmse)} m, MaxRes={fmt(maximum)} m.")
            predictions = frame['predictions'][method]
            for index, match in sorted(matches.items(), key=lambda pair: int(pair[0])):
                geo = match['geometry']
                prediction = predictions[match['prediction_index']]
                lines.append(f"  Reference {match['reference_id']} -> output {prediction['id']}: Angle difference={geo['angle_deg']:.9f} deg, Normal distance={geo['normal_m']:.12f} m, IoU={geo['iou']:.9f}, Mean endpoint error={geo['endpoint_mean_m']:.12f} m; Output length={prediction['length']:.12f} m, Support point count={prediction['n_points']}; Sample count={match['N']}, RMSE={math.sqrt(match['sum_sq'] / match['N']):.12f} m, MaxRes={match['MaxRes']:.12f} m.")
            missed = [ref['id'] for index, ref in enumerate(refs) if str(index) not in matches]
            assigned = {match['prediction_index'] for match in matches.values()}
            false_positives = [prediction['id'] for index, prediction in enumerate(predictions) if index not in assigned]
            lines.append(f"  Missed references: {missed}; False-positive outputs: {false_positives}.")
            lines.append("  Fitting times (ms): " + ", ".join(f"{value:.6f}" for value in frame['timing_ms'][method]) + ".")
    (output / "experiment_log_new.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


TABLE = 3
DATASET = "Intel"
FRAME_COUNT = 40
REPEATS = 5
DATA_DIR = "40_Frames_Reference_Segments_and_Annotations/Scan_Data_and_Annotations"
PROFILE = "standard"

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default=DATA_DIR, help="Annotation JSON directory, relative to this script")
    parser.add_argument("--output-dir", default=".", help="Output directory, relative to this script")
    parser.add_argument("--repeats", type=int, default=REPEATS, help="Timed repetitions per frame and method")
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("--repeats must be positive")
    paths = sorted(relative_path(args.data_dir).glob("inter*.json"), key=lambda path: int(path.stem[5:]))
    if len(paths) != FRAME_COUNT:
        parser.error(f"Expected {FRAME_COUNT} input JSON files, found {len(paths)}")
    feature = load_method("feature")
    print("Preparing extraction backend...", flush=True)
    setup_ms = feature.prepare_backend(sensor_config(feature, DATASET, profile=PROFILE))
    frames = []
    for index, path in enumerate(paths):
        data = read_json(path)
        if data["dataset"] != DATASET:
            raise ValueError(f"Unexpected dataset in {path.name}")
        points = np.array([[p["x"], p["y"]] for p in data["points"]], dtype=float)
        refs = sorted(data["reference_segments"], key=lambda row: row["id"])
        samples = reference_samples(refs)
        runners, parameters = {}, {}
        for method in METHOD_FILES:
            runners[method], parameters[method] = build_runner(method, path, DATASET, PROFILE)
        if index == 0:
            for runner in runners.values():
                effective_segments(runner(points.copy()))
        times = {method: [] for method in METHOD_FILES}
        predictions = {}
        for repeat in range(args.repeats):
            methods = list(METHOD_FILES)
            offset = (index + repeat) % len(methods)
            for method in methods[offset:] + methods[:offset]:
                inputs = points.copy()
                runner = runners[method]
                started = time.perf_counter_ns()
                segments = effective_segments(runner(inputs))
                elapsed_ms = (time.perf_counter_ns() - started) / 1e6
                current = serialize(segments)
                if repeat and current != predictions[method]:
                    raise RuntimeError(f"Repeated fitting changed predictions: {path.stem}, {method}")
                predictions[method] = current
                times[method].append(elapsed_ms)
        evaluation = {method: evaluate_predictions(refs, predictions[method], samples)
                      for method in METHOD_FILES}
        common = sorted(set.intersection(*(set(row["matches"]) for row in evaluation.values())), key=int)
        frames.append({
            "frame": path.stem, "input": path.name, "point_count": len(points),
            "references": len(refs), "reference_segments": refs,
            "source_frame_index": data.get("frame_index_zero_based", data.get("source_scan_ordinal_zero_based")),
            "predictions": predictions, "evaluation": evaluation,
            "common_reference_indices": common,
            "common_reference_ids": [refs[int(i)]["id"] for i in common],
            "timing_ms": times, "frame_mean_ms": {method: math.fsum(values) / len(values)
                                                  for method, values in times.items()},
            "parameters": parameters,
        })
        print(f"Completed {index + 1}/{len(paths)}: {path.stem}", flush=True)
    common = [frame["common_reference_indices"] for frame in frames]
    summary = {}
    for method in METHOD_FILES:
        summary[method] = summarize([frame["evaluation"][method] for frame in frames], common)
        summary[method]["mean_ms"] = math.fsum(frame["frame_mean_ms"][method] for frame in frames) / len(frames)
    result = {
        "table": TABLE, "frames": len(frames), "references": sum(frame["references"] for frame in frames),
        "common_references": sum(map(len, common)), "repeats": args.repeats,
        "backend_setup_ms": setup_ms,
        "timing_protocol": {
            "clock": "perf_counter_ns",
            "interval": "in-memory points and frame layout to screened final segments",
            "warmup_calls_per_method": 1,
            "serial": True,
            "order": "rotate by frame index and repetition",
            "nominal_repeats_per_frame": REPEATS,
            "aggregation": "arithmetic mean per frame, then arithmetic mean across frames",
        },
        "summary": summary, "per_frame": frames,
    }
    output = relative_path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    save_table(output, f"table{TABLE}", result)
    print_table(summary)
    print(f"Saved {output / 'experiment_log_new.txt'}", flush=True)


if __name__ == "__main__":
    main()

