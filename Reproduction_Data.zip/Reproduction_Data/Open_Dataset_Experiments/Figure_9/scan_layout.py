"""Read arranged point clouds and restore each scan's sensor coordinates."""

import json

import numpy as np


def load_scan(path):
    with path.open("r", encoding="utf-8-sig") as stream:
        data = json.load(stream)
    points = np.array([[p["x"], p["y"]] for p in data.get("points", [])],
                      dtype=np.float64).reshape(-1, 2)
    frames = data.get("metadata", {}).get("frames", [])
    if not isinstance(frames, list):
        raise ValueError("Frame layout metadata must be a list")
    return points, frames


def original_scans(points, frames):
    expected_start = 0
    for frame in sorted(frames, key=lambda item: int(item["point_start"])):
        start = int(frame["point_start"])
        count = int(frame["point_count"])
        stop = start + count
        if start != expected_start or count < 2 or stop > len(points):
            raise ValueError(f"Invalid point range [{start}, {stop}) in scan layout")
        center = np.array([frame["source_center"][axis] for axis in ("x", "y")], dtype=float)
        offset = np.array([frame["layout_offset"][axis] for axis in ("x", "y")], dtype=float)
        if not np.isfinite([center, offset]).all():
            raise ValueError("Scan layout coordinates must be finite")
        yield start, points[start:stop] - offset + center, center, offset
        expected_start = stop
    if expected_start != len(points):
        raise ValueError("Scan layout does not cover the complete point cloud")
