"""Compact entry point for the archived Intel analysis.

python analyze_inter.py --stage all
python analyze_inter.py --verify-only
python analyze_inter.py --restore-to D:/analysis/Inter_full
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "reproducibility.zip"
SKIP = {".mplconfig", ".numba_cache", "__pycache__"}
PUBLISHED = ("result.txt", "model_diagnostics.png", "extraction_sensitivity.png")


def unpack(destination):
    destination = destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE) as z:
        manifest = json.loads(z.read("archive_manifest.json"))["sha256"]
        for entry in z.infolist():
            target = (destination / entry.filename).resolve()
            if not target.is_relative_to(destination):
                raise ValueError(f"Archive path exceeds destination: {entry.filename}")
        if z.testzip() is not None:
            raise ValueError("Archive integrity check failed.")
        for name, expected in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise ValueError(f"Archive fingerprint mismatch: {name}")
        z.extractall(destination)


def pack(work):
    files = sorted(p for p in work.rglob("*") if p.is_file()
                   and p.name != "archive_manifest.json"
                   and not any(part in SKIP for part in p.relative_to(work).parts))
    manifest = {p.relative_to(work).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in files}
    temporary = ARCHIVE.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in files:
            z.write(p, p.relative_to(work).as_posix())
        z.writestr("archive_manifest.json", json.dumps({"sha256": manifest,
            "description": "Reproduction scripts, results, settings, and frozen extractor; regenerable caches excluded."}, indent=2))
    with zipfile.ZipFile(temporary) as z:
        if z.testzip() is not None:
            raise ValueError("Updated archive integrity check failed.")
        for name, expected in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise ValueError(f"Updated archive fingerprint mismatch: {name}")
    temporary.replace(ARCHIVE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("all", "statistics", "extraction", "report"), default="all")
    parser.add_argument("--config", type=Path, default=ROOT / "config.json")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--verify-only", action="store_true")
    action.add_argument("--restore-to", type=Path)
    args = parser.parse_args()
    if args.restore_to:
        target = args.restore_to.resolve()
        if target == ROOT or (target.exists() and any(target.iterdir())):
            raise ValueError("Choose an empty restoration directory separate from this folder.")
        unpack(target)
        print(f"Complete reproduction files restored to {target}")
        return
    configuration = args.config.resolve()
    settings = json.loads(configuration.read_text(encoding="utf-8-sig"))
    settings["source_root"] = str((configuration.parent / settings["source_root"]).resolve())
    temporary_parent = Path(tempfile.gettempdir()).resolve()
    with tempfile.TemporaryDirectory(prefix="intel_reproduction_", dir=temporary_parent) as temporary:
        work = Path(temporary).resolve()
        if work.parent != temporary_parent or not work.name.startswith("intel_reproduction_"):
            raise ValueError("Temporary workspace location failed validation.")
        unpack(work)
        (work / "config.json").write_text(json.dumps(settings, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        if args.verify_only:
            for name in ("verify_method.py", "verify_outputs.py"):
                subprocess.run([sys.executable, "-B", str(work/name)], cwd=work, check=True)
            print("Archive verification and repeat-extraction checks passed.")
            return
        subprocess.run([sys.executable, "-B", str(work/"analyze_inter.py"),
                        "--stage", args.stage], cwd=work, check=True)
        pack(work)
        if args.stage in ("all", "report"):
            for name in PUBLISHED:
                shutil.copy2(work/name, ROOT/name)
        print(f"Completed {args.stage}; detailed outputs saved in {ARCHIVE.name}.")
        print(f"Reports and figures: {ROOT}")


if __name__ == "__main__":
    main()
