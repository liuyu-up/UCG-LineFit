"""Reproduce Figure 12 using full Table 5 scans and fixed display windows.

Keep this folder inside the ablation experiment directory with the shared
methods and Table 5 scans. Run python reproduce_fig12.py from this folder.
Each manifest points to a complete scan using a relative path.
"""

import argparse
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import ablation_no_uncertainty as experiment
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
import numpy as np


EXAMPLES = (
    "Fig12_ab_Heuristic_Corridor02520.json",
    "Fig12_cd_FixedHuber_Intel01040.json",
    "Fig12_ef_GraphOff_Intel01641.json",
)
POINT_COLOR = "#0b1f5b"
SEGMENT_COLOR = "#ff8c00"


def segments_in_window(result, start, stop):
    segments = []
    for segment in result["effective_segments"]:
        if min(stop, segment["idx_end"] + 1) - max(start, segment["idx_start"]) < 2:
            continue
        length = math.dist(segment["p1"], segment["p2"])
        if segment["n_points"] >= 12 and math.isfinite(length) and length >= .30:
            segments.append(segment)
    return segments


def draw_panel(ax, measured, segments, xlim, ylim):
    ax.scatter(measured[:, 0], measured[:, 1], s=18, color=POINT_COLOR,
               edgecolors="#152536", linewidths=.35, zorder=2)
    for segment in segments:
        a, b = segment["p1"], segment["p2"]
        ax.plot([a[0], b[0]], [a[1], b[1]], color=SEGMENT_COLOR, linewidth=2.1,
                solid_capstyle="round", zorder=3)
    ax.set(xlim=xlim, ylim=ylim, xlabel="X (m)", ylabel="Y (m)", aspect="equal")
    ax.xaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    ax.grid(True, color="#d9dfe6", linewidth=.55, linestyle="--")
    ax.set_axisbelow(True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="../fig12_new.pdf", type=Path,
                        help="Output vector PDF, relative to this script")
    args = parser.parse_args()

    output = HERE / args.output
    experiment.full.prepare_backend(experiment.full.build_parser().parse_args([]))
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 11, "axes.labelsize": 12, "xtick.labelsize": 11, "ytick.labelsize": 11,
        "axes.unicode_minus": True, "pdf.fonttype": 42,
    })
    fig, axes = plt.subplots(3, 2, figsize=(10.4, 12.453))
    fig.subplots_adjust(left=.078, right=.98, top=.938, bottom=.108, wspace=.22, hspace=.45)

    for row, filename in enumerate(EXAMPLES):
        crop = experiment.read_json(HERE / filename)
        dataset, frame, variant = crop["dataset"], crop["source_frame"], crop["ablation"]
        source = Path(crop["source_full_scan"])
        if source.is_absolute():
            raise ValueError(f"Expected a relative full-scan path in {filename}")
        data = experiment.read_json(HERE / source)
        if (data["name"], data["dataset"]) != (frame, dataset):
            raise ValueError(f"Unexpected scan identity for {frame}")
        interval = crop["source_point_slice"]
        start, stop = interval["start_zero_based"], interval["end_exclusive"]
        points = data["points"]
        if (data["frame_index_zero_based"] != crop["source_frame_index_zero_based"]
                or len(points) != crop["source_full_point_count"]
                or not 0 <= start < stop <= len(points)
                or points[start:stop] != crop["points"]):
            raise ValueError(f"Display fragment does not match the full scan for {frame}")
        measured = np.asarray([[p["x"], p["y"]] for p in points[start:stop]], dtype=float)
        xlim, ylim = crop["view"]["xlim"], crop["view"]["ylim"]
        for col, method in enumerate(("Full", variant)):
            result = experiment.run_method(data, method)
            segments = segments_in_window(result, start, stop)
            ax = axes[row, col]
            draw_panel(ax, measured, segments, xlim, ylim)
            box = ax.get_position()
            fig.text((box.x0+box.x1)/2, box.y0-.055, f"({'abcdef'[2*row+col]}) {method}",
                     ha="center", va="center", fontsize=12)
            lengths = ", ".join(f'{math.dist(s["p1"], s["p2"]):.3f} m' for s in segments)
            print(f"{frame} {method}: {len(segments)} segments" + (f" ({lengths})" if lengths else ""), flush=True)
        y = max(ax.get_position().y1 for ax in axes[row]) + .018
        fig.text(.53, y, f"{dataset}  /  {frame}", ha="center", va="center", fontsize=11, fontweight="bold")

    handles = [Line2D([], [], color=POINT_COLOR, marker="o", linestyle="", markersize=4.2),
               Line2D([], [], color=SEGMENT_COLOR, linewidth=2.1)]
    fig.legend(handles, ["Raw points", "Fitted segments"], loc="lower center",
               bbox_to_anchor=(.53, .018), ncol=2, frameon=False, handlelength=2.3, fontsize=11)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, format="pdf", metadata={"Title": "Figure 12", "Creator": None, "Producer": None, "Author": None, "CreationDate": None, "ModDate": None})
    if output == HERE / "../fig12_new.pdf":
        (output.parent / "ablation_combined_new.pdf").write_bytes(output.read_bytes())
    plt.close(fig)
    print(output.resolve(), flush=True)


if __name__ == "__main__":
    main()
