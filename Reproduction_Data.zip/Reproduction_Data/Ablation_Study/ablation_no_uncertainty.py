"""Run the Heuristic ablation or evaluate all four methods for Table 5."""
import os
import sys
sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[_key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import copy
import hashlib
import json
import math
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from contextlib import contextmanager, nullcontext
from pathlib import Path

import numpy as np

import feature as full


HERE = Path(__file__).resolve().parent
METHODS = ("Full", "Heuristic", "Fixed-Huber", "Graph-off")
CORE_SHA256 = "66a738747830275561dc8a4a5f8cf8a366c0261fcf56565485e00d3e0fd00a0c"
# Angle increment (rad), range noise (m), angle noise (rad).
SENSOR_CALIBRATION = {
    "Intel": (0.017453293006, 0.006210466855951062, 0.0012414863603140256),
    "R2000": (0.0026179938577115536, 0.007332930140722351, 0.0012673763),
}


def make_config(data):
    """The same sensor parameters used for the final 30-frame Table 5."""
    dataset = data["dataset"]
    if dataset not in SENSOR_CALIBRATION:
        raise ValueError("dataset must be Intel or R2000")
    angle_increment, range_noise, angle_noise = SENSOR_CALIBRATION[dataset]
    metadata = data.get("metadata", {})
    cfg = full.build_parser().parse_args([])
    cfg.native_enable = True
    cfg.angle_increment = abs(float(metadata.get("angle_increment_rad", angle_increment)))
    cfg.sensor_range_noise_m = range_noise
    cfg.sensor_angle_noise_rad = angle_noise
    cfg.sensor_range_noise_slope = 0.
    return cfg


def configure(args):
    cfg = copy.copy(args)
    cfg.uncertainty_enable = False
    cfg.adaptive_merge_enable = False
    return cfg

def heuristic_edge(m,a,b,points,angle_increment,args):
    base=m.base
    if b.idx_start<a.idx_start:a,b=b,a
    idx_gap=int(b.idx_start-a.idx_end)
    if idx_gap<0 or idx_gap>args.graph_max_index_gap:return None
    angle=base.segment_included_angle_deg(a,b)
    if angle>args.graph_angle_deg:return None
    gap=base.segment_endpoint_to_endpoint_distance(a,b)
    axis_gap=base.segment_support_axis_distance(a,b)
    r=.5*(np.linalg.norm(base.segment_midpoint(a))+np.linalg.norm(base.segment_midpoint(b)))
    gap_limit=max(args.graph_gap_scale,1.)*m._ORIGINAL_MERGE_GAP_THR(r,angle_increment,args.merge_gap0_m,args.merge_cgap)
    band=max(args.graph_perp_floor_m,m._ORIGINAL_MERGE_PERP_THR(r,args.merge_perp_base_m,args.merge_perp_cr))+.75*gap
    if gap>gap_limit or axis_gap>band:return None
    cost=(args.graph_weight_angle*angle/max(args.graph_angle_deg,1e-6)+args.graph_weight_gap*gap/max(gap_limit,1e-6)
          +args.graph_weight_perp*axis_gap/max(band,1e-6)+args.graph_weight_index*idx_gap/max(args.graph_max_index_gap,1))
    if cost>args.graph_edge_cost_max:return None
    return m.FragmentEdge(-1,-1,float(cost),float(angle),float(gap),float(axis_gap),float(band))

@contextmanager
def ablation_context(points=None):
    original = full._fragment_edge
    full._fragment_edge = lambda *args: heuristic_edge(full, *args)
    try:
        yield
    finally:
        full._fragment_edge = original

def extract_segments(points, args=None):
    cfg = configure(args if args is not None else full.build_parser().parse_args([]))
    with ablation_context(points):
        return full.extract_segments(points, cfg)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def run_method(data, method):
    if method not in METHODS:
        raise ValueError(method)
    points = np.asarray([[p["x"], p["y"]] for p in data["points"]], dtype=float)
    cfg = make_config(data)
    context = nullcontext()
    if method == "Heuristic":
        cfg = configure(cfg)
        context = ablation_context(points)
    elif method == "Fixed-Huber":
        import ablation_no_adaptive_huber as fixed_huber

        cfg = fixed_huber.configure(cfg)
        context = fixed_huber.ablation_context(points)
    elif method == "Graph-off":
        import ablation_no_graph as graph_off

        cfg = graph_off.configure(cfg)
        context = graph_off.ablation_context(points)
    full._LAST_DIAGNOSTICS.clear()
    with context:
        start = time.perf_counter_ns()
        segments, _ = full.extract_segments(points, cfg)
        lengths = [math.dist(s.p1, s.p2) for s in segments]
        accepted = [i for i, (s, length) in enumerate(zip(segments, lengths))
                    if s.n_points >= 12 and math.isfinite(length) and length >= .30]
        seconds = (time.perf_counter_ns() - start) / 1e9
    serialized = [
        {"p1": s.p1.tolist(), "p2": s.p2.tolist(),
         "idx_start": int(s.idx_start), "idx_end": int(s.idx_end),
         "n_points": int(s.n_points), "length": length,
         "rms": float(s.rms), "max_res": float(s.max_res),
         "is_fragment": bool(s.is_fragment), "merged_from": s.merged_from}
        for s, length in zip(segments, lengths)
    ]
    return {"segments": serialized,
            "effective_segments": [serialized[i] for i in accepted],
            "parameters": vars(cfg), "seconds": seconds}

def geometry(p,g):
    a,b,c,d=map(np.asarray,[p['p1'],p['p2'],g['p1'],g['p2']])
    lp,lg=np.linalg.norm(b-a),np.linalg.norm(d-c)
    if min(lp,lg)<=1e-12:return {'eligible':False}
    u,v=(b-a)/lp,(d-c)/lg
    angle=float(np.degrees(np.arccos(np.clip(abs(u@v),0.,1.))))
    nu,nv=np.array([-u[1],u[0]]),np.array([-v[1],v[0]])
    normal=float((abs((a-c)@nv)+abs((b-c)@nv)+abs((c-a)@nu)+abs((d-a)@nu))/4)
    lo,hi=sorted([(a-c)@v,(b-c)@v]);overlap=max(0.,min(hi,lg)-max(lo,0.))
    iou=float(overlap/(lg+hi-lo-overlap))
    endpoint=float(min(np.linalg.norm(a-c)+np.linalg.norm(b-d),np.linalg.norm(a-d)+np.linalg.norm(b-c))/2)
    return {'eligible':angle<=5. and normal<=.02 and iou>=.5,
            'angle_deg':angle,'normal_m':normal,'iou':iou,'endpoint_mean_m':endpoint}

def matching(pred,refs):
    from scipy.optimize import linear_sum_assignment

    stats={(gi,pi):geometry(p,g) for gi,g in enumerate(refs) for pi,p in enumerate(pred)}
    eligible={k:v['endpoint_mean_m'] for k,v in stats.items() if v['eligible']}
    # An unmatched penalty exceeds the maximum possible total eligible cost,
    # so cardinality has strict priority over endpoint distance.
    penalty=(min(len(pred),len(refs))+1)*(max(eligible.values(),default=0.)+1.)
    def solve(gs,ps):
        if not gs:return 0,0.,{}
        cost=np.full((len(gs),len(ps)+len(gs)),penalty)
        cost[:,:len(ps)]=penalty*3
        for r,gi in enumerate(gs):
            for c,pi in enumerate(ps):
                if (gi,pi) in eligible:cost[r,c]=eligible[gi,pi]
        ii,jj=linear_sum_assignment(cost)
        pairs={gs[i]:ps[j] for i,j in zip(ii,jj) if j<len(ps) and (gs[i],ps[j]) in eligible}
        return len(pairs),math.fsum(eligible[k] for k in pairs.items()),pairs
    gs=list(range(len(refs)));ps=list(range(len(pred)))
    target_n,target_cost,_=solve(gs,ps)
    ans={}
    # Lexicographic reference ID then prediction ID, with unmatched last.
    # Re-solving the residual assignment avoids epsilon perturbing costs.
    for gi in gs:
        remaining=[g for g in gs if g>gi]
        choices=[p for p in ps if (gi,p) in eligible]+[None]
        for pi in choices:
            rest=[p for p in ps if p!=pi]
            n,c,_=solve(remaining,rest)
            own=0. if pi is None else eligible[gi,pi]
            if n+(pi is not None)==target_n and math.isclose(c+own,target_cost,rel_tol=1e-13,abs_tol=1e-12):
                if pi is not None:
                    ans[gi]=pi;ps.remove(pi);target_n-=1
                target_cost-=own
                break
        else:raise AssertionError('No canonical optimal assignment')
    return ans,stats

def distances(points,pred):
    x=np.asarray(points);a,b=np.asarray(pred['p1']),np.asarray(pred['p2']);v=b-a
    t=np.clip((x-a)@v/(v@v),0.,1.)
    return np.linalg.norm(x-a-t[:,None]*v,axis=1)

def discover_frames(data_dir, labels_dir):
    records = []
    for dataset, count in (("Intel", 20), ("R2000", 10)):
        pdfs = sorted((labels_dir / dataset).glob("*.pdf"))
        raws = {p.stem: p for p in (data_dir / dataset).glob("*.json")}
        labels = {p.stem: p for p in (labels_dir / dataset).glob("*.json")}
        names = {p.stem for p in pdfs}
        if len(names) != count or names != set(raws) or names != set(labels):
            raise ValueError(f"{dataset}: expected {count} matching raw JSON/PDF/annotation files")
        for pdf in pdfs:
            records.append((str(raws[pdf.stem]), str(labels[pdf.stem])))
    # Process the slower real-world frames first.
    return sorted(records, key=lambda r: (Path(r[0]).parent.name != "R2000", Path(r[0]).stem))

def evaluate_frame(record):
    raw_path, label_path = map(Path, record)
    data = read_json(raw_path)
    annotation = data if label_path == raw_path else read_json(label_path)
    assert data["name"] == raw_path.stem == annotation["name"] == label_path.stem
    assert data["dataset"] == annotation["dataset"]
    scan_index = data.get("source_scan_ordinal_zero_based", data.get("frame_index_zero_based"))
    assert scan_index == annotation["frame_index_zero_based"]
    assert data["points"] == annotation["points"]
    refs = sorted(annotation["reference_segments"], key=lambda s: s["id"])
    assert [s["id"] for s in refs] == list(range(1, len(refs) + 1))
    samples = {}
    for g in refs:
        length = math.dist(g["p1"], g["p2"])
        if not math.isfinite(length) or length <= 0:
            raise ValueError(f"Invalid reference segment {g['id']} in {label_path.name}")
        samples[g["id"]] = np.linspace(g["p1"], g["p2"], math.ceil(length / .01) + 1)
    frame = {"frame": data["name"], "dataset": data["dataset"], "G": len(refs),
             "point_count": len(data["points"]), "source_frame_index": scan_index,
             "references": refs, "eval": {}}
    for method in METHODS:
        result = run_method(data, method)
        predictions = result["effective_segments"]
        pairs, geometry_details = matching(predictions, refs)
        matches = []
        for gi, pi in sorted(pairs.items()):
            rr = distances(samples[refs[gi]["id"]], predictions[pi])
            matches.append({"reference_id": refs[gi]["id"], "prediction_index": pi,
                            "N_eval": len(rr), "sum_sq": float(rr @ rr), "MaxRes": float(rr.max()),
                            "geometry": geometry_details[gi, pi]})
        tp = len(matches)
        frame["eval"][method] = {
            "P_all": len(result["segments"]), "P": len(predictions),
            "TP": tp, "FP": len(predictions) - tp, "FN": len(refs) - tp,
            "matches": matches, "seconds": result["seconds"],
            "predictions": [{key: pred[key] for key in ("p1", "p2", "length", "n_points")}
                            for pred in predictions]}
    return frame

def aggregate(frames):
    totals = {m: {k: 0 for k in ("TP", "FP", "FN", "P", "P_all", "N_eval", "sum_sq", "MaxRes")} for m in METHODS}
    common_count = 0
    for frame in frames:
        maps = {m: {v["reference_id"]: v for v in frame["eval"][m]["matches"]} for m in METHODS}
        common = set.intersection(*(set(maps[m]) for m in METHODS))
        common_count += len(common)
        for method in METHODS:
            total = totals[method]
            for key in ("TP", "FP", "FN", "P", "P_all"):
                total[key] += frame["eval"][method][key]
            for reference_id in sorted(common):
                for key in ("N_eval", "sum_sq"):
                    total[key] += maps[method][reference_id][key]
                total["MaxRes"] = max(total["MaxRes"], maps[method][reference_id]["MaxRes"])
    reference_count = sum(f["G"] for f in frames)
    for total in totals.values():
        tp, fp, fn = total["TP"], total["FP"], total["FN"]
        assert tp + fn == reference_count and tp + fp == total["P"]
        total["Precision"] = 100 * tp / (tp + fp) if tp + fp else 0.
        total["Recall"] = 100 * tp / (tp + fn) if tp + fn else 0.
        total["F1"] = 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.
        total["RMSE"] = math.sqrt(total["sum_sq"] / total["N_eval"]) if total["N_eval"] else None
        if not total["N_eval"]:
            total["MaxRes"] = None
    return {"frames": len(frames), "G": reference_count, "NC": common_count,
            "common_percentage": 100 * common_count / reference_count if reference_count else 0.,
            "metrics": totals}

def prepare_worker():
    full.prepare_backend(full.build_parser().parse_args([]))


def evaluate_frames(records, workers):
    if workers == 1:
        prepare_worker()
        for record in records:
            yield evaluate_frame(record)
        return
    with ProcessPoolExecutor(max_workers=workers, initializer=prepare_worker) as pool:
        futures = [pool.submit(evaluate_frame, record) for record in records]
        for future in as_completed(futures):
            yield future.result()


def main(default_method="Full"):
    parser = argparse.ArgumentParser(description=__doc__)
    combined_dir = HERE / "Annotations_and_Raw_Data"
    if combined_dir.is_dir():
        data_dir = labels_dir = combined_dir
    else:
        data_dir = HERE / "01_Raw_Data"
        labels_dir = HERE / "Point_Cloud_Visualizations"
    parser.add_argument("--data-dir", type=Path, default=data_dir)
    parser.add_argument("--labels-dir", type=Path, default=labels_dir)
    parser.add_argument("--workers", type=int, default=1,
                        help="Frame workers; each worker initializes its own extraction backend")
    parser.add_argument("--input", type=Path, help="Fit one raw JSON frame and print predictions")
    parser.add_argument("--method", choices=METHODS, default=default_method)
    parser.add_argument("--all", action="store_true", help="Recompute all four methods on all 30 frames (default without --input)")
    parser.add_argument("--json", action="store_true", help="Print final JSON, including frame-level matching results")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    if args.input and args.all:
        parser.error("--input and --all are mutually exclusive")
    if sha256(HERE / "feature.py") != CORE_SHA256:
        raise RuntimeError("The frozen Full core has changed")
    if args.input:
        data = read_json(HERE / args.input)
        prepare_worker()
        print(json.dumps({"frame": data["name"], "method": args.method, **run_method(data, args.method)}, ensure_ascii=False))
        return
    records = discover_frames((HERE / args.data_dir).resolve(), (HERE / args.labels_dir).resolve())
    started = time.monotonic()
    frames = []
    for frame in evaluate_frames(records, args.workers):
        frames.append(frame)
        print(f"Completed {len(frames)}/30 frames: {frame['frame']}", file=sys.stderr, flush=True)
    frames.sort(key=lambda f: f["frame"])
    results = {scope: aggregate(fs) for scope, fs in (
        ("Combined", frames),
        ("Intel", [f for f in frames if f["dataset"] == "Intel"]),
        ("R2000", [f for f in frames if f["dataset"] == "R2000"]))}
    if args.json:
        print(json.dumps({"results": results, "per_frame": frames, "elapsed_seconds": time.monotonic() - started}, ensure_ascii=False))
        return
    for scope, result in results.items():
        print(f"\n{scope}: frames={result['frames']}, G={result['G']}, NC={result['NC']}, N_eval={result['metrics']['Full']['N_eval']}")
        print("Method | TP | FP | FN | Precision (%) | Recall (%) | F1 (%) | RMSE (m) | MaxRes (m)")
        for method in METHODS:
            t = result["metrics"][method]
            fields = [f"{t[k]:.2f}" for k in ("Precision", "Recall", "F1")]
            fields += ["N/A" if t[k] is None else f"{t[k]:.6f}" for k in ("RMSE", "MaxRes")]
            print(f"{method} | {t['TP']} | {t['FP']} | {t['FN']} | " + " | ".join(fields))


if __name__ == "__main__":
    main(default_method="Heuristic")
