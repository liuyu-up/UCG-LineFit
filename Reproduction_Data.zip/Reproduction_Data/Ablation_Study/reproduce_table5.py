"""Recompute Table 5 from this folder. Run: python reproduce_table5.py
Dependencies: numpy, scipy, matplotlib; numba enables the accelerated backend.
Relative paths are resolved from the directory containing this script.
"""
import os
import sys
sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import csv
import json
from pathlib import Path

import ablation_no_uncertainty as experiment

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default="Annotations_and_Raw_Data")
    parser.add_argument("--output-dir", default="reproduced")
    parser.add_argument("--workers", type=int, default=1,
                        help="Frame workers; each worker initializes its own extraction backend")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    data = HERE / args.data_dir
    output = HERE / args.output_dir
    records = experiment.discover_frames(data, data)
    frames = []
    for frame in experiment.evaluate_frames(records, args.workers):
        frames.append(frame)
        print(f"Completed {len(frames)}/30: {frame['frame']}", flush=True)
    frames.sort(key=lambda frame: frame["frame"])
    results = {scope: experiment.aggregate(selected) for scope, selected in (
        ("Combined", frames),
        ("Intel", [frame for frame in frames if frame["dataset"] == "Intel"]),
        ("R2000", [frame for frame in frames if frame["dataset"] == "R2000"]),
    )}
    output.mkdir(parents=True, exist_ok=True)
    (output / "table5.json").write_text(
        json.dumps({"results": results, "per_frame": frames, "workers": args.workers,
                    "timing_note": "Per-frame seconds cover fitting and final screening; worker calls may overlap"},
                   ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8")
    fields = ("Scope", "Method", "TP", "FP", "FN", "Precision", "Recall", "F1", "RMSE", "MaxRes")
    with (output / "table5.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for scope, result in results.items():
            print(f"\n{scope}: frames={result['frames']}, references={result['G']}, common={result['NC']}")
            print("Method | TP | FP | FN | Precision (%) | Recall (%) | F1 (%) | RMSE (m) | MaxRes (m)")
            for method, row in result["metrics"].items():
                writer.writerow({"Scope": scope, "Method": method, **{key: row[key] for key in fields[2:]}})
                values = [str(row[key]) for key in ("TP", "FP", "FN")]
                values += [f'{row[key]:.2f}' for key in ("Precision", "Recall", "F1")]
                values += ["N/A" if row[key] is None else f'{row[key]:.6f}' for key in ("RMSE", "MaxRes")]
                print(method + " | " + " | ".join(values))
    print(f"Saved {output / 'table5.csv'}", flush=True)


if __name__ == "__main__":
    main()

