"""Recompute Table 5 from this folder. Run: python reproduce_table5.py
Dependencies: numpy, scipy, matplotlib; numba enables the accelerated backend.
Relative paths are resolved from the directory containing this script.
"""
import os
import sys
sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import csv
import json
import math
from pathlib import Path

import ablation_no_uncertainty as experiment

HERE = Path(__file__).resolve().parent


def error_summary(matches):
    count = sum(match["N_eval"] for match in matches)
    rmse = math.sqrt(math.fsum(match["sum_sq"] for match in matches) / count) if count else None
    maximum = max((match["MaxRes"] for match in matches), default=None)
    return count, rmse, maximum


def number(value, precision=12):
    return "N/A" if value is None else f"{value:.{precision}f}"


def write_log(path, results, frames):
    lines = ["Ablation study experiment results", ""]
    for scope, result in results.items():
        selected = frames if scope == "Combined" else [frame for frame in frames if frame["dataset"] == scope]
        lines.extend([
            "All 30 frames: final Table 5" if scope == "Combined" else f"{scope} results",
            f"Frame count = {result['frames']}; reference segments = {result['G']}; common matches across four methods = {result['NC']}; common evaluation samples = {next(iter(result['metrics'].values()))['N_eval']}.",
            "Method | TP | FP | FN | Precision (%) | Recall (%) | F1 (%) | RMSE (m) | MaxRes (m) | Mean time (ms/frame)",
        ])
        for method, row in result["metrics"].items():
            mean_ms = math.fsum(frame["eval"][method]["seconds"] for frame in selected) * 1000 / len(selected)
            row["mean_ms"] = mean_ms
            values = [str(row[key]) for key in ("TP", "FP", "FN")]
            values += [number(row[key], 6) for key in ("Precision", "Recall", "F1")]
            values += [number(row[key], 6) for key in ("RMSE", "MaxRes")]
            values.append(number(mean_ms, 6))
            lines.append(method + " | " + " | ".join(values))
        lines.append("")
    lines.extend(["Per-frame matches, errors, and fitting times", ""])
    for index, frame in enumerate(frames, 1):
        common = set.intersection(*(set(match["reference_id"] for match in frame["eval"][method]["matches"])
                                    for method in experiment.METHODS))
        refs = {ref["id"]: ref for ref in frame["references"]}
        lines.extend([
            f"[{index:02d}] {frame['frame']} ({frame['dataset']})",
            f"Source frame index={frame['source_frame_index']}; Raw point count={frame['point_count']}; Reference segment count={frame['G']}.",
            "Common reference IDs: " + ", ".join(map(str, sorted(common))) + ".",
        ])
        for method in experiment.METHODS:
            row = frame["eval"][method]
            tp, fp, fn = (row[key] for key in ("TP", "FP", "FN"))
            precision = 100 * tp / (tp + fp) if tp + fp else 0.0
            recall = 100 * tp / (tp + fn) if tp + fn else 0.0
            f1 = 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0
            matched_ids = {match["reference_id"] for match in row["matches"]}
            matched_predictions = {match["prediction_index"] for match in row["matches"]}
            missed = sorted(set(refs) - matched_ids)
            false_positives = [i + 1 for i in range(row["P"]) if i not in matched_predictions]
            lines.extend([
                method,
                f"Reference segment count={frame['G']}, Valid output segment count={row['P']}; TP={tp}, FP={fp}, FN={fn}.",
                f"Precision={precision:.6f}%, Recall={recall:.6f}%, F1={f1:.6f}%.",
                f"Frame fitting runtime: {1000 * row['seconds']:.6f} ms.",
                "Matches: " + ("; ".join(f"Reference {match['reference_id']} -> output {match['prediction_index'] + 1}" for match in row["matches"]) or "none") + ".",
                f"False-positive output IDs: {', '.join(map(str, false_positives)) or 'none'}; Missed reference IDs: {', '.join(map(str, missed)) or 'none'}.",
            ])
            for label, matches in (
                ("common reference set", [match for match in row["matches"] if match["reference_id"] in common]),
                ("all matched segments", row["matches"]),
            ):
                count, rmse, maximum = error_summary(matches)
                lines.append(f"Errors on {label}: Sample count={count}, RMSE={number(rmse)} m, MaxRes={number(maximum)} m.")
            lines.append("Per-segment matches and errors:")
            for match in row["matches"]:
                ref = refs[match["reference_id"]]
                pred = row["predictions"][match["prediction_index"]]
                geometry = match["geometry"]
                suffix = " (in common reference set)" if match["reference_id"] in common else ""
                lines.append(
                    f"  Reference {match['reference_id']} -> output {match['prediction_index'] + 1}{suffix}: "
                    f"Reference length={math.dist(ref['p1'], ref['p2']):.9f} m; "
                    f"Output length={pred['length']:.9f} m, Output support point count={pred['n_points']}; "
                    f"Angle difference={geometry['angle_deg']:.9f} deg, Normal distance={geometry['normal_m']:.12f} m, "
                    f"Projection IoU={geometry['iou']:.9f}, Mean endpoint error={geometry['endpoint_mean_m']:.12f} m; "
                    f"Sample count={match['N_eval']}, RMSE={math.sqrt(match['sum_sq'] / match['N_eval']):.12f} m, "
                    f"MaxRes={match['MaxRes']:.12f} m."
                )
            lines.append("")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default="Annotations_and_Raw_Data")
    parser.add_argument("--output-dir", default=".")
    parser.add_argument("--export-data", action="store_true", help="Also save JSON and CSV results")
    parser.add_argument("--workers", type=int, default=1,
                        help="Frame workers; each worker initializes its own extraction backend")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    data = HERE / args.data_dir
    output = HERE / args.output_dir
    records = experiment.discover_frames(data, data)
    frames = []
    for frame in experiment.evaluate_frames(records, args.workers):
        frames.append(frame)
        print(f"Completed {len(frames)}/30: {frame['frame']}", flush=True)
    frames.sort(key=lambda frame: frame["frame"])
    results = {scope: experiment.aggregate(selected) for scope, selected in (
        ("Combined", frames),
        ("Intel", [frame for frame in frames if frame["dataset"] == "Intel"]),
        ("R2000", [frame for frame in frames if frame["dataset"] == "R2000"]),
    )}
    output.mkdir(parents=True, exist_ok=True)
    write_log(output / "experiment_log_new.txt", results, frames)
    if args.export_data:
        (output / "table5_new.json").write_text(
            json.dumps({"results": results, "per_frame": frames, "workers": args.workers},
                       ensure_ascii=False, indent=2, allow_nan=False) + "\n",
            encoding="utf-8")
    fields = ("Scope", "Method", "TP", "FP", "FN", "Precision", "Recall", "F1", "RMSE", "MaxRes", "mean_ms")
    if args.export_data:
        with (output / "table5_new.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            for scope, result in results.items():
                for method, row in result["metrics"].items():
                    writer.writerow({"Scope": scope, "Method": method, **{key: row[key] for key in fields[2:]}})
    for scope, result in results.items():
        print(f"\n{scope}: frames={result['frames']}, references={result['G']}, common={result['NC']}")
        print("Method | TP | FP | FN | Precision (%) | Recall (%) | F1 (%) | RMSE (m) | MaxRes (m) | Mean time (ms/frame)")
        for method, row in result["metrics"].items():
            values = [str(row[key]) for key in ("TP", "FP", "FN")]
            values += [number(row[key], 2) for key in ("Precision", "Recall", "F1")]
            values += [number(row[key], 6) for key in ("RMSE", "MaxRes", "mean_ms")]
            print(method + " | " + " | ".join(values))
    print(f"Saved {output / 'experiment_log_new.txt'}", flush=True)


if __name__ == "__main__":
    main()

