# -*- coding: utf-8 -*-
#!/usr/bin/env python3
import argparse
import json
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


# ================== SCI���ȫ������ ==================
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 11,
    "axes.labelsize": 12,
    "axes.titlesize": 14,
    "legend.fontsize": 10,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10
})


@dataclass
class Segment:
    idx0: int
    idx1: int
    p0: np.ndarray
    p1: np.ndarray
    n_points: int
    length: float
    is_feature: bool


def load_points(path: Path) -> np.ndarray:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    pts = data.get("points", [])
    return np.array([[p["x"], p["y"]] for p in pts], dtype=np.float64)


def split_runs(points, gap_scale, gap_abs, min_run_points):
    if len(points) < 2:
        return []
    d = np.linalg.norm(points[1:] - points[:-1], axis=1)
    med = float(np.median(d)) if len(d) else 0.0
    thr = gap_abs + gap_scale * max(med, 1e-6)

    runs, s = [], 0
    for i, g in enumerate(d):
        if g > thr:
            if i - s + 1 >= min_run_points:
                runs.append((s, i))
            s = i + 1
    if len(points) - s >= min_run_points:
        runs.append((s, len(points) - 1))
    return runs


def point_line_distances(points, a, b):
    v = b - a
    n = np.linalg.norm(v)
    if n < 1e-12:
        return np.linalg.norm(points - a[None, :], axis=1)
    vn = v / n
    rel = points - a
    proj = rel @ vn
    closest = a + np.outer(proj, vn)
    return np.linalg.norm(points - closest, axis=1)


def iepf_split(points, idx0, idx1, eps, min_pts, out):
    if idx1 - idx0 + 1 < min_pts:
        return
    sub = points[idx0:idx1 + 1]
    dist = point_line_distances(sub, points[idx0], points[idx1])

    if len(dist) <= 2:
        out.append((idx0, idx1))
        return

    imax = np.argmax(dist[1:-1]) + 1
    if dist[imax] > eps:
        mid = idx0 + imax
        iepf_split(points, idx0, mid, eps, min_pts, out)
        iepf_split(points, mid, idx1, eps, min_pts, out)
    else:
        out.append((idx0, idx1))


def simple_feature_filter(points, idx_segments, min_pts, min_len):
    features = []
    for s, e in idx_segments:
        if e - s + 1 < min_pts:
            continue
        if np.linalg.norm(points[e] - points[s]) < min_len:
            continue
        features.append((s, e))
    return features


def fit_segment(points, idx0, idx1):
    seg = points[idx0:idx1 + 1]
    mu = seg.mean(axis=0)
    x = seg - mu
    cov = x.T @ x
    _, vecs = np.linalg.eigh(cov)
    d = vecs[:, -1]
    proj = x @ d
    p0 = mu + np.min(proj) * d
    p1 = mu + np.max(proj) * d

    return Segment(idx0, idx1, p0, p1, len(seg),
                   float(np.linalg.norm(p1 - p0)), True)


def compute_segment_error(points, seg):
    pts = points[seg.idx0:seg.idx1 + 1]
    d = point_line_distances(pts, seg.p0, seg.p1)

    if len(d) == 0:
        return 0, 0, 0

    rms = np.sqrt(np.mean(d ** 2))
    max_res = np.max(d)
    straightness = rms / seg.length if seg.length > 1e-12 else 0
    return rms, max_res, straightness


# ================== ? ���Ż�����Ӿ���ǿ���ģ� ==================
def plot_result(points, segments, out_png):
    fig, ax = plt.subplots(figsize=(16.8, 9.8), dpi=720)
    point_size = 96.0 if len(points) <= 220 else 76.0
    line_width = 7.2
    ax.set_facecolor("#ffffff")

    ax.scatter(
        points[:, 0],
        points[:, 1],
        s=point_size,
        c="#0b1f5b",
        edgecolors="#111827",
        linewidths=1.25,
        alpha=0.98,
        label="Raw points",
        zorder=1,
        antialiased=True,
    )

    drawn = False
    for s in segments:
        ax.plot(
            [s.p0[0], s.p1[0]],
            [s.p0[1], s.p1[1]],
            color="#ff8c00",
            linewidth=line_width,
            alpha=0.98,
            solid_capstyle="round",
            label="Extracted segments" if not drawn else None,
            zorder=3,
            antialiased=True,
        )
        ax.scatter(
            [s.p0[0], s.p1[0]],
            [s.p0[1], s.p1[1]],
            s=86.0,
            c="#ff8c00",
            edgecolors="#111827",
            linewidths=1.08,
            zorder=4,
        )
        drawn = True

    ax.set_xlabel("X (m)", fontsize=24, labelpad=10)
    ax.set_ylabel("Y (m)", fontsize=24, labelpad=10)
    ax.set_title("IEPF Line Extraction Result", fontsize=34, pad=18)
    ax.set_aspect("equal")
    ax.grid(True, linestyle="--", linewidth=0.8, alpha=0.36, zorder=0)
    ax.tick_params(axis="both", which="major", width=1.1, length=6, labelsize=20)
    for spine in ax.spines.values():
        spine.set_linewidth(1.1)

    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    y_min, y_max = np.min(points[:, 1]), np.max(points[:, 1])
    x_span = max(x_max - x_min, 1e-6)
    y_span = max(y_max - y_min, 1e-6)
    ax.set_xlim(x_min - 0.06 * x_span, x_max + 0.34 * x_span)
    ax.set_ylim(y_min - 0.10 * y_span, y_max + 0.10 * y_span)

    ax.legend(
        loc="lower right",
        bbox_to_anchor=(0.985, 0.035),
        borderaxespad=0.0,
        frameon=True,
        framealpha=0.94,
        edgecolor="#d0d0d0",
        fontsize=22,
        markerscale=1.35,
        borderpad=0.52,
        labelspacing=0.42,
        handlelength=2.35,
        handletextpad=0.58,
    )

    fig.subplots_adjust(left=0.09, right=0.985, bottom=0.12, top=0.90)
    plt.savefig(out_png, dpi=720, bbox_inches="tight", pad_inches=0.03)
    plt.close()

# ================== �����̣����䣩 ==================
def run(args):
    points = load_points(Path(args.input))

    runs = split_runs(points, args.gap_scale, args.gap_abs, args.min_run_points)
    if not runs:
        runs = [(0, len(points) - 1)]

    eps = args.eps_a + args.eps_b * np.median(np.linalg.norm(points, axis=1))

    idx_segments = []
    for s, e in runs:
        iepf_split(points, s, e, eps, args.iepf_min_points, idx_segments)

    feature_idx = simple_feature_filter(
        points, idx_segments,
        args.feature_min_points, args.feature_min_len)

    fitted = [fit_segment(points, s, e) for s, e in feature_idx]

    rms_list, max_list, str_list = [], [], []
    for seg in fitted:
        r, m, s = compute_segment_error(points, seg)
        rms_list.append(r)
        max_list.append(m)
        str_list.append(s)

    mean_rms = np.mean(rms_list) if rms_list else 0
    max_res = np.max(max_list) if max_list else 0
    mean_str = np.mean(str_list) if str_list else 0

    plot_result(points, fitted, Path(args.output))

    print("=" * 50)
    print("IEPF Line Extraction Statistics")
    print("=" * 50)
    print(f"Total points          : {len(points)}")
    print(f"Feature segments      : {len(fitted)}")
    print("-" * 50)
    print(f"Mean RMS error        : {mean_rms:.6f}")
    print(f"Max residual error    : {max_res:.6f}")
    print(f"Mean straightness     : {mean_str:.6f}")
    print("=" * 50)


def build_arg_parser():
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="map_points.json")
    p.add_argument("--output", default="result_iepf.png")

    p.add_argument("--gap-scale", type=float, default=8.0)
    p.add_argument("--gap-abs", type=float, default=0.02)
    p.add_argument("--min-run-points", type=int, default=6)

    p.add_argument("--eps-a", type=float, default=0.01)
    p.add_argument("--eps-b", type=float, default=0.003)
    p.add_argument("--iepf-min-points", type=int, default=6)

    p.add_argument("--feature-min-points", type=int, default=12)
    p.add_argument("--feature-min-len", type=float, default=0.30)

    return p


if __name__ == "__main__":
    parser = build_arg_parser()
    run(parser.parse_args())
