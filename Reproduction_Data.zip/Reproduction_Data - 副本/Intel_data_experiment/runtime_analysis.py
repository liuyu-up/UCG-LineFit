#!/usr/bin/env python3
"""Single-scan runtime analysis using the method files beside this script.

Target: Ubuntu 22.04, Python 3.10.12, NumPy 1.24.4.
Default: one warm-up, one uninstrumented measurement, and one separate Full
stage-profile call. Input loading, backend initialization, copies made for
repeatability, plotting, reference scoring, and printing are outside timing.
All measured calls include the final 12-point / 0.30-m acceptance gate.

Only stdout/stderr are used; no result, figure, log, or bytecode file is saved.
Full stage shares are estimates from an instrumented call, normalized to the
uninstrumented runtime. They are not independently measured production times.
The NumPy backend is the default; it is not a claim to reproduce a published
compiled-backend runtime or the paper's complete multi-frame Figure 11.
"""
from __future__ import annotations

import os
import sys

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
             "NUMEXPR_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[_key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import importlib.util
import json
import math
from contextlib import contextmanager
from dataclasses import replace
from functools import wraps
from pathlib import Path
from time import perf_counter_ns

import numpy as np

HERE = Path(__file__).resolve().parent
DATASET = "Intel"
DEFAULT_INPUT = HERE / "annotated_scans_40/data_and_references/inter1.json"
DEFAULT_ANGLE = 0.017453292519943295
METHODS = ("Full", "RANSAC", "IEPF", "SRG")
STAGES = (
    "Preprocessing",
    "Candidate search / gating",
    "Independent TLS-Huber fitting",
    "Endpoints + merge / optimization",
)


def load_module(stem):
    path = HERE / (stem + ".py")
    name = "_runtime_" + DATASET.lower() + "_" + stem
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError("Cannot load method: " + str(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def effective_segments(segments):
    """Preserve each algorithm's internal gates, then apply the common gate."""
    result = []
    for segment in segments:
        count = (int(segment.n_points) if hasattr(segment, "n_points")
                 else len(segment.point_indices))
        length = float(segment.length)
        if count >= 12 and math.isfinite(length) and length >= 0.30:
            result.append(segment)
    return result


class ExclusiveStages:
    """Selected-call timers with child durations subtracted from their parent.

    Calls nested inside preprocessing remain in preprocessing, including its
    provisional fits. Compiled kernels are opaque: their entire duration stays
    in the calling stage. Unclassified orchestration, layout restoration, graph
    recovery, and the final acceptance gate belong to the fourth stage.
    """

    def __init__(self):
        self.totals_ns = [0, 0, 0, 0]
        self.stack = []
        self.wrapped_bindings = 0

    @contextmanager
    def section(self, category):
        if self.stack and self.stack[-1][0] == 0:
            category = 0
        frame = [category, perf_counter_ns(), 0]
        self.stack.append(frame)
        try:
            yield
        finally:
            elapsed = perf_counter_ns() - frame[1]
            self.stack.pop()
            self.totals_ns[category] += elapsed - frame[2]
            if self.stack:
                self.stack[-1][2] += elapsed

    @contextmanager
    def install(self, core):
        # Match actual function objects, including _ORIGINAL_* aliases. Install
        # before _patched_base() so its temporary bindings pick up the wrappers.
        names = {
            0: (
                "_preprocess_points", "preprocess_points",
                "prune_small_noise_runs", "_ORIGINAL_PREPROCESS",
            ),
            1: (
                "extract_all_candidates", "extract_candidates_from_run",
                "_extract_candidates_from_run", "_ORIGINAL_CANDIDATES_RUN",
                "build_candidate_from_window", "extract_endpoint_branch_candidates",
                "split_corner_branches_from_segment", "extend_branch_with_run_context",
                "extend_segment_in_run", "_extend_segment_in_run",
                "_ORIGINAL_EXTEND_SEGMENT", "recover_noise_split_candidates",
                "_recover_noise_split_candidates_python", "recover_dense_vertical_runs",
                "_recover_dense_vertical_runs", "_recover_dense_vertical_runs_python",
                "_dense_window_mask",
            ),
            2: (
                "fit_line_tls_huber", "fit_line_tls_huber_adaptive",
                "_fit_line_tls_huber_adaptive_uncached", "fit_line_tls_core",
                "_fit_line_tls_core", "_ORIGINAL_FIT", "_ORIGINAL_TLS_CORE",
                "estimate_local_noise_sigma_m", "_local_noise_and_tls",
                "robust_refine_segment_points", "fit_windows", "tls_batch",
            ),
            3: (
                "build_segment_from_points", "_build_segment_from_points",
                "_build_segment_geometry", "_ORIGINAL_BUILD_SEGMENT",
                "extend_high_quality_segment_support", "merge_and_extend_candidates",
                "try_merge_two_segments", "_try_local_merge", "_ORIGINAL_LOCAL_MERGE",
                "try_global_merge_two_segments", "adaptive_try_global_merge_two_segments",
                "graph_recover_fragment_paths", "_fragment_edge",
                "attach_collinear_fragments_to_features", "adaptive_stitch_feature_chains",
                "stitch_collinear_segments_global", "deduplicate_segments",
                "sort_segments_by_mid_angle", "recover_collinear_corner_fragments",
                "_recover_measured_endpoints", "_finish_measured_segments",
                "_remove_contained_segments", "_consolidate_observed_lines",
                "_consolidate_observed_lines_impl", "_grow_observed_line",
            ),
        }
        modules = [core, core.base, core._batch]
        categories = {}
        for category, identifiers in names.items():
            for module in modules:
                for identifier in identifiers:
                    value = getattr(module, identifier, None)
                    if callable(value):
                        categories[id(value)] = category

        wrappers = {}
        saved = []

        def wrap(function, category):
            @wraps(function)
            def timed(*args, **kwargs):
                with self.section(category):
                    return function(*args, **kwargs)
            return timed

        try:
            for module in modules:
                for name, value in list(vars(module).items()):
                    category = categories.get(id(value))
                    if category is None:
                        continue
                    if id(value) not in wrappers:
                        wrappers[id(value)] = wrap(value, category)
                    saved.append((module, name, value))
                    setattr(module, name, wrappers[id(value)])
            self.wrapped_bindings = len(saved)
            yield
        finally:
            for module, name, value in reversed(saved):
                setattr(module, name, value)


def default_ransac_args(module):
    # This older parser reads sys.argv directly. Restore it immediately.
    original = sys.argv
    try:
        sys.argv = [str(HERE / "ransac.py")]
        return module.parse_args()
    finally:
        sys.argv = original


def build_runner(method, input_path, options):
    """Prepare a callable whose body does no file I/O or rendering."""
    stem = {"Full": "feature", "RANSAC": "ransac",
            "IEPF": "iepf", "SRG": "srg"}[method]
    module = load_module(stem)

    if method == "Full":
        cfg = module.build_parser().parse_args([])
        cfg.native_enable = options.backend == "numba"
        hint = module.base.load_angle_increment_hint(input_path)
        cfg.angle_increment = (options.angle_increment if options.angle_increment is not None
                               else abs(float(hint)) if hint is not None else DEFAULT_ANGLE)
        for name in ("sensor_range_noise_m", "sensor_range_noise_slope",
                     "sensor_angle_noise_rad"):
            value = getattr(options, name)
            if value is not None:
                setattr(cfg, name, value)
        layouts = module.base.load_frame_layouts(input_path)
        module.prepare_backend(cfg)  # Excluded from all measurements.
        if cfg.native_enable and not getattr(module.native, "_READY", False):
            raise RuntimeError("Numba backend requested but unavailable; install compatible "
                               "Numba/SciPy or use --backend numpy.")
        # The real-environment implementation has an additional continuity pass.
        layout_entry = getattr(module, "_extract_layout_with_continuity",
                               module.base.extract_segments_from_layout)

        def extract(points):
            # Same scoped settings/caches as the public extraction API, without
            # repeating prepare_backend() inside the measurement.
            with module._patched_base(cfg):
                return layout_entry(points, layouts, cfg)[0]

        settings = {name: getattr(cfg, name) for name in (
            "native_enable", "angle_increment", "sensor_range_noise_m",
            "sensor_range_noise_slope", "sensor_angle_noise_rad",
            "threshold_confidence", "huber_sigma_gain", "graph_angle_deg")}
        if hasattr(cfg, "continuity_enable"):
            settings["continuity_enable"] = cfg.continuity_enable
            settings["output_min_length_m"] = cfg.output_min_length_m

    elif method == "RANSAC":
        cfg = default_ransac_args(module)

        def extract(points):
            return module.ransac_segments(
                points, cfg.distance_threshold, cfg.max_iterations, cfg.min_inliers,
                cfg.max_lines, cfg.projection_gap, cfg.seed, cfg.min_length,
                cfg.min_straightness, cfg.merge_angle_deg, cfg.merge_offset, cfg.merge_gap)

        settings = {key: value for key, value in vars(cfg).items()
                    if key not in ("input", "output_png", "output_json")}

    elif method == "IEPF":
        cfg = module.build_arg_parser().parse_args([])

        def extract(points):
            runs = module.split_runs(points, cfg.gap_scale, cfg.gap_abs,
                                     cfg.min_run_points) or [(0, len(points) - 1)]
            epsilon = cfg.eps_a + cfg.eps_b * np.median(np.linalg.norm(points, axis=1))
            intervals = []
            for first, last in runs:
                parts = []
                module.iepf_split(points, first, last, epsilon, cfg.iepf_min_points, parts)
                intervals.extend(module.refine_adjacent_intervals(
                    points, parts, cfg.merge_max_residual, cfg.merge_angle_deg))
            kept = module.simple_feature_filter(
                points, intervals, cfg.feature_min_points, cfg.feature_min_len)
            fitted = [module.fit_segment(points, first, last) for first, last in kept]
            return [segment for segment in fitted if segment.length >= cfg.feature_min_len]

        settings = {key: value for key, value in vars(cfg).items()
                    if key not in ("input", "output")}

    else:
        parsed = module.build_arg_parser().parse_args([])
        cfg = module.Parameters(**{name: getattr(parsed, name)
                                   for name in module.Parameters.__dataclass_fields__})
        layouts = module.load_frame_layouts(input_path)  # Excluded from timing.

        def extract(points):
            if not layouts:
                return module.srg_segments(points, cfg)
            result = []
            for frame in layouts:
                first = int(frame["point_start"])
                end = first + int(frame["point_count"])
                if first < 0 or end > len(points):
                    raise ValueError("Frame layout exceeds the input point array")
                offset = frame["layout_offset"] - frame["source_center"]
                local = points[first:end] - offset
                for segment in module.srg_segments(local, cfg):
                    centroid = segment.centroid + offset
                    result.append(replace(
                        segment, point_indices=segment.point_indices + first,
                        p0=segment.p0 + offset, p1=segment.p1 + offset,
                        centroid=centroid,
                        angle=float(np.mod(np.arctan2(centroid[1], centroid[0]), 2*np.pi)),
                        frame_id=int(frame["frame_id"])))
            result.sort(key=lambda segment: (segment.angle, np.linalg.norm(segment.centroid)))
            for line_id, segment in enumerate(result, 1):
                segment.line_id = line_id
            return result

        settings = vars(cfg)

    def run(points):
        return effective_segments(extract(points))

    return module, run, settings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT,
                        help="One ordered scan JSON; defaults to the first packaged scan")
    parser.add_argument("--method", choices=(*METHODS, "all"), default="Full",
                        help="One method, or all four methods run serially")
    parser.add_argument("--backend", choices=("numpy", "numba"), default="numpy",
                        help="Full backend only; NumPy needs no optional compiler")
    parser.add_argument("--warmup", type=int, default=1,
                        help="Untimed warm-up calls per method (default: 1)")
    parser.add_argument("--repeat", type=int, default=1,
                        help="Measured calls per method on the same scan (default: 1)")
    parser.add_argument("--breakdown", action=argparse.BooleanOptionalAction, default=True,
                        help="One additional Full-only call for exclusive stage shares")
    parser.add_argument("--angle-increment", type=float, default=None)
    parser.add_argument("--sensor-range-noise-m", type=float, default=None)
    parser.add_argument("--sensor-range-noise-slope", type=float, default=None)
    parser.add_argument("--sensor-angle-noise-rad", type=float, default=None)
    options = parser.parse_args()
    if options.warmup < 0 or options.repeat < 1:
        parser.error("--warmup must be nonnegative and --repeat must be positive")
    for name in ("angle_increment", "sensor_range_noise_m",
                 "sensor_range_noise_slope", "sensor_angle_noise_rad"):
        value = getattr(options, name)
        if value is not None and (not math.isfinite(value) or value < 0
                                  or (name == "angle_increment" and value == 0)):
            parser.error(name.replace("_", "-") + " must be finite and nonnegative "
                         "(angle increment must be positive)")
    if options.backend == "numba" and options.warmup < 1:
        parser.error("Use at least one warm-up with Numba to exclude lazy compilation")

    input_path = options.input.expanduser().resolve()
    data = json.loads(input_path.read_text(encoding="utf-8-sig"))
    if data.get("dataset") not in (None, DATASET):
        parser.error("This script expects " + DATASET + " input")
    points = np.asarray([[point["x"], point["y"]] for point in data["points"]],
                        dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2 or len(points) < 2:
        parser.error("Expected at least two ordered 2D points")

    methods = METHODS if options.method == "all" else (options.method,)
    prepared = {method: build_runner(method, input_path, options) for method in methods}
    for method in methods:
        for _ in range(options.warmup):
            prepared[method][1](points.copy())

    elapsed = {method: [] for method in methods}
    counts = {}
    # Rotate methods only when repeated calls are explicitly requested.
    for repeat in range(options.repeat):
        offset = repeat % len(methods)
        order = methods[offset:] + methods[:offset]
        for method in order:
            current_points = points.copy()  # Excluded from timing.
            run = prepared[method][1]
            started = perf_counter_ns()
            segments = run(current_points)
            elapsed[method].append((perf_counter_ns() - started) / 1e6)
            counts[method] = len(segments)

    print("Dataset: " + DATASET)
    print("Input: " + str(input_path))
    print("Points: " + str(len(points)))
    print("Python: " + sys.version.split()[0] + "; NumPy: " + np.__version__)
    print("Warm-up calls per method: " + str(options.warmup))
    print("Uninstrumented measured calls per method: " + str(options.repeat))
    print("Acceptance gate: at least 12 support points and 0.30 m")
    print("Method | Mean uninstrumented runtime (ms) | Effective segments")
    means = {}
    for method in methods:
        means[method] = math.fsum(elapsed[method]) / len(elapsed[method])
        print(f"{method} | {means[method]:.6f} | {counts[method]}")
        print("Settings (" + method + "): " +
              json.dumps(prepared[method][2], sort_keys=True, ensure_ascii=True))

    if "Full" in methods and options.breakdown:
        core, run, _ = prepared["Full"]
        profiler = ExclusiveStages()
        current_points = points.copy()
        with profiler.install(core):
            with profiler.section(3):
                profiled_segments = run(current_points)
        total_ns = sum(profiler.totals_ns)
        if total_ns <= 0:
            raise RuntimeError("The profiling timer returned no positive duration")
        print("\nFull stage allocation (one separate instrumented call)")
        print("Stage | Exclusive instrumented ms | Share (%) | Normalized estimate (ms)")
        for name, duration in zip(STAGES, profiler.totals_ns):
            share = duration / total_ns
            print(f"{name} | {duration / 1e6:.6f} | {share * 100:.4f} | "
                  f"{share * means['Full']:.6f}")
        print(f"Instrumented total: {total_ns / 1e6:.6f} ms")
        print(f"Uninstrumented normalization total: {means['Full']:.6f} ms")
        print(f"Instrumented effective segments: {len(profiled_segments)}")
        print("Stage values include instrumentation effects. Normalized values are "
              "allocations of the uninstrumented total, not direct stage benchmarks.")
        print("Opaque compiled kernels stay in their calling stage; preprocessing's "
              "provisional fits stay in preprocessing. Other orchestration is in stage 4.")
        if len(profiled_segments) != counts["Full"]:
            print("WARNING: profiled and uninstrumented segment counts differ.",
                  file=sys.stderr)
    print("No result, plot, or log files were saved.")


if __name__ == "__main__":
    main()

