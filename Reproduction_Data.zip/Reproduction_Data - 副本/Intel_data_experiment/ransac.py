#!/usr/bin/env python3
import argparse
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np


# 2026-10-28: development-set settings for the requested 100-300 ms mean budget.
# Original hypothesis/refinement implementation; no artificial timing delay.
EPS = 1e-12


# ================== Global plot style (aligned with IEPF) ==================
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 11,
    "axes.labelsize": 12,
    "axes.titlesize": 14,
    "legend.fontsize": 10,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
})


@dataclass
class FittedSegment:
    line_id: int
    point_indices: np.ndarray
    p0: np.ndarray
    p1: np.ndarray
    direction: np.ndarray
    centroid: np.ndarray
    rms: float
    max_residual: float
    straightness: float
    length: float
    angle: float = 0.0


def load_points(path: Path) -> np.ndarray:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    points = data.get("points", [])
    arr = np.array([[float(p["x"]), float(p["y"])] for p in points], dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] != 2:
        raise ValueError("Invalid map_points.json format, expected points=[{x,y}, ...]")
    if len(arr) < 2:
        raise ValueError("Not enough points to fit line segments")
    return arr


def normalize(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / (n + EPS)


def fit_tls_line(points: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    mu = points.mean(axis=0)
    xc = points - mu
    cov = (xc.T @ xc) / max(1, len(points))
    eigvals, eigvecs = np.linalg.eigh(cov)
    order = np.argsort(eigvals)[::-1]
    eigvals = eigvals[order]
    direction = eigvecs[:, order[0]]
    direction = normalize(direction)
    if direction[0] < 0 or (abs(direction[0]) < 1e-12 and direction[1] < 0):
        direction = -direction
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    return mu, direction, normal, eigvals


def residual_to_line(points: np.ndarray, mu: np.ndarray, normal: np.ndarray) -> np.ndarray:
    return (points - mu) @ normal


def project_range(points: np.ndarray, mu: np.ndarray, direction: np.ndarray) -> Tuple[np.ndarray, float, float]:
    t = (points - mu) @ direction
    return t, float(np.min(t)), float(np.max(t))


def longest_projection_cluster(
    points: np.ndarray,
    indices: np.ndarray,
    mu: np.ndarray,
    direction: np.ndarray,
    max_gap: float,
) -> np.ndarray:
    if len(indices) == 0:
        return indices
    pts = points[indices]
    t = (pts - mu) @ direction
    order = np.argsort(t)
    sorted_idx = indices[order]
    sorted_t = t[order]

    groups: List[np.ndarray] = []
    start = 0
    for i in range(1, len(sorted_t)):
        if (sorted_t[i] - sorted_t[i - 1]) > max_gap:
            groups.append(sorted_idx[start:i])
            start = i
    groups.append(sorted_idx[start:])

    groups.sort(
        key=lambda g: (
            len(g),
            float(np.ptp(((points[g] - mu) @ direction))) if len(g) > 1 else 0.0,
        ),
        reverse=True,
    )
    return groups[0]


def expand_segment_support(
    points: np.ndarray,
    candidate_idx: np.ndarray,
    active_idx: np.ndarray,
    distance_threshold: float,
    projection_gap: float,
    expand_ratio: float = 1.25,
    refine_steps: int = 3,
) -> np.ndarray:
    if len(candidate_idx) == 0:
        return candidate_idx

    support = candidate_idx.copy()
    pts_active = points[active_idx]

    for _ in range(refine_steps):
        mu, direction, normal, _ = fit_tls_line(points[support])

        d = np.abs((pts_active - mu) @ normal)
        proj = (pts_active - mu) @ direction

        support_proj = (points[support] - mu) @ direction
        tmin = float(np.min(support_proj))
        tmax = float(np.max(support_proj))

        corridor = d <= (distance_threshold * expand_ratio)
        range_ok = (proj >= tmin - projection_gap) & (proj <= tmax + projection_gap)
        expanded = active_idx[corridor & range_ok]

        expanded = longest_projection_cluster(points, expanded, mu, direction, projection_gap)
        if len(expanded) <= len(support):
            break
        support = expanded

    return support


def build_segment(points: np.ndarray, point_indices: np.ndarray, line_id: int) -> FittedSegment:
    seg_points = points[point_indices]
    mu, direction, normal, eigvals = fit_tls_line(seg_points)
    res = residual_to_line(seg_points, mu, normal)
    rms = float(np.sqrt(np.mean(res ** 2)))
    max_res = float(np.max(np.abs(res)))

    proj = (seg_points - mu) @ direction
    t0, t1 = float(np.min(proj)), float(np.max(proj))
    p0 = mu + t0 * direction
    p1 = mu + t1 * direction
    length = float(np.linalg.norm(p1 - p0))

    lam1 = float(max(eigvals[0], 0.0))
    lam2 = float(max(eigvals[1], 0.0))
    straightness = 1.0 - lam2 / (lam1 + lam2 + EPS)

    centroid = 0.5 * (p0 + p1)
    angle = float(np.mod(np.arctan2(centroid[1], centroid[0]), 2.0 * np.pi))

    return FittedSegment(
        line_id=line_id,
        point_indices=np.unique(point_indices),
        p0=p0,
        p1=p1,
        direction=direction,
        centroid=centroid,
        rms=rms,
        max_residual=max_res,
        straightness=float(straightness),
        length=length,
        angle=angle,
    )


def segment_score(seg: FittedSegment) -> float:
    n = len(seg.point_indices)
    return n * max(seg.length, 0.0) * max(seg.straightness, 0.0) / (seg.rms + 1e-4)


def point_to_segment_distance_batch(points: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ab = b - a
    ab2 = float(ab @ ab)
    if ab2 < 1e-12:
        return np.linalg.norm(points - a, axis=1)
    t = ((points - a) @ ab) / ab2
    t = np.clip(t, 0.0, 1.0)
    proj = a + np.outer(t, ab)
    return np.linalg.norm(points - proj, axis=1)


def suppress_points_near_segment(
    points: np.ndarray,
    active_idx: np.ndarray,
    seg: FittedSegment,
    distance_threshold: float,
    extension_margin: float,
) -> np.ndarray:
    mu = seg.centroid
    direction = seg.direction
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)

    pts = points[active_idx]
    d_line = np.abs((pts - mu) @ normal)
    t = (pts - mu) @ direction

    seg_t = np.array([(seg.p0 - mu) @ direction, (seg.p1 - mu) @ direction], dtype=np.float64)
    tmin, tmax = float(np.min(seg_t)), float(np.max(seg_t))

    near_corridor = d_line <= (distance_threshold * 1.35)
    near_range = (t >= tmin - extension_margin) & (t <= tmax + extension_margin)
    keep_mask = ~(near_corridor & near_range)
    return active_idx[keep_mask]


def are_segments_mergeable(
    s1: FittedSegment,
    s2: FittedSegment,
    angle_tol_deg: float,
    offset_tol: float,
    gap_tol: float,
) -> bool:
    u1 = normalize(s1.p1 - s1.p0)
    u2 = normalize(s2.p1 - s2.p0)

    cosang = float(np.clip(np.abs(u1 @ u2), -1.0, 1.0))
    ang = np.degrees(np.arccos(cosang))
    if ang > angle_tol_deg:
        return False

    n1 = np.array([-u1[1], u1[0]], dtype=np.float64)
    c1 = 0.5 * (s1.p0 + s1.p1)
    c2 = 0.5 * (s2.p0 + s2.p1)

    offset = abs((c2 - c1) @ n1)
    if offset > offset_tol:
        return False

    t11 = (s1.p0 - c1) @ u1
    t12 = (s1.p1 - c1) @ u1
    t21 = (s2.p0 - c1) @ u1
    t22 = (s2.p1 - c1) @ u1

    a0, a1 = min(t11, t12), max(t11, t12)
    b0, b1 = min(t21, t22), max(t21, t22)

    overlap = min(a1, b1) - max(a0, b0)
    gap = max(0.0, max(a0, b0) - min(a1, b1))

    return overlap >= -gap_tol or gap <= gap_tol


def merge_two_segments(points: np.ndarray, s1: FittedSegment, s2: FittedSegment, line_id: int) -> FittedSegment:
    merged_idx = np.unique(np.concatenate([s1.point_indices, s2.point_indices]))
    return build_segment(points, merged_idx, line_id=line_id)


def merge_collinear_segments(
    points: np.ndarray,
    segments: List[FittedSegment],
    angle_tol_deg: float,
    offset_tol: float,
    gap_tol: float,
) -> List[FittedSegment]:
    if not segments:
        return []

    used = [False] * len(segments)
    merged: List[FittedSegment] = []

    for i in range(len(segments)):
        if used[i]:
            continue

        cur = segments[i]
        changed = True
        used[i] = True

        while changed:
            changed = False
            for j in range(len(segments)):
                if used[j]:
                    continue
                if are_segments_mergeable(cur, segments[j], angle_tol_deg, offset_tol, gap_tol):
                    cur = merge_two_segments(points, cur, segments[j], line_id=cur.line_id)
                    used[j] = True
                    changed = True

        merged.append(cur)

    for idx, seg in enumerate(merged, start=1):
        seg.line_id = idx
    return merged


def sort_segments_ccw(segments: List[FittedSegment]) -> List[FittedSegment]:
    for seg in segments:
        center = 0.5 * (seg.p0 + seg.p1)
        seg.centroid = center
        seg.angle = float(np.mod(np.arctan2(center[1], center[0]), 2.0 * np.pi))

    segments = sorted(segments, key=lambda s: (s.angle, np.linalg.norm(s.centroid)))
    for idx, seg in enumerate(segments, start=1):
        seg.line_id = idx
    return segments


def ransac_segments(
    points: np.ndarray,
    distance_threshold: float,
    max_iterations: int,
    min_inliers: int,
    max_lines: int,
    projection_gap: float,
    random_seed: int,
    min_length: float,
    min_straightness: float,
    merge_angle_deg: float,
    merge_offset: float,
    merge_gap: float,
) -> List[FittedSegment]:
    rng = np.random.default_rng(random_seed)

    active_idx = np.arange(len(points), dtype=np.int64)
    segments: List[FittedSegment] = []
    temp_line_id = 1

    while len(active_idx) >= min_inliers and len(segments) < max_lines:
        best_segment = None
        best_score = -np.inf
        pts_active = points[active_idx]

        for _ in range(max_iterations):
            if len(active_idx) < 2:
                break

            i1, i2 = rng.choice(active_idx, size=2, replace=False)
            p1, p2 = points[i1], points[i2]
            v = p2 - p1
            vn = np.linalg.norm(v)
            if vn < 1e-9:
                continue

            direction = v / vn
            normal = np.array([-direction[1], direction[0]], dtype=np.float64)

            d = np.abs((pts_active - p1) @ normal)
            candidate = active_idx[d <= distance_threshold]
            if len(candidate) < min_inliers:
                continue

            mu_c, dir_c, _, _ = fit_tls_line(points[candidate])
            candidate = longest_projection_cluster(points, candidate, mu_c, dir_c, projection_gap)
            candidate = expand_segment_support(
                points=points,
                candidate_idx=candidate,
                active_idx=active_idx,
                distance_threshold=distance_threshold,
                projection_gap=projection_gap,
                expand_ratio=1.25,
                refine_steps=3,
            )

            if len(candidate) < min_inliers:
                continue

            seg = build_segment(points, candidate, line_id=temp_line_id)

            if seg.length < min_length:
                continue
            if seg.straightness < min_straightness:
                continue

            score = segment_score(seg)
            if score > best_score:
                best_score = score
                best_segment = seg

        if best_segment is None:
            break

        segments.append(best_segment)

        active_idx = suppress_points_near_segment(
            points=points,
            active_idx=active_idx,
            seg=best_segment,
            distance_threshold=distance_threshold,
            extension_margin=projection_gap,
        )
        temp_line_id += 1

    segments = merge_collinear_segments(
        points=points,
        segments=segments,
        angle_tol_deg=merge_angle_deg,
        offset_tol=merge_offset,
        gap_tol=merge_gap,
    )
    segments = [s for s in segments if s.length >= min_length and s.straightness >= min_straightness]
    segments = sort_segments_ccw(segments)
    return segments


# ================== Only the map visualization is adjusted to match IEPF ==================
def plot_segments(
    points: np.ndarray,
    segments: Sequence[FittedSegment],
    out_path: Path,
    show_segments: bool = True,
) -> None:
    fig, ax = plt.subplots(figsize=(16.8, 9.8), dpi=720)
    point_size = 96.0 if len(points) <= 220 else 76.0
    line_width = 7.2 if show_segments else 0.0
    ax.set_facecolor("#ffffff")

    ax.scatter(
        points[:, 0],
        points[:, 1],
        s=point_size,
        c="#0b1f5b",
        edgecolors="#111827",
        linewidths=1.25,
        alpha=0.98,
        label="Raw points",
        zorder=1,
        antialiased=True,
    )

    if show_segments:
        drawn = False
        for seg in segments:
            ax.plot(
                [seg.p0[0], seg.p1[0]],
                [seg.p0[1], seg.p1[1]],
                color="#ff8c00",
                linewidth=line_width,
                alpha=0.98,
                solid_capstyle="round",
                label="Extracted segments" if not drawn else None,
                zorder=3,
                antialiased=True,
            )
            ax.scatter(
                [seg.p0[0], seg.p1[0]],
                [seg.p0[1], seg.p1[1]],
                s=86.0,
                c="#ff8c00",
                edgecolors="#111827",
                linewidths=1.08,
                zorder=4,
            )
            drawn = True

    ax.set_xlabel("X (m)", fontsize=24, labelpad=10)
    ax.set_ylabel("Y (m)", fontsize=24, labelpad=10)
    ax.set_title("RANSAC Line Extraction Result", fontsize=34, pad=18)
    ax.set_aspect("equal")
    ax.grid(True, linestyle="--", linewidth=0.8, alpha=0.36, zorder=0)
    ax.tick_params(axis="both", which="major", width=1.1, length=6, labelsize=20)
    for spine in ax.spines.values():
        spine.set_linewidth(1.1)

    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    y_min, y_max = np.min(points[:, 1]), np.max(points[:, 1])
    x_span = max(x_max - x_min, 1e-6)
    y_span = max(y_max - y_min, 1e-6)
    ax.set_xlim(x_min - 0.06 * x_span, x_max + 0.34 * x_span)
    ax.set_ylim(y_min - 0.10 * y_span, y_max + 0.10 * y_span)

    ax.legend(
        loc="lower right",
        bbox_to_anchor=(0.985, 0.035),
        borderaxespad=0.0,
        frameon=True,
        framealpha=0.94,
        edgecolor="#d0d0d0",
        fontsize=22,
        markerscale=1.35,
        borderpad=0.52,
        labelspacing=0.42,
        handlelength=2.35,
        handletextpad=0.58,
    )

    fig.subplots_adjust(left=0.09, right=0.985, bottom=0.12, top=0.90)
    plt.savefig(out_path, dpi=720, bbox_inches="tight", pad_inches=0.03)
    plt.close()


def summary_metrics(segments: Sequence[FittedSegment]) -> Dict[str, float]:
    if not segments:
        return {"avg_rms": float("nan"), "max_residual": float("nan"), "avg_straightness": float("nan")}
    n = np.array([len(s.point_indices) for s in segments], dtype=np.float64)
    total_n = np.sum(n)
    weighted_rms = float(np.sqrt(np.sum((np.array([s.rms for s in segments]) ** 2) * n) / max(total_n, 1.0)))
    max_residual = float(np.max([s.max_residual for s in segments]))
    weighted_straightness = float(np.sum(np.array([s.straightness for s in segments]) * n) / max(total_n, 1.0))
    return {"avg_rms": weighted_rms, "max_residual": max_residual, "avg_straightness": weighted_straightness}


def append_result_json(path: Path, input_file: str, segments: Sequence[FittedSegment], summary: Dict[str, float]) -> None:
    run_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "input_file": input_file,
        "num_segments": len(segments),
        "summary": {
            "avg_rms": summary["avg_rms"],
            "max_residual": summary["max_residual"],
            "avg_straightness": summary["avg_straightness"],
        },
        "segments": [
            {
                "line_id": int(s.line_id),
                "angle_deg": float(np.degrees(s.angle)),
                "centroid": {"x": float(s.centroid[0]), "y": float(s.centroid[1])},
                "p0": {"x": float(s.p0[0]), "y": float(s.p0[1])},
                "p1": {"x": float(s.p1[0]), "y": float(s.p1[1])},
                "length": float(s.length),
                "rms": float(s.rms),
                "max_residual": float(s.max_residual),
                "straightness": float(s.straightness),
                "n_points": int(len(s.point_indices)),
            }
            for s in segments
        ],
    }

    if path.exists():
        with path.open("r", encoding="utf-8") as f:
            existing = json.load(f)
    else:
        existing = {"runs": []}

    if isinstance(existing, list):
        existing.append(run_record)
        output_obj = existing
    elif isinstance(existing, dict):
        inserted = False
        for key in ("runs", "history", "records", "frames"):
            if key in existing and isinstance(existing[key], list):
                existing[key].append(run_record)
                inserted = True
                break
        if not inserted:
            existing["runs"] = [run_record]
        output_obj = existing
    else:
        output_obj = {"runs": [run_record]}

    with path.open("w", encoding="utf-8") as f:
        json.dump(output_obj, f, ensure_ascii=False, indent=2)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="RANSAC line segment fitting for map_points.json")
    p.add_argument("--input", default="map_points.json", help="Input point cloud JSON")
    p.add_argument("--output-png", default="ransac.png", help="Output visualization image")
    p.add_argument("--output-json", default="ransac.json", help="Output segment result JSON (append mode)")

    p.add_argument("--distance-threshold", type=float, default=0.02, help="RANSAC inlier distance threshold (m)")
    p.add_argument("--max-iterations", type=int, default=240, help="Maximum RANSAC iterations per line")
    p.add_argument("--min-inliers", type=int, default=12, help="Minimum number of inliers")
    p.add_argument("--max-lines", type=int, default=20, help="Maximum number of extracted segments")
    p.add_argument("--projection-gap", type=float, default=0.24, help="Maximum projection gap within one segment (m)")
    p.add_argument("--seed", type=int, default=42, help="Random seed")

    p.add_argument("--min-length", type=float, default=0.30, help="Minimum kept segment length (m)")
    p.add_argument("--min-straightness", type=float, default=0.92, help="Minimum straightness")

    p.add_argument("--merge-angle-deg", type=float, default=8.0, help="Maximum merge angle between segments (deg)")
    p.add_argument("--merge-offset", type=float, default=0.05, help="Maximum normal offset for segment merging (m)")
    p.add_argument("--merge-gap", type=float, default=0.12, help="Maximum endpoint gap for segment merging (m)")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    points = load_points(Path(args.input))

    segments = ransac_segments(
        points=points,
        distance_threshold=args.distance_threshold,
        max_iterations=args.max_iterations,
        min_inliers=args.min_inliers,
        max_lines=args.max_lines,
        projection_gap=args.projection_gap,
        random_seed=args.seed,
        min_length=args.min_length,
        min_straightness=args.min_straightness,
        merge_angle_deg=args.merge_angle_deg,
        merge_offset=args.merge_offset,
        merge_gap=args.merge_gap,
    )

    summary = summary_metrics(segments)
    output_png_path = Path(args.output_png)
    points_png_path = output_png_path.with_name("points.png")

    plot_segments(points, segments, output_png_path, show_segments=True)
    plot_segments(points, segments, points_png_path, show_segments=False)
    append_result_json(Path(args.output_json), args.input, segments, summary)

    print("RANSAC line fitting completed")
    print(f"Number of points: {len(points)}")
    print(f"Number of segments: {len(segments)}")
    if segments:
        print("---- Segment metrics (indexed counterclockwise from the origin) ----")
        for s in segments:
            print(
                f"line_id={s.line_id:02d}, angle={np.degrees(s.angle):7.2f} deg, "
                f"n={len(s.point_indices):4d}, length={s.length:.4f} m, "
                f"RMS={s.rms:.6f} m, max_res={s.max_residual:.6f} m, "
                f"straightness={s.straightness:.6f}"
            )
        print("---- Summary metrics ----")
        print(f"Average point-to-line RMS error: {summary['avg_rms']:.6f} m")
        print(f"Maximum residual: {summary['max_residual']:.6f} m")
        print(f"Average straightness: {summary['avg_straightness']:.6f}")
    else:
        print("No segments satisfied the thresholds. Please adjust the parameters and try again.")

    print(f"Visualization file: {output_png_path.resolve()}")
    print(f"Points-only visualization file: {points_png_path.resolve()}")
    print(f"Segment result file: {Path(args.output_json).resolve()}")


if __name__ == "__main__":
    main()

