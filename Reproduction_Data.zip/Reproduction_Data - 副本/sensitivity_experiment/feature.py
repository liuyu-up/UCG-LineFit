#!/usr/bin/env python3
"""Standalone uncertainty-aware and graph-optimized LiDAR line extraction.

Requires Python 3.9+, NumPy and Matplotlib. Numba and SciPy are optional
for --native-enable. All geometric, batch and accelerated helper code is
included in this file; no support archive or sibling modules are required.

    python feature.py --input scan.json --output-png feature.png

The default sensor scales follow the calibration reported in article3.docx.
The angular standard deviation is independent of the beam sampling increment;
the latter is used only for deterministic sampling/spacing calculations.
"""

from __future__ import annotations

import argparse
import math
from contextlib import contextmanager
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path
from statistics import NormalDist
from time import perf_counter
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

# Self-contained helper modules retain their separate globals for scoped patches.
# All source is included below; no ZIP archive or sibling Python files are loaded.
import sys
import types

_EMBEDDED_SUPPORT = {
    'feature_base': r'''#!/usr/bin/env python3
import argparse
import json
import os
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

# Use Matplotlib's normal user cache; no support/cache directory beside this file.

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


EPS = 1e-12


plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 14,
    "axes.labelsize": 24,
    "axes.titlesize": 34,
    "legend.fontsize": 22,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "axes.linewidth": 1.1,
    "figure.facecolor": "#ffffff",
    "savefig.facecolor": "#ffffff",
})


@dataclass
class LineFit:
    mu: np.ndarray
    direction: np.ndarray
    rms: float
    max_res: float
    straightness: float


@dataclass
class Segment:
    id: int = 0
    idx_start: int = 0
    idx_end: int = 0
    p1: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=np.float64))
    p2: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=np.float64))
    length: float = 0.0
    rms: float = 0.0
    max_res: float = 0.0
    straightness: float = 0.0
    feature: float = 0.0
    n_points: int = 0
    is_feature: bool = False
    is_fragment: bool = False
    merged_from: List[Tuple[int, int]] = field(default_factory=list)


def load_points(path: Path) -> np.ndarray:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    pts = data.get("points", [])
    arr = np.array([[float(p["x"]), float(p["y"])] for p in pts], dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] != 2:
        raise ValueError("Invalid points format in JSON.")
    if len(arr) < 2:
        raise ValueError("Not enough points to fit segments.")
    return arr


def load_angle_increment_hint(path: Path) -> Optional[float]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    metadata = data.get("metadata", {})
    for key in ("recommended_angle_increment_rad", "angle_increment_rad", "laser_angle_increment_rad"):
        if key in metadata:
            value = float(metadata[key])
            if value > 0.0:
                return value
    return None


def _metadata_point_xy(obj: dict) -> np.ndarray:
    return np.array([float(obj["x"]), float(obj["y"])], dtype=np.float64)


def load_frame_layouts(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    frames = data.get("metadata", {}).get("frames", [])
    if not isinstance(frames, list):
        return []

    layouts: List[dict] = []
    for item in frames:
        if not isinstance(item, dict):
            continue
        try:
            start = int(item["point_start"])
            count = int(item["point_count"])
            source_center = _metadata_point_xy(item["source_center"])
            layout_offset = _metadata_point_xy(item["layout_offset"])
        except (KeyError, TypeError, ValueError):
            continue
        if start < 0 or count <= 1:
            continue

        angle_increment = item.get("angle_increment_rad", None)
        layouts.append({
            "frame_id": int(item.get("frame_id", len(layouts) + 1)),
            "point_start": start,
            "point_count": count,
            "source_center": source_center,
            "layout_offset": layout_offset,
            "angle_increment_rad": float(angle_increment) if angle_increment is not None else None,
        })
    return layouts


def normalize(v: np.ndarray) -> np.ndarray:
    return v / (np.linalg.norm(v) + EPS)


def median(values: Sequence[float]) -> float:
    if len(values) == 0:
        return 0.0
    return float(np.median(np.asarray(values, dtype=np.float64)))


def mad(values: Sequence[float]) -> float:
    if len(values) == 0:
        return 0.0
    arr = np.asarray(values, dtype=np.float64)
    med = np.median(arr)
    return float(np.median(np.abs(arr - med)))


def fit_line_tls_core(points: np.ndarray, weights: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if len(points) == 0:
        raise ValueError("No points provided for TLS fitting.")

    if weights is None:
        weights = np.ones(len(points), dtype=np.float64)

    wsum = float(np.sum(weights))
    mu = np.sum(points * weights[:, None], axis=0) / max(wsum, EPS)
    q = points - mu
    cov = (q * weights[:, None]).T @ q / max(wsum, EPS)
    eigvals, eigvecs = np.linalg.eigh(cov)
    idx = int(np.argmax(eigvals))
    direction = normalize(eigvecs[:, idx])
    if direction[0] < 0.0 or (abs(direction[0]) < 1e-12 and direction[1] < 0.0):
        direction = -direction
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    residual = q @ normal
    return mu, direction, residual, eigvals


def fit_line_tls_huber(points: np.ndarray, huber_delta: float, huber_iters: int) -> LineFit:
    n = len(points)
    weights = np.ones(n, dtype=np.float64)

    mu = np.zeros(2, dtype=np.float64)
    direction = np.array([1.0, 0.0], dtype=np.float64)
    residual = np.zeros(n, dtype=np.float64)
    eigvals = np.zeros(2, dtype=np.float64)

    if huber_delta <= 0.0 or huber_iters <= 0:
        mu, direction, residual, eigvals = fit_line_tls_core(points)
    else:
        for _ in range(huber_iters):
            mu, direction, residual, eigvals = fit_line_tls_core(points, weights=weights)
            abs_res = np.abs(residual)
            weights = np.where(abs_res <= huber_delta, 1.0, huber_delta / (abs_res + EPS))

        mu, direction, residual, eigvals = fit_line_tls_core(points, weights=weights)

    rms = float(np.sqrt(np.mean(residual ** 2)))
    max_res = float(np.max(np.abs(residual)))
    eigvals = np.sort(eigvals)[::-1]
    lam1 = float(max(eigvals[0], 0.0))
    lam2 = float(max(eigvals[1], 0.0))
    straightness = 1.0 - lam2 / (lam1 + lam2 + EPS)
    return LineFit(mu=mu, direction=direction, rms=rms, max_res=max_res, straightness=float(straightness))


ORIGINAL_FIT_LINE_TLS_HUBER = fit_line_tls_huber


def gap_thr_m(r: float, angle_increment: float, gap0_m: float, cgap: float) -> float:
    return max(gap0_m + cgap * max(r, 0.05) * angle_increment, gap0_m * 3.0)


def mean_gap_thr_m(r: float, angle_increment: float, gap0_m: float, cmean: float) -> float:
    return max(gap0_m + cmean * max(r, 0.05) * angle_increment, gap0_m * 2.4)


def merge_gap_thr_m(r: float, angle_increment: float, merge_gap0_m: float, merge_cgap: float) -> float:
    return merge_gap0_m + merge_cgap * max(r, 0.05) * angle_increment


def merge_perp_thr_m(r: float, merge_perp_base_m: float, merge_perp_cr: float) -> float:
    return merge_perp_base_m + merge_perp_cr * max(r, 0.05)


def estimate_noise_ratio_from_points(points: np.ndarray, median_range: float, angle_increment: float) -> float:
    if len(points) < 3 or angle_increment <= 0.0:
        return 0.0
    ranges = np.linalg.norm(points, axis=1)
    radial_steps = np.abs(np.diff(ranges))
    if len(radial_steps) == 0:
        return 0.0
    exp_gap = max(median_range, 0.05) * angle_increment + 1e-6
    noise_mad = 1.4826 * mad(radial_steps)
    return float(np.clip(noise_mad / exp_gap, 0.0, 3.0))


def adaptive_min_len_m(
    median_range: float,
    noise_ratio: float,
    min_len_m: float,
    adaptive_min_len_enable: bool,
    adaptive_min_len_ref_range_m: float,
    adaptive_min_len_dist_exp: float,
    adaptive_min_len_noise_gain: float,
    adaptive_min_len_scale_min: float,
    adaptive_min_len_scale_max: float,
) -> float:
    if not adaptive_min_len_enable:
        return min_len_m
    rr = max(median_range, 0.05)
    ref_range = max(adaptive_min_len_ref_range_m, 0.05)
    dist_scale = np.power(ref_range / rr, adaptive_min_len_dist_exp)
    noise_scale = 1.0 + adaptive_min_len_noise_gain * max(0.0, noise_ratio)
    scale = np.clip(dist_scale * noise_scale, adaptive_min_len_scale_min, adaptive_min_len_scale_max)
    return float(min_len_m * scale)


def adaptive_short_feature_min_len_m(
    median_range: float,
    noise_ratio: float,
    args: argparse.Namespace,
) -> float:
    if not args.adaptive_min_len_enable:
        return args.min_len_m

    rr = max(median_range, 0.05)
    ref_range = max(args.adaptive_min_len_ref_range_m, 0.05)
    dist_scale = np.power(rr / ref_range, max(1.0, args.adaptive_min_len_dist_exp + 0.55))
    noise_scale = 1.0 + 0.01 * max(0.0, noise_ratio)
    base = args.min_len_m * dist_scale * noise_scale
    return float(np.clip(base, max(args.frag_min_len_m, 0.11), args.min_len_m * 0.96))


def short_feature_candidate_ok(
    seg: Segment,
    median_range: float,
    noise_ratio: float,
    args: argparse.Namespace,
) -> bool:
    if not args.adaptive_min_len_enable or seg.n_points < args.min_pts or seg.length >= args.min_len_m:
        return False

    short_min_len = adaptive_short_feature_min_len_m(median_range, noise_ratio, args)
    if seg.length < short_min_len:
        return False

    _, thr_rms, thr_max, _ = segment_quality_thresholds(np.array([median_range], dtype=np.float64), args)
    straight_thr = max(args.frag_straightness_min, args.straightness_min + 0.01)
    return (
        seg.rms <= thr_rms * 1.10
        and seg.max_res <= thr_max * 1.08
        and seg.straightness >= straight_thr
    )


def point_to_line_distance(point: np.ndarray, mu: np.ndarray, direction: np.ndarray) -> float:
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    return float(abs((point - mu) @ normal))


def prune_small_noise_runs(points: np.ndarray, angle_increment: float, args: argparse.Namespace) -> np.ndarray:
    if len(points) <= 2:
        return points

    keep = np.ones(len(points), dtype=bool)
    run_start = 0

    def maybe_prune(run_end: int) -> None:
        nonlocal keep, run_start
        count = run_end - run_start + 1
        if count <= 0:
            return
        if count > args.preclean_small_run_max_pts:
            return

        run_pts = points[run_start:run_end + 1]
        fit = fit_line_tls_huber(run_pts, huber_delta=0.0, huber_iters=0)
        seg_length = float(np.linalg.norm(run_pts[-1] - run_pts[0]))
        if seg_length <= args.preclean_small_run_max_len_m or fit.straightness <= args.preclean_small_run_straightness:
            keep[run_start:run_end + 1] = False

    for i in range(len(points) - 1):
        r_local = 0.5 * (np.linalg.norm(points[i]) + np.linalg.norm(points[i + 1]))
        gap = float(np.linalg.norm(points[i + 1] - points[i]))
        if gap > gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap) * args.preclean_run_gap_scale:
            maybe_prune(i)
            run_start = i + 1
    maybe_prune(len(points) - 1)

    pruned = points[keep]
    if len(pruned) >= 2:
        return pruned
    return points


def preprocess_points(points: np.ndarray, angle_increment: float, args: argparse.Namespace) -> np.ndarray:
    if not args.preclean_enable or len(points) < max(7, 2 * args.preclean_window + 3):
        return points

    filtered = points.copy()
    for _ in range(max(1, args.preclean_passes)):
        if len(filtered) < max(7, 2 * args.preclean_window + 3):
            break

        ranges = np.linalg.norm(filtered, axis=1)
        keep = np.ones(len(filtered), dtype=bool)

        for i in range(1, len(filtered) - 1):
            left = max(0, i - args.preclean_window)
            right = min(len(filtered), i + args.preclean_window + 1)
            d_prev = float(np.linalg.norm(filtered[i] - filtered[i - 1]))
            d_next = float(np.linalg.norm(filtered[i + 1] - filtered[i]))
            r_local = max(float(ranges[i]), 0.05)
            run_gap_base = gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap) * args.preclean_run_gap_scale
            if d_prev > run_gap_base:
                left = i
            if d_next > run_gap_base:
                right = i + 1

            while left < i and float(np.linalg.norm(filtered[left + 1] - filtered[left])) > run_gap_base:
                left += 1
            while right > i + 1 and float(np.linalg.norm(filtered[right - 1] - filtered[right - 2])) > run_gap_base:
                right -= 1

            if right - left < max(4, args.preclean_window + 2):
                continue

            local = filtered[left:right]
            local_idx = i - left
            neigh = np.concatenate([local[:local_idx], local[local_idx + 1:]], axis=0)
            if len(neigh) < 3:
                continue

            mu, direction, _, _ = fit_line_tls_core(neigh)
            residual = point_to_line_distance(filtered[i], mu, direction)
            local_ranges = np.linalg.norm(neigh, axis=1)
            r_med = median(local_ranges)
            gap_base = gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
            mean_gap_base = mean_gap_thr_m(r_med, angle_increment, args.gap0_m, args.cmean)
            radial_sigma = 1.4826 * mad(local_ranges)
            radial_dev = abs(float(ranges[i] - median(local_ranges)))

            isolated = (
                d_prev > gap_base * args.preclean_isolated_gap_scale
                and d_next > gap_base * args.preclean_isolated_gap_scale
            )
            bridge_break = (
                d_prev > gap_base * args.preclean_gap_scale
                or d_next > gap_base * args.preclean_gap_scale
            )
            deviated = residual > max(args.preclean_residual_abs_m, mean_gap_base * args.preclean_residual_scale)
            radial_bad = radial_dev > max(args.preclean_radial_abs_m, (radial_sigma + gap_base) * args.preclean_radial_scale)

            if isolated or (deviated and (bridge_break or radial_bad)):
                keep[i] = False

        if np.all(keep):
            break

        candidate = filtered[keep]
        if len(candidate) < 2:
            break

        candidate = prune_small_noise_runs(candidate, angle_increment, args)
        if len(candidate) == len(filtered):
            break
        filtered = candidate

    if len(filtered) >= 2:
        return filtered
    return points


def robust_refine_segment_points(
    seg_points: np.ndarray,
    huber_delta: float,
    huber_iters: int,
    args: Optional[argparse.Namespace],
) -> Tuple[np.ndarray, LineFit]:
    fit = fit_line_tls_huber(seg_points, huber_delta=huber_delta, huber_iters=huber_iters)
    if (
        args is None
        or not getattr(args, "preclean_enable", False)
        or huber_delta <= 0.0
        or huber_iters <= 0
        or fit_line_tls_huber is not ORIGINAL_FIT_LINE_TLS_HUBER
        or len(seg_points) < max(8, getattr(args, "min_pts", 8))
    ):
        return seg_points, fit

    normal = np.array([-fit.direction[1], fit.direction[0]], dtype=np.float64)
    residual = np.abs((seg_points - fit.mu) @ normal)
    med_res = float(np.median(residual))
    mad_res = 1.4826 * float(np.median(np.abs(residual - med_res)))
    keep_thr = max(0.010, med_res + 2.2 * max(mad_res, fit.rms))
    keep = residual <= keep_thr
    min_keep = max(getattr(args, "min_pts", 8), int(np.ceil(0.72 * len(seg_points))))
    if int(np.sum(keep)) < min_keep or int(np.sum(keep)) >= len(seg_points):
        return seg_points, fit

    refined_points = seg_points[keep]
    refined_fit = ORIGINAL_FIT_LINE_TLS_HUBER(refined_points, huber_delta=huber_delta, huber_iters=huber_iters)
    improved = (
        refined_fit.rms <= fit.rms * 0.90
        or refined_fit.max_res <= fit.max_res * 0.90
        or refined_fit.straightness >= fit.straightness + 0.002
    )
    if not improved:
        return seg_points, fit
    return refined_points, refined_fit


def full_feature_refine_enabled(args: Optional[argparse.Namespace]) -> bool:
    if args is None:
        return False
    return (
        getattr(args, "preclean_enable", False)
        and getattr(args, "adaptive_min_len_enable", False)
        and getattr(args, "merge_enable", False)
        and getattr(args, "global_map_merge_enable", False)
        and getattr(args, "huber_delta", 0.0) > 0.0
        and getattr(args, "huber_iters", 0) > 0
        and fit_line_tls_huber is ORIGINAL_FIT_LINE_TLS_HUBER
    )


def build_segment_from_points(
    seg_points: np.ndarray,
    idx_start: int,
    idx_end: int,
    huber_delta: float,
    huber_iters: int,
    args: Optional[argparse.Namespace] = None,
) -> Segment:
    use_points, fit = robust_refine_segment_points(seg_points, huber_delta, huber_iters, args)
    proj = (use_points - fit.mu) @ fit.direction
    p1 = fit.mu + np.min(proj) * fit.direction
    p2 = fit.mu + np.max(proj) * fit.direction
    return Segment(
        idx_start=idx_start,
        idx_end=idx_end,
        p1=p1,
        p2=p2,
        length=float(np.linalg.norm(p2 - p1)),
        rms=fit.rms,
        max_res=fit.max_res,
        straightness=fit.straightness,
        feature=float(fit.straightness * np.exp(-fit.rms / 0.02)),
        n_points=len(seg_points),
    )


def extend_high_quality_segment_support(
    points: np.ndarray,
    seg: Segment,
    angle_increment: float,
    args: argparse.Namespace,
) -> Segment:
    if not full_feature_refine_enabled(args):
        return seg
    if len(points) < 2 or seg.idx_start < 0 or seg.idx_end >= len(points):
        return seg
    if seg.length < max(args.min_len_m * 0.70, 0.18):
        return seg
    if seg.straightness < max(args.final_quality_straightness_min - 0.004, 0.996):
        return seg
    if seg.max_res > max(args.final_quality_max_res_m * 0.45, 0.020):
        return seg

    search_pad = max(args.min_pts + 14, 26)
    win_start = max(0, seg.idx_start - search_pad)
    win_end = min(len(points) - 1, seg.idx_end + search_pad)
    if win_end - win_start + 1 <= seg.n_points + 2:
        return seg

    center = 0.5 * (seg.p1 + seg.p2)
    direction = seg_dir(seg)
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    win_idx = np.arange(win_start, win_end + 1)
    win_points = points[win_idx]
    proj = (win_points - center) @ direction
    perp = np.abs((win_points - center) @ normal)

    seg_proj = np.array([(seg.p1 - center) @ direction, (seg.p2 - center) @ direction], dtype=np.float64)
    tmin = float(np.min(seg_proj))
    tmax = float(np.max(seg_proj))
    proj_margin = float(np.clip(seg.length * 0.85 + 0.12, 0.20, 0.56))
    perp_thr = float(min(max(0.010, seg.max_res * 1.18, seg.rms * 3.0), 0.022))

    base_ranges = np.linalg.norm(points[seg.idx_start:seg.idx_end + 1], axis=1)
    r_med = median(base_ranges) if len(base_ranges) > 0 else 0.5 * (np.linalg.norm(seg.p1) + np.linalg.norm(seg.p2))
    gap_limit = max(0.055, gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap) * 2.8)

    support_mask = (
        (perp <= perp_thr)
        & (proj >= tmin - proj_margin)
        & (proj <= tmax + proj_margin)
    )
    support_idx = win_idx[support_mask]
    support_points = win_points[support_mask]
    if len(support_idx) <= seg.n_points + 2:
        return seg

    order = np.argsort(proj[support_mask])
    ordered_idx = support_idx[order]
    ordered_points = support_points[order]
    ordered_proj = proj[support_mask][order]
    keep = np.ones(len(ordered_idx), dtype=bool)
    for i in range(1, len(ordered_idx)):
        step_proj = float(abs(ordered_proj[i] - ordered_proj[i - 1]))
        step_xy = float(np.linalg.norm(ordered_points[i] - ordered_points[i - 1]))
        if step_proj > gap_limit and step_xy > gap_limit * 1.15:
            keep[i] = False

    support_idx = ordered_idx[keep]
    if len(support_idx) <= seg.n_points + 2:
        return seg

    proposal = build_segment_from_points(
        points[support_idx],
        int(support_idx[0]),
        int(support_idx[-1]),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    length_gain = proposal.length - seg.length
    if length_gain < max(0.035, seg.length * 0.12):
        return seg
    if proposal.rms > max(seg.rms * 1.45, seg.rms + 0.0035):
        return seg
    if proposal.max_res > max(seg.max_res * 1.50, seg.max_res + 0.0065):
        return seg
    if proposal.straightness < seg.straightness - 0.008:
        return seg

    proposal.id = seg.id
    proposal.feature = max(seg.feature, proposal.feature)
    proposal.is_feature = seg.is_feature
    proposal.is_fragment = seg.is_fragment
    proposal.merged_from = list(seg.merged_from)
    return proposal


def extract_endpoint_branch_candidates(
    run_points: np.ndarray,
    indices: np.ndarray,
    seg_start: int,
    seg_end: int,
    parent_seg: Segment,
    args: argparse.Namespace,
) -> List[Segment]:
    if seg_end - seg_start + 1 < max(args.frag_min_pts + 1, 4):
        return []

    branch_candidates: List[Segment] = []
    parent_dir = seg_dir(parent_seg)
    max_window = min(seg_end - seg_start + 1, max(args.frag_min_pts + 10, args.min_pts + 2))
    min_window = max(3, args.frag_min_pts)

    def try_side(side: str) -> Optional[Segment]:
        best_branch: Optional[Segment] = None
        best_score: Optional[Tuple[float, float, float]] = None

        for win in range(min_window, max_window + 1):
            if side == "left":
                sub_start = seg_start
                sub_end = seg_start + win - 1
                attach_point = parent_seg.p1
            else:
                sub_start = seg_end - win + 1
                sub_end = seg_end
                attach_point = parent_seg.p2

            if sub_start < seg_start or sub_end > seg_end or sub_end - sub_start + 1 < min_window:
                continue

            sub_points = run_points[sub_start:sub_end + 1]
            branch = build_segment_from_points(
                sub_points,
                int(indices[sub_start]),
                int(indices[sub_end]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            branch.is_fragment = True
            branch.is_feature = False

            branch_dir = seg_dir(branch)
            angle_deg = float(np.degrees(np.arccos(np.clip(abs(parent_dir @ branch_dir), -1.0, 1.0))))
            endpoint_attach = min(
                float(np.linalg.norm(branch.p1 - attach_point)),
                float(np.linalg.norm(branch.p2 - attach_point)),
            )

            if not (45.0 <= angle_deg <= 135.0):
                continue
            if branch.length < args.frag_min_len_m or branch.n_points < min_window:
                continue
            if branch.straightness < max(0.94, args.frag_straightness_min - 0.05):
                continue
            if branch.rms > (args.rms_a + args.rms_b * median(np.linalg.norm(sub_points, axis=1))) * 1.9:
                continue
            if endpoint_attach > max(args.merge_gap0_m * 1.6, 0.22):
                continue

            score = (branch.length, -abs(angle_deg - 90.0), branch.straightness, -branch.rms)
            if best_score is None or score > best_score:
                best_branch = branch
                best_score = score

        return best_branch

    left_branch = try_side("left")
    right_branch = try_side("right")
    if left_branch is not None:
        branch_candidates.append(left_branch)
    if right_branch is not None:
        branch_candidates.append(right_branch)
    return branch_candidates


def extend_branch_with_run_context(
    run_points: np.ndarray,
    indices: np.ndarray,
    seed_start: int,
    seed_end: int,
    search_start: int,
    search_end: int,
    attach_point: np.ndarray,
    parent_dir: np.ndarray,
    args: argparse.Namespace,
) -> Segment:
    seed_points = run_points[seed_start:seed_end + 1]
    seed_branch = build_segment_from_points(
        seed_points,
        int(indices[seed_start]),
        int(indices[seed_end]),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )

    if search_start > search_end:
        return seed_branch

    window_points = run_points[search_start:search_end + 1]
    window_indices = indices[search_start:search_end + 1]
    if len(window_points) < len(seed_points):
        return seed_branch

    branch_dir = seg_dir(seed_branch)
    normal = np.array([-branch_dir[1], branch_dir[0]], dtype=np.float64)
    origin = seed_branch.p1

    proj = (window_points - origin) @ branch_dir
    perp = np.abs((window_points - origin) @ normal)
    seed_proj = (seed_points - origin) @ branch_dir
    seed_lo = float(np.min(seed_proj))
    seed_hi = float(np.max(seed_proj))
    attach_proj = float((attach_point - origin) @ branch_dir)

    median_range = median(np.linalg.norm(seed_points, axis=1))
    perp_thr = max(merge_perp_thr_m(median_range, args.merge_perp_base_m, args.merge_perp_cr) * 2.5, 0.07)
    proj_gap = max(args.merge_gap0_m * 2.1, 0.15)
    back_tol = max(args.merge_gap0_m * 1.0, 0.06)

    keep = perp <= perp_thr
    if not np.any(keep):
        return seed_branch

    attach_on_low = abs(attach_proj - seed_lo) <= abs(attach_proj - seed_hi)
    lo = seed_lo
    hi = seed_hi

    for _ in range(16):
        if attach_on_low:
            candidate = keep & (proj >= seed_lo - back_tol) & (proj <= hi + proj_gap)
            if not np.any(candidate):
                break
            new_hi = float(np.max(proj[candidate]))
            if new_hi <= hi + 1e-6:
                break
            hi = new_hi
        else:
            candidate = keep & (proj >= lo - proj_gap) & (proj <= seed_hi + back_tol)
            if not np.any(candidate):
                break
            new_lo = float(np.min(proj[candidate]))
            if new_lo >= lo - 1e-6:
                break
            lo = new_lo

    if attach_on_low:
        candidate = keep & (proj >= seed_lo - back_tol) & (proj <= hi + 1e-9)
    else:
        candidate = keep & (proj >= lo - 1e-9) & (proj <= seed_hi + back_tol)

    selected_points = window_points[candidate]
    selected_indices = window_indices[candidate]
    if len(selected_points) <= len(seed_points):
        return seed_branch

    extended = build_segment_from_points(
        selected_points,
        int(np.min(selected_indices)),
        int(np.max(selected_indices)),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )

    angle_deg = float(np.degrees(np.arccos(np.clip(abs(seg_dir(extended) @ parent_dir), -1.0, 1.0))))
    attach_dist = min(
        float(np.linalg.norm(extended.p1 - attach_point)),
        float(np.linalg.norm(extended.p2 - attach_point)),
    )

    if not (45.0 <= angle_deg <= 135.0):
        return seed_branch
    if extended.straightness < max(0.90, args.frag_straightness_min - 0.09):
        return seed_branch
    if extended.rms > (args.rms_a + args.rms_b * median(np.linalg.norm(selected_points, axis=1))) * 2.4:
        return seed_branch
    if attach_dist > max(args.merge_gap0_m * 2.2, 0.28):
        return seed_branch
    if extended.length <= seed_branch.length + 0.01:
        return seed_branch

    extended.is_fragment = True
    extended.is_feature = False
    return extended


def split_corner_branches_from_segment(
    run_points: np.ndarray,
    indices: np.ndarray,
    seg_start: int,
    seg_end: int,
    parent_seg: Segment,
    args: argparse.Namespace,
) -> List[Segment]:
    if seg_end - seg_start + 1 < max(args.min_pts, 6):
        return []

    parent_dir = seg_dir(parent_seg)
    min_branch_pts = max(3, args.frag_min_pts - 1)
    max_branch_pts = min(max(args.frag_min_pts + 30, args.min_pts + 12), seg_end - seg_start)
    branch_candidates: List[Segment] = []

    def try_side(side: str) -> Optional[Segment]:
        best_branch: Optional[Segment] = None
        best_score: Optional[Tuple[float, float, float]] = None

        for branch_pts in range(min_branch_pts, max_branch_pts + 1):
            if side == "left":
                branch_start = seg_start
                branch_end = seg_start + branch_pts - 1
                trunk_start = branch_end
                trunk_end = seg_end
                attach_point = run_points[branch_end]
                search_start = max(0, seg_start - max(args.min_pts + 20, 52))
                search_end = min(len(run_points) - 1, branch_end + 5)
            else:
                branch_start = seg_end - branch_pts + 1
                branch_end = seg_end
                trunk_start = seg_start
                trunk_end = branch_start
                attach_point = run_points[branch_start]
                search_start = max(0, branch_start - 8)
                search_end = min(len(run_points) - 1, seg_end + max(args.min_pts + 30, 68))

            if branch_start < seg_start or branch_end > seg_end:
                continue
            if trunk_end - trunk_start + 1 < max(args.min_pts // 2, 4):
                continue

            branch_points = run_points[branch_start:branch_end + 1]
            trunk_points = run_points[trunk_start:trunk_end + 1]
            seed_branch = build_segment_from_points(
                branch_points,
                int(indices[branch_start]),
                int(indices[branch_end]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            seed_dir = seg_dir(seed_branch)
            parent_is_vertical = abs(parent_dir[1]) >= 0.9
            seed_is_horizontal = abs(seed_dir[0]) >= 0.94
            if side == "left" and parent_is_vertical and seed_is_horizontal:
                search_start = max(0, search_start - args.corner_branch_left_lookback_extra)
                search_end = min(len(run_points) - 1, search_end + 1)

            branch = seed_branch
            branch = extend_branch_with_run_context(
                run_points,
                indices,
                branch_start,
                branch_end,
                search_start,
                search_end,
                attach_point,
                parent_dir,
                args,
            )
            trunk = build_segment_from_points(
                trunk_points,
                int(indices[trunk_start]),
                int(indices[trunk_end]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )

            branch_dir = seg_dir(branch)
            trunk_dir = seg_dir(trunk)
            angle_deg = float(np.degrees(np.arccos(np.clip(abs(branch_dir @ trunk_dir), -1.0, 1.0))))
            attach_dist = min(
                float(np.linalg.norm(branch.p1 - attach_point)),
                float(np.linalg.norm(branch.p2 - attach_point)),
            )

            if not (45.0 <= angle_deg <= 135.0):
                continue
            if branch.length < max(args.frag_min_len_m, 0.04):
                continue
            if branch.n_points < min_branch_pts:
                continue
            if branch.straightness < max(0.93, args.frag_straightness_min - 0.06):
                continue
            if trunk.straightness < max(args.straightness_min - 0.07, 0.90):
                continue
            if attach_dist > 0.22:
                continue

            branch.is_fragment = True
            branch.is_feature = False
            score = (branch.length, -abs(angle_deg - 90.0), branch.straightness - branch.rms)
            if best_score is None or score > best_score:
                best_branch = branch
                best_score = score

        return best_branch

    left_branch = try_side("left")
    right_branch = try_side("right")
    if left_branch is not None:
        branch_candidates.append(left_branch)
    if right_branch is not None:
        branch_candidates.append(right_branch)
    return branch_candidates


def segment_quality_thresholds(seg_ranges: np.ndarray, args: argparse.Namespace) -> Tuple[float, float, float, float]:
    med_r = median(seg_ranges)
    thr_rms = args.rms_a + args.rms_b * med_r
    thr_max = args.max_a + args.max_b * med_r
    straight_thr = args.straightness_min - np.clip(args.grow_straightness_relax, 0.0, 0.20)
    return med_r, thr_rms, thr_max, straight_thr


def extend_segment_in_run(
    run_points: np.ndarray,
    start: int,
    end: int,
    angle_increment: float,
    args: argparse.Namespace,
) -> Tuple[int, int]:
    if start < 0 or end >= len(run_points) or start >= end:
        return start, end

    rms_relax = max(1.0, args.grow_rms_relax) * 1.15
    max_relax = max(1.0, args.grow_max_relax) * 1.20
    straight_bonus = 0.015
    gap_relax = 1.18
    bridge_steps = 5

    changed = True
    while changed:
        changed = False
        for side in ("left", "right"):
            best_candidate: Optional[Tuple[int, int]] = None
            best_score: Optional[Tuple[int, float]] = None

            for step in range(1, bridge_steps + 1):
                cand_start = start - step if side == "left" else start
                cand_end = end if side == "left" else end + step
                if cand_start < 0 or cand_end >= len(run_points):
                    continue

                boundary_a = run_points[cand_start]
                boundary_b = run_points[cand_start + 1] if side == "left" else run_points[cand_end - 1]
                r_local = 0.5 * (np.linalg.norm(boundary_a) + np.linalg.norm(boundary_b))
                gap = float(np.linalg.norm(boundary_a - boundary_b))
                if gap > gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap) * gap_relax * max(1.0, step * 0.9):
                    continue

                seg_points = run_points[cand_start:cand_end + 1]
                seg_ranges = np.linalg.norm(seg_points, axis=1)
                med_r, thr_rms, thr_max, straight_thr = segment_quality_thresholds(seg_ranges, args)

                dif = np.linalg.norm(np.diff(seg_points, axis=0), axis=1) if len(seg_points) >= 2 else np.array([])
                if len(dif) == 0:
                    continue
                if (
                    float(np.mean(dif)) > mean_gap_thr_m(med_r, angle_increment, args.gap0_m, args.cmean) * gap_relax * max(1.0, step * 0.9)
                    or float(np.max(dif)) > gap_thr_m(med_r, angle_increment, args.gap0_m, args.cgap) * gap_relax * max(1.0, step * 1.2)
                ):
                    continue

                fit = fit_line_tls_huber(seg_points, args.huber_delta, args.huber_iters)
                if (
                    fit.rms > thr_rms * rms_relax
                    or fit.max_res > thr_max * max_relax * max(1.0, step * 1.15)
                    or fit.straightness < (straight_thr - straight_bonus)
                ):
                    continue

                candidate_score = (cand_end - cand_start + 1, fit.straightness - fit.rms)
                if best_score is None or candidate_score > best_score:
                    best_candidate = (cand_start, cand_end)
                    best_score = candidate_score

            if best_candidate is not None:
                start, end = best_candidate
                changed = True
    return start, end


def build_candidate_from_window(
    run_points: np.ndarray,
    indices: np.ndarray,
    r_all: np.ndarray,
    start: int,
    end: int,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[Segment]:
    if start < 0 or end >= len(run_points) or end - start + 1 <= 1:
        return None

    seg_points = run_points[start:end + 1]
    dif = np.linalg.norm(np.diff(seg_points, axis=0), axis=1) if len(seg_points) >= 2 else np.array([])
    if len(dif) == 0:
        return None

    r_med = median(r_all[start:end + 1])
    mean_gap = float(np.mean(dif))
    max_gap = float(np.max(dif))
    if (
        mean_gap > mean_gap_thr_m(r_med, angle_increment, args.gap0_m, args.cmean)
        or max_gap > gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
    ):
        return None

    seg = build_segment_from_points(
        seg_points,
        int(indices[start]),
        int(indices[end]),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    noise_ratio = estimate_noise_ratio_from_points(seg_points, r_med, angle_increment)
    min_len_local = adaptive_min_len_m(
        median_range=r_med,
        noise_ratio=noise_ratio,
        min_len_m=args.min_len_m,
        adaptive_min_len_enable=args.adaptive_min_len_enable,
        adaptive_min_len_ref_range_m=args.adaptive_min_len_ref_range_m,
        adaptive_min_len_dist_exp=args.adaptive_min_len_dist_exp,
        adaptive_min_len_noise_gain=args.adaptive_min_len_noise_gain,
        adaptive_min_len_scale_min=args.adaptive_min_len_scale_min,
        adaptive_min_len_scale_max=args.adaptive_min_len_scale_max,
    )

    seg.is_feature = seg.n_points >= args.min_pts and (
        seg.length >= min_len_local or short_feature_candidate_ok(seg, r_med, noise_ratio, args)
    )
    seg.is_fragment = False
    if (
        args.frag_enable
        and seg.n_points >= args.frag_min_pts
        and seg.length >= args.frag_min_len_m
        and seg.straightness >= args.frag_straightness_min
    ):
        seg.feature = float(seg.straightness * np.exp(-seg.rms / args.frag_rms_scale))
        seg.is_fragment = True

    if not (seg.is_feature or seg.is_fragment):
        return None
    return seg


def extract_candidates_from_run(
    run_points: np.ndarray,
    indices: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> List[Segment]:
    candidates: List[Segment] = []
    min_pts = args.min_pts
    frag_enable = args.frag_enable
    frag_min_pts = args.frag_min_pts
    grow_min_pts = frag_min_pts if frag_enable else min_pts

    r_all = np.linalg.norm(run_points, axis=1)
    n = len(run_points)
    j = 0

    while j < n - 1:
        i = j
        accepted = False

        while i + 1 < n:
            r_local = 0.5 * (r_all[i] + r_all[i + 1])
            gap = float(np.linalg.norm(run_points[i + 1] - run_points[i]))
            if gap > gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap):
                break

            i += 1
            if i - j + 1 >= grow_min_pts:
                seg_points = run_points[j:i + 1]
                fit = fit_line_tls_huber(seg_points, args.huber_delta, args.huber_iters)
                med_r = median(r_all[j:i + 1])
                thr_rms = args.rms_a + args.rms_b * med_r
                thr_max = args.max_a + args.max_b * med_r

                if (
                    fit.rms > thr_rms * max(1.0, args.grow_rms_relax)
                    or fit.max_res > thr_max * max(1.0, args.grow_max_relax)
                    or fit.straightness < (args.straightness_min - np.clip(args.grow_straightness_relax, 0.0, 0.20))
                ):
                    i -= 1
                    break

        end = i
        if end - j + 1 >= grow_min_pts:
            ext_start, ext_end = extend_segment_in_run(run_points, j, end, angle_increment, args)
            trial_windows = [(ext_start, ext_end)]
            if (j, end) != (ext_start, ext_end):
                trial_windows.append((j, end))

            best_seg: Optional[Segment] = None
            best_window: Optional[Tuple[int, int]] = None
            best_score: Optional[Tuple[int, int, float, float, float]] = None
            for cand_start, cand_end in trial_windows:
                seg = build_candidate_from_window(run_points, indices, r_all, cand_start, cand_end, angle_increment, args)
                if seg is None:
                    continue
                score = (int(seg.is_feature), int(seg.is_fragment), seg.length, seg.straightness, -seg.rms)
                if best_score is None or score > best_score:
                    best_seg = seg
                    best_window = (cand_start, cand_end)
                    best_score = score

            if best_seg is not None and best_window is not None:
                win_start, win_end = best_window
                candidates.append(best_seg)
                accepted = True
                candidates.extend(
                    extract_endpoint_branch_candidates(
                        run_points,
                        indices,
                        win_start,
                        win_end,
                        best_seg,
                        args,
                    )
                )
                candidates.extend(
                    split_corner_branches_from_segment(
                        run_points,
                        indices,
                        win_start,
                        win_end,
                        best_seg,
                        args,
                    )
                )

        if accepted:
            j = end + 1
        else:
            j += 1

    candidates.sort(key=lambda s: (s.idx_start, s.idx_end))
    return candidates


def extract_all_candidates(points: np.ndarray, angle_increment: float, args: argparse.Namespace) -> List[Segment]:
    indices = np.arange(len(points), dtype=np.int64)
    if len(indices) == 0:
        return []

    runs: List[Tuple[int, int]] = []
    s = int(indices[0])
    p = int(indices[0])
    for ii in indices[1:]:
        ii = int(ii)
        if ii == p + 1:
            p = ii
        else:
            runs.append((s, p))
            s = ii
            p = ii
    runs.append((s, p))

    all_candidates: List[Segment] = []
    for rs, re in runs:
        run_points = points[rs:re + 1]
        run_indices = indices[rs:re + 1]
        all_candidates.extend(extract_candidates_from_run(run_points, run_indices, angle_increment, args))

    all_candidates.sort(key=lambda s: (s.idx_start, s.idx_end))
    return all_candidates


def seg_dir(seg: Segment) -> np.ndarray:
    return normalize(seg.p2 - seg.p1)


def segment_midpoint(seg: Segment) -> np.ndarray:
    return 0.5 * (seg.p1 + seg.p2)


def segment_mid_angle_deg(seg: Segment) -> float:
    mid = segment_midpoint(seg)
    return float(np.degrees(np.mod(np.arctan2(mid[1], mid[0]), 2.0 * np.pi)))


def segment_midpoint_distance(seg1: Segment, seg2: Segment) -> float:
    return float(np.linalg.norm(segment_midpoint(seg1) - segment_midpoint(seg2)))


def segment_included_angle_deg(seg1: Segment, seg2: Segment) -> float:
    d1 = seg_dir(seg1)
    d2 = seg_dir(seg2)
    dot = float(np.clip(abs(d1 @ d2), -1.0, 1.0))
    return float(np.degrees(np.arccos(dot)))


def segment_endpoint_min_distance(seg1: Segment, seg2: Segment) -> float:
    distances = (
        np.linalg.norm(seg1.p1 - seg2.p1),
        np.linalg.norm(seg1.p1 - seg2.p2),
        np.linalg.norm(seg1.p2 - seg2.p1),
        np.linalg.norm(seg1.p2 - seg2.p2),
    )
    return float(min(distances))


def support_overlap_ratio(seg1: Segment, seg2: Segment) -> float:
    lo = max(seg1.idx_start, seg2.idx_start)
    hi = min(seg1.idx_end, seg2.idx_end)
    if hi < lo:
        return 0.0
    overlap = hi - lo + 1
    shorter = max(1, min(seg1.idx_end - seg1.idx_start + 1, seg2.idx_end - seg2.idx_start + 1))
    return float(overlap / shorter)


def segment_endpoint_to_endpoint_distance(seg1: Segment, seg2: Segment) -> float:
    return segment_endpoint_min_distance(seg1, seg2)


def segment_support_axis_distance(seg1: Segment, seg2: Segment) -> float:
    d1 = seg_dir(seg1)
    d2 = seg_dir(seg2)

    axis = d1 if abs(d1 @ d2) >= 0.0 else -d1
    origin = segment_midpoint(seg1)

    proj1 = sorted((float((seg1.p1 - origin) @ axis), float((seg1.p2 - origin) @ axis)))
    proj2 = sorted((float((seg2.p1 - origin) @ axis), float((seg2.p2 - origin) @ axis)))

    if proj1[1] < proj2[0]:
        return proj2[0] - proj1[1]
    if proj2[1] < proj1[0]:
        return proj1[0] - proj2[1]
    return 0.0


def sort_segments_by_mid_angle(segments: List[Segment]) -> List[Segment]:
    segments.sort(key=lambda s: (segment_mid_angle_deg(s), s.idx_start, s.idx_end))
    for idx, seg in enumerate(segments, start=1):
        seg.id = idx
    return segments


def is_better_segment_for_dedup(lhs: Segment, rhs: Segment) -> bool:
    if abs(lhs.straightness - rhs.straightness) > 1e-9:
        return lhs.straightness > rhs.straightness
    if abs(lhs.rms - rhs.rms) > 1e-9:
        return lhs.rms < rhs.rms
    if abs(lhs.max_res - rhs.max_res) > 1e-9:
        return lhs.max_res < rhs.max_res
    if abs(lhs.length - rhs.length) > 1e-9:
        return lhs.length > rhs.length
    return lhs.n_points >= rhs.n_points


def deduplicate_segments(segments: List[Segment]) -> List[Segment]:
    if len(segments) <= 1:
        return segments

    removed = [False] * len(segments)
    for i in range(len(segments)):
        if removed[i]:
            continue
        for j in range(i + 1, len(segments)):
            if removed[j]:
                continue
            angle_deg = segment_included_angle_deg(segments[i], segments[j])
            midpoint_dist = segment_midpoint_distance(segments[i], segments[j])
            if angle_deg >= 10.0 or midpoint_dist >= 0.15:
                continue

            support_gap = segment_support_axis_distance(segments[i], segments[j])
            if support_gap > 0.05:
                continue

            if is_better_segment_for_dedup(segments[j], segments[i]):
                removed[i] = True
                break
            removed[j] = True

    deduped = [seg for seg, flag in zip(segments, removed) if not flag]
    deduped.sort(key=lambda s: (s.idx_start, s.idx_end))
    for idx, seg in enumerate(deduped, start=1):
        seg.id = idx
    return deduped


def try_merge_two_segments(
    seg1: Segment,
    seg2: Segment,
    points: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[Segment]:
    idx_gap = seg2.idx_start - seg1.idx_end
    if idx_gap < 0 or idx_gap > args.merge_max_index_gap:
        return None

    p1a = seg1.p1.copy()
    p1b = seg1.p2.copy()
    p2a = seg2.p1.copy()
    p2b = seg2.p2.copy()

    d1 = seg_dir(seg1)
    d2 = seg_dir(seg2)

    merge_scale = 1.0
    if args.adaptive_merge_enable:
        ref_range = max(args.adaptive_merge_ref_range_m, 0.05)
        r_mid = 0.5 * (np.linalg.norm(p1b) + np.linalg.norm(p2a))
        dist_ratio = float(np.clip(r_mid / ref_range, 0.5, 4.0))

        lo = max(seg1.idx_start, seg1.idx_end - 2)
        hi = min(seg2.idx_end, seg2.idx_start + 2)
        boundary_points = points[lo:hi + 1] if hi >= lo else np.empty((0, 2), dtype=np.float64)
        noise_ratio = estimate_noise_ratio_from_points(boundary_points, max(r_mid, 0.05), angle_increment)

        merge_scale = float(np.clip(
            1.0 + args.adaptive_merge_dist_gain * max(0.0, dist_ratio - 1.0) + args.adaptive_merge_noise_gain * noise_ratio,
            args.adaptive_merge_scale_min,
            args.adaptive_merge_scale_max,
        ))

    cos_thr = float(np.cos(np.deg2rad(args.merge_angle_deg * merge_scale * max(1.0, args.merge_relax_factor))))
    dot = float(d1 @ d2)
    if abs(dot) < cos_thr:
        return None

    if dot < 0.0:
        d2 = -d2
        p2a, p2b = p2b, p2a

    r_ref = 0.25 * (np.linalg.norm(p1a) + np.linalg.norm(p1b) + np.linalg.norm(p2a) + np.linalg.norm(p2b))
    mid2 = 0.5 * (p2a + p2b)
    n1 = np.array([-d1[1], d1[0]], dtype=np.float64)
    perp_dist = abs(float((mid2 - p1a) @ n1))
    if perp_dist > merge_perp_thr_m(r_ref, args.merge_perp_base_m, args.merge_perp_cr) * merge_scale * max(1.0, args.merge_relax_factor):
        return None

    t1a = float(p1a @ d1)
    t1b = float(p1b @ d1)
    end1 = p1a if t1a > t1b else p1b

    t2a = float(p2a @ d1)
    t2b = float(p2b @ d1)
    start2 = p2a if t2a < t2b else p2b

    gap_along = max(0.0, float((start2 - end1) @ d1))
    if gap_along > merge_gap_thr_m(r_ref, angle_increment, args.merge_gap0_m, args.merge_cgap) * merge_scale * max(1.0, args.merge_relax_factor):
        return None

    merged_points = points[seg1.idx_start:seg2.idx_end + 1]
    if len(merged_points) < args.merge_min_pts:
        return None

    merged = build_segment_from_points(merged_points, seg1.idx_start, seg2.idx_end, args.huber_delta, args.huber_iters, args=args)
    if merged.length < 0.03:
        return None

    dif = np.linalg.norm(np.diff(merged_points, axis=0), axis=1) if len(merged_points) >= 2 else np.array([])
    if len(dif) > 0:
        max_allowed = 2.0 * merge_gap_thr_m(r_ref, angle_increment, args.merge_gap0_m, args.merge_cgap) * merge_scale * max(1.0, args.merge_relax_factor)
        if float(np.max(dif)) > max_allowed:
            return None

    ranges = np.linalg.norm(merged_points, axis=1)
    r_med = median(ranges) if len(ranges) > 0 else max(r_ref, 0.05)
    noise_ratio = estimate_noise_ratio_from_points(merged_points, r_med, angle_increment)
    min_len_local = adaptive_min_len_m(
        median_range=r_med,
        noise_ratio=noise_ratio,
        min_len_m=args.min_len_m,
        adaptive_min_len_enable=args.adaptive_min_len_enable,
        adaptive_min_len_ref_range_m=args.adaptive_min_len_ref_range_m,
        adaptive_min_len_dist_exp=args.adaptive_min_len_dist_exp,
        adaptive_min_len_noise_gain=args.adaptive_min_len_noise_gain,
        adaptive_min_len_scale_min=args.adaptive_min_len_scale_min,
        adaptive_min_len_scale_max=args.adaptive_min_len_scale_max,
    )

    merged.is_feature = merged.n_points >= args.min_pts and merged.length >= min_len_local
    merged.is_fragment = not merged.is_feature
    merged.merged_from = [(seg1.idx_start, seg1.idx_end), (seg2.idx_start, seg2.idx_end)]
    return merged


def merge_and_extend_candidates(points: np.ndarray, candidates: List[Segment], angle_increment: float, args: argparse.Namespace) -> List[Segment]:
    if not candidates:
        return []

    cand = sorted(candidates, key=lambda s: (s.idx_start, s.idx_end))
    merged: List[Segment] = []
    i = 0

    while i < len(cand):
        cur = cand[i]
        j = i + 1
        changed = False

        while j < len(cand):
            if cand[j].idx_start - cur.idx_end > args.merge_max_index_gap:
                break
            merged_candidate = try_merge_two_segments(cur, cand[j], points, angle_increment, args)
            if merged_candidate is not None:
                cur = merged_candidate
                changed = True
            j += 1

        merged.append(cur)

        if changed:
            k = i + 1
            while k < len(cand) and cand[k].idx_start <= cur.idx_end:
                k += 1
            i = k
        else:
            i += 1

    features: List[Segment] = []
    next_id = 1
    for seg in merged:
        if seg.is_feature:
            seg.id = next_id
            next_id += 1
            features.append(seg)

    features.sort(key=lambda s: (s.idx_start, s.idx_end))
    return features


def recover_salient_fragments(candidates: List[Segment], features: List[Segment], args: argparse.Namespace) -> List[Segment]:
    if not candidates:
        return features

    recovered = list(features)
    min_promoted_length = max(args.frag_min_len_m, min(args.min_len_m * 0.85, args.min_len_m - 0.01))
    min_promoted_points = max(args.frag_min_pts, args.min_pts // 2)
    corner_attach_thr = max(args.merge_gap0_m * 1.5, 0.12)
    orthogonal_attach_thr = max(args.merge_gap0_m * 1.2, 0.12)
    corner_branch_min_length = max(args.frag_min_len_m, min(args.min_len_m * 0.30, 0.07))
    corner_branch_min_points = max(3, args.frag_min_pts - 1)
    promoted_branch_min_length = max(corner_branch_min_length, min(args.min_len_m * 0.80, 0.16))

    fragment_pool = [
        seg for seg in candidates
        if seg.is_fragment and not seg.is_feature and seg.length >= corner_branch_min_length and seg.n_points >= corner_branch_min_points
    ]
    fragment_pool.sort(key=lambda s: (-s.straightness, s.rms, -s.length, -s.n_points))

    for frag in fragment_pool:
        duplicate = False
        attached_to_corner = False
        orthogonal_corner_branch = False

        for ref in recovered:
            if segment_included_angle_deg(frag, ref) < 10.0 and segment_midpoint_distance(frag, ref) < 0.15:
                if segment_support_axis_distance(frag, ref) <= 0.05:
                    duplicate = True
                    break
            angle_deg = segment_included_angle_deg(frag, ref)
            if support_overlap_ratio(frag, ref) > 0.75 and angle_deg < 12.0:
                duplicate = True
                break
            if segment_endpoint_min_distance(frag, ref) <= corner_attach_thr:
                attached_to_corner = True
            if 55.0 <= angle_deg <= 125.0 and segment_endpoint_to_endpoint_distance(frag, ref) <= orthogonal_attach_thr:
                orthogonal_corner_branch = True

        if duplicate:
            continue

        frag_range = 0.5 * (np.linalg.norm(frag.p1) + np.linalg.norm(frag.p2))
        strong_fragment = frag.length >= min_promoted_length and frag.n_points >= min_promoted_points
        short_feature_ok = short_feature_candidate_ok(frag, frag_range, 0.0, args)
        branch_ok = (
            orthogonal_corner_branch
            and frag.length >= promoted_branch_min_length
            and frag.n_points >= corner_branch_min_points
            and frag.straightness >= max(0.95, args.frag_straightness_min - 0.04, args.straightness_min - 0.04)
        )
        if (strong_fragment and (attached_to_corner or frag.length >= args.min_len_m)) or short_feature_ok:
            frag.is_feature = True
            frag.is_fragment = False
            recovered.append(frag)
            continue

        if branch_ok:
            frag.is_feature = True
            frag.is_fragment = False
            recovered.append(frag)

    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def segment_is_duplicate_like(candidate: Segment, refs: Sequence[Segment]) -> bool:
    for ref in refs:
        angle_deg = segment_included_angle_deg(candidate, ref)
        if angle_deg >= 10.0:
            continue
        if support_overlap_ratio(candidate, ref) > 0.60:
            return True
        if (
            segment_midpoint_distance(candidate, ref) < 0.15
            and segment_support_axis_distance(candidate, ref) <= 0.05
        ):
            return True
    return False


def segment_normal_offset(seg1: Segment, seg2: Segment) -> float:
    d = seg_dir(seg1)
    n = np.array([-d[1], d[0]], dtype=np.float64)
    c1 = 0.5 * (seg1.p1 + seg1.p2)
    c2 = 0.5 * (seg2.p1 + seg2.p2)
    return float(abs((c2 - c1) @ n))


def recover_collinear_corner_fragments(
    points: np.ndarray,
    candidates: Sequence[Segment],
    refs: Sequence[Segment],
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.corner_fragment_recover_enable:
        return []

    pool = [
        seg for seg in candidates
        if seg.length >= args.corner_fragment_seed_min_len_m
        and seg.n_points >= args.corner_fragment_seed_min_pts
        and seg.straightness >= args.corner_fragment_seed_straightness_min
    ]
    pool.sort(key=lambda s: (s.idx_start, s.idx_end))

    recovered: List[Segment] = []
    for i in range(len(pool)):
        for j in range(i + 1, len(pool)):
            s1, s2 = pool[i], pool[j]
            if s2.idx_start < s1.idx_start:
                s1, s2 = s2, s1

            idx_gap = s2.idx_start - s1.idx_end
            if idx_gap < 0 or idx_gap > args.corner_fragment_max_index_gap:
                continue
            if segment_included_angle_deg(s1, s2) > args.corner_fragment_angle_deg:
                continue
            if segment_normal_offset(s1, s2) > args.corner_fragment_normal_offset_m:
                continue
            if segment_endpoint_to_endpoint_distance(s1, s2) > args.corner_fragment_endpoint_gap_m:
                continue

            seed_idx = np.unique(np.concatenate([
                np.arange(s1.idx_start, s1.idx_end + 1),
                np.arange(s2.idx_start, s2.idx_end + 1),
            ]))
            if len(seed_idx) < args.min_pts:
                continue

            seed = build_segment_from_points(
                points[seed_idx],
                int(seed_idx[0]),
                int(seed_idx[-1]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            direction = seg_dir(seed)
            normal = np.array([-direction[1], direction[0]], dtype=np.float64)
            center = 0.5 * (seed.p1 + seed.p2)
            seed_proj = (points[seed_idx] - center) @ direction
            tmin, tmax = float(np.min(seed_proj)), float(np.max(seed_proj))

            win_start = max(0, int(seed_idx[0]) - args.corner_fragment_context_pts)
            win_end = min(len(points) - 1, int(seed_idx[-1]) + args.corner_fragment_context_pts)
            win_idx = np.arange(win_start, win_end + 1)
            win_points = points[win_idx]
            residual = np.abs((win_points - center) @ normal)
            proj = (win_points - center) @ direction

            support = win_idx[
                (residual <= args.corner_fragment_collect_dist_m)
                & (proj >= tmin - args.corner_fragment_projection_margin_m)
                & (proj <= tmax + args.corner_fragment_projection_margin_m)
            ]
            if len(support) < args.min_pts:
                continue

            for _ in range(max(1, args.corner_fragment_refine_iters)):
                proposal = build_segment_from_points(
                    points[support],
                    int(support[0]),
                    int(support[-1]),
                    args.huber_delta,
                    args.huber_iters,
                    args=args,
                )
                direction = seg_dir(proposal)
                normal = np.array([-direction[1], direction[0]], dtype=np.float64)
                center = 0.5 * (proposal.p1 + proposal.p2)
                residual = np.abs((points[support] - center) @ normal)
                refined = support[residual <= args.corner_fragment_refine_dist_m]
                if len(refined) < args.min_pts:
                    break
                if len(refined) == len(support):
                    support = refined
                    break
                support = refined

            proposal = build_segment_from_points(
                points[support],
                int(support[0]),
                int(support[-1]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            proposal.is_fragment = False
            proposal.is_feature = True

            if proposal.length < args.corner_fragment_min_len_m:
                continue
            if proposal.n_points < args.min_pts:
                continue
            if proposal.rms > args.final_quality_rms_m:
                continue
            if proposal.max_res > args.final_quality_max_res_m:
                continue
            if proposal.straightness < args.corner_fragment_straightness_min:
                continue
            if segment_is_duplicate_like(proposal, refs) or segment_is_duplicate_like(proposal, recovered):
                continue

            recovered.append(proposal)

    return recovered


def recover_dense_vertical_runs(
    points: np.ndarray,
    refs: Sequence[Segment],
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.dense_vertical_recover_enable or len(points) < args.dense_vertical_min_pts:
        return []

    proposals: List[Segment] = []
    max_window = min(args.dense_vertical_max_pts, len(points))
    for start in range(0, len(points) - args.dense_vertical_min_pts + 1):
        for count in range(args.dense_vertical_min_pts, max_window + 1):
            end = start + count - 1
            if end >= len(points):
                break

            seg = build_segment_from_points(
                points[start:end + 1],
                start,
                end,
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            if seg.length < args.dense_vertical_min_len_m or seg.length > args.dense_vertical_max_len_m:
                continue
            if abs(seg_dir(seg)[1]) < args.dense_vertical_abs_dir_y_min:
                continue
            if seg.rms > args.dense_vertical_rms_m:
                continue
            if seg.max_res > args.dense_vertical_max_res_m:
                continue
            if seg.straightness < args.dense_vertical_straightness_min:
                continue
            if segment_is_duplicate_like(seg, refs) or segment_is_duplicate_like(seg, proposals):
                continue

            seg.is_fragment = False
            seg.is_feature = True
            proposals.append(seg)

    proposals.sort(key=lambda s: (s.length, s.n_points, -s.rms), reverse=True)
    kept: List[Segment] = []
    for seg in proposals:
        if segment_is_duplicate_like(seg, kept):
            continue
        kept.append(seg)
        if len(kept) >= args.dense_vertical_max_segments:
            break
    return kept


def try_recover_fragment_chain(
    seg1: Segment,
    seg2: Segment,
    points: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[Segment]:
    if seg2.idx_start < seg1.idx_start:
        seg1, seg2 = seg2, seg1

    if seg1.idx_end >= seg2.idx_start:
        return None
    if seg2.idx_end - seg1.idx_start + 1 > args.frag_chain_max_span_pts:
        return None

    angle_deg = segment_included_angle_deg(seg1, seg2)
    if angle_deg > args.frag_chain_angle_deg:
        return None
    if segment_endpoint_to_endpoint_distance(seg1, seg2) > args.frag_chain_endpoint_gap_m:
        return None
    if segment_support_axis_distance(seg1, seg2) > args.frag_chain_support_gap_m:
        return None

    merged_points = points[seg1.idx_start:seg2.idx_end + 1]
    if len(merged_points) < args.frag_chain_min_pts:
        return None

    dif = np.linalg.norm(np.diff(merged_points, axis=0), axis=1) if len(merged_points) >= 2 else np.array([])
    if len(dif) == 0:
        return None

    r_med = median(np.linalg.norm(merged_points, axis=1))
    max_gap_allowed = args.frag_chain_gap_relax * gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
    if float(np.max(dif)) > max_gap_allowed:
        return None

    merged = build_segment_from_points(
        merged_points,
        seg1.idx_start,
        seg2.idx_end,
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    thr_rms = args.rms_a + args.rms_b * r_med
    thr_max = args.max_a + args.max_b * r_med
    straight_thr = max(args.frag_straightness_min, args.straightness_min - 0.01)

    if merged.length < args.frag_chain_min_len_m:
        return None
    if merged.rms > thr_rms * args.frag_chain_rms_relax:
        return None
    if merged.max_res > thr_max * args.frag_chain_max_relax:
        return None
    if merged.straightness < straight_thr:
        return None

    merged.is_feature = True
    merged.is_fragment = False
    merged.merged_from = [(seg1.idx_start, seg1.idx_end), (seg2.idx_start, seg2.idx_end)]
    return merged


def recover_fragment_chains(
    points: np.ndarray,
    candidates: List[Segment],
    features: List[Segment],
    angle_increment: float,
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.frag_chain_enable:
        return features

    fragment_pool = [
        seg
        for seg in candidates
        if seg.is_fragment and not seg.is_feature and seg.n_points >= args.frag_min_pts
    ]
    if len(fragment_pool) < 2:
        return features

    recovered = list(features)
    proposals: List[Segment] = []

    for i in range(len(fragment_pool)):
        for j in range(i + 1, len(fragment_pool)):
            proposal = try_recover_fragment_chain(fragment_pool[i], fragment_pool[j], points, angle_increment, args)
            if proposal is None:
                continue
            if segment_is_duplicate_like(proposal, recovered) or segment_is_duplicate_like(proposal, proposals):
                continue
            proposals.append(proposal)

    proposals.sort(key=lambda s: (-s.length, -s.straightness, s.rms, -s.n_points))
    for proposal in proposals:
        if segment_is_duplicate_like(proposal, recovered):
            continue
        recovered.append(proposal)

    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def attach_collinear_fragments_to_features(
    candidates: List[Segment],
    features: List[Segment],
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.global_map_merge_enable or not features:
        return features

    fragment_pool = [
        seg
        for seg in candidates
        if seg.is_fragment
        and not seg.is_feature
        and seg.n_points >= args.frag_min_pts
        and seg.length >= max(args.frag_min_len_m, 0.05)
    ]
    if not fragment_pool:
        return features

    recovered = list(features)
    changed = True
    while changed:
        changed = False
        best_feature_idx = -1
        best_fragment_idx = -1
        best_attempt: Optional[Tuple[Segment, float, float]] = None
        best_score: Optional[Tuple[float, float, float, float, float]] = None

        for feat_idx, feat in enumerate(recovered):
            for frag_idx, frag in enumerate(fragment_pool):
                attempt = try_global_merge_two_segments(feat, frag, args)
                if attempt is None:
                    continue

                merged, gap_m, angle_deg = attempt
                length_gain = merged.length - feat.length
                if length_gain < max(0.05, 0.35 * frag.length):
                    continue

                score = (
                    length_gain,
                    -gap_m,
                    -angle_deg,
                    merged.straightness,
                    -merged.rms,
                )
                if best_score is None or score > best_score:
                    best_feature_idx = feat_idx
                    best_fragment_idx = frag_idx
                    best_attempt = attempt
                    best_score = score

        if best_attempt is None:
            break

        merged, _, _ = best_attempt
        recovered[best_feature_idx] = merged
        fragment_pool.pop(best_fragment_idx)
        changed = True

    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def try_global_merge_two_segments(seg1: Segment, seg2: Segment, args: argparse.Namespace) -> Optional[Tuple[Segment, float, float]]:
    a1 = seg1.p1.copy()
    b1 = seg1.p2.copy()
    a2 = seg2.p1.copy()
    b2 = seg2.p2.copy()

    d1 = normalize(b1 - a1)
    d2 = normalize(b2 - a2)

    dot = float(d1 @ d2)
    if dot < 0.0:
        d2 = -d2
        a2, b2 = b2, a2
        dot = -dot

    dot = float(np.clip(dot, -1.0, 1.0))
    angle_deg = float(np.degrees(np.arccos(dot)))
    if angle_deg > args.global_map_merge_angle_deg:
        return None

    n1 = np.array([-d1[1], d1[0]], dtype=np.float64)
    perp_a2 = abs(float((a2 - a1) @ n1))
    perp_b2 = abs(float((b2 - a1) @ n1))
    perp_mid2 = abs(float((0.5 * (a2 + b2) - a1) @ n1))
    perp_err = max(perp_a2, perp_b2, perp_mid2)
    if perp_err > args.global_map_merge_perp_m:
        return None

    t1a = float(a1 @ d1)
    t1b = float(b1 @ d1)
    t2a = float(a2 @ d1)
    t2b = float(b2 @ d1)

    s1, e1 = min(t1a, t1b), max(t1a, t1b)
    s2, e2 = min(t2a, t2b), max(t2a, t2b)
    overlap = min(e1, e2) - max(s1, s2)
    gap_m = 0.0 if overlap >= -args.global_map_merge_overlap_tol_m else -overlap
    if gap_m > args.global_map_merge_endpoint_gap_m:
        return None

    merge_pts = np.vstack([seg1.p1, seg1.p2, seg2.p1, seg2.p2])
    merged = build_segment_from_points(
        merge_pts,
        min(seg1.idx_start, seg2.idx_start),
        max(seg1.idx_end, seg2.idx_end),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    merged.n_points = max(merged.n_points, seg1.n_points + seg2.n_points)
    merged.feature = max(seg1.feature, seg2.feature)
    merged.is_feature = merged.length >= args.global_map_merge_min_len_m
    merged.is_fragment = not merged.is_feature
    if merged.length < args.global_map_merge_min_len_m:
        return None

    merged_from = list(seg1.merged_from) if seg1.merged_from else [(seg1.idx_start, seg1.idx_end)]
    merged_from.extend(seg2.merged_from if seg2.merged_from else [(seg2.idx_start, seg2.idx_end)])
    merged.merged_from = sorted(set(merged_from))
    return merged, gap_m, angle_deg


def stitch_collinear_segments_global(segments: List[Segment], args: argparse.Namespace) -> List[Segment]:
    if not args.global_map_merge_enable or len(segments) <= 1:
        return segments

    segs = list(segments)
    for _ in range(max(1, args.global_map_merge_max_passes)):
        changed = False
        while True:
            best_i = -1
            best_j = -1
            best_result: Optional[Tuple[Segment, float, float]] = None

            for i in range(len(segs)):
                for j in range(i + 1, len(segs)):
                    attempt = try_global_merge_two_segments(segs[i], segs[j], args)
                    if attempt is None:
                        continue
                    merged, gap_m, angle_deg = attempt
                    if best_result is None:
                        best_i, best_j, best_result = i, j, attempt
                        continue

                    best_merged, best_gap, best_angle = best_result
                    better = (
                        gap_m < best_gap - 1e-9
                        or (abs(gap_m - best_gap) <= 1e-9 and angle_deg < best_angle - 1e-9)
                        or (
                            abs(gap_m - best_gap) <= 1e-9
                            and abs(angle_deg - best_angle) <= 1e-9
                            and merged.length > best_merged.length + 1e-9
                        )
                    )
                    if better:
                        best_i, best_j, best_result = i, j, attempt

            if best_result is None:
                break

            merged, _, _ = best_result
            if best_i > best_j:
                best_i, best_j = best_j, best_i
            segs.pop(best_j)
            segs.pop(best_i)
            segs.append(merged)
            changed = True

        if not changed:
            break
        segs = sort_segments_by_mid_angle(deduplicate_segments(segs))

    segs = sort_segments_by_mid_angle(deduplicate_segments(segs))
    return segs


def estimate_angle_increment(points: np.ndarray) -> float:
    bearings = np.unwrap(np.arctan2(points[:, 1], points[:, 0]))
    diffs = np.abs(np.diff(bearings))
    diffs = diffs[np.isfinite(diffs) & (diffs > 1e-6)]
    if len(diffs) == 0:
        return np.deg2rad(0.5)
    upper = float(np.percentile(diffs, 80))
    filtered = diffs[diffs <= max(upper, 1e-6)]
    if len(filtered) == 0:
        filtered = diffs
    return float(np.median(filtered))


def extract_segments(points: np.ndarray, args: argparse.Namespace) -> Tuple[List[Segment], float]:
    angle_increment = float(args.angle_increment) if args.angle_increment is not None else estimate_angle_increment(points)
    points_for_extract = preprocess_points(points, angle_increment, args)
    candidates = extract_all_candidates(points_for_extract, angle_increment, args)

    if args.merge_enable:
        segments = merge_and_extend_candidates(points_for_extract, candidates, angle_increment, args)
    else:
        segments = []
        next_id = 1
        for seg in candidates:
            if seg.is_feature:
                seg.id = next_id
                next_id += 1
            segments.append(seg)
        segments.sort(key=lambda s: (s.idx_start, s.idx_end))

    segments = recover_salient_fragments(candidates, segments, args)
    segments = recover_fragment_chains(points_for_extract, candidates, segments, angle_increment, args)
    segments = attach_collinear_fragments_to_features(candidates, segments, args)
    segments = sort_segments_by_mid_angle(segments)
    segments = deduplicate_segments(segments)
    segments = sort_segments_by_mid_angle(segments)
    segments = stitch_collinear_segments_global(segments, args)
    if full_feature_refine_enabled(args):
        segments = [
            extend_high_quality_segment_support(points_for_extract, seg, angle_increment, args)
            for seg in segments
        ]
        segments = sort_segments_by_mid_angle(deduplicate_segments(segments))
    return segments, angle_increment


def extract_segments_from_input_layout(
    points: np.ndarray,
    input_path: Path,
    args: argparse.Namespace,
) -> Tuple[List[Segment], float, bool]:
    frame_layouts = load_frame_layouts(input_path)
    return extract_segments_from_layout(points, frame_layouts, args)


def extract_segments_from_layout(
    points: np.ndarray,
    frame_layouts: Sequence[dict],
    args: argparse.Namespace,
) -> Tuple[List[Segment], float, bool]:
    """Process already loaded frame metadata without performing file I/O."""
    if not frame_layouts:
        segments, angle_increment = extract_segments(points, args)
        return segments, angle_increment, False

    all_segments: List[Segment] = []
    angle_values: List[float] = []

    for frame in frame_layouts:
        start = int(frame["point_start"])
        count = int(frame["point_count"])
        end = start + count
        if start < 0 or end > len(points):
            continue

        global_frame_points = points[start:end]
        local_frame_points = (
            global_frame_points
            - frame["layout_offset"][None, :]
            + frame["source_center"][None, :]
        )
        if len(local_frame_points) < 2:
            continue

        frame_args = argparse.Namespace(**vars(args))
        if frame["angle_increment_rad"] is not None:
            frame_args.angle_increment = float(frame["angle_increment_rad"])

        frame_segments, angle_increment = extract_segments(local_frame_points, frame_args)
        angle_values.append(float(angle_increment))
        local_refs = [
            seg for seg in frame_segments
            if (
                seg.n_points >= frame_args.min_pts
                and seg.length >= frame_args.final_quality_min_len_m
                and seg.rms <= frame_args.final_quality_rms_m
                and seg.max_res <= frame_args.final_quality_max_res_m
                and seg.straightness >= frame_args.final_quality_straightness_min
            )
        ]
        local_candidates = extract_all_candidates(local_frame_points, angle_increment, frame_args)
        corner_recovered = recover_collinear_corner_fragments(
            local_frame_points,
            local_candidates,
            local_refs,
            frame_args,
        )
        dense_vertical_recovered = recover_dense_vertical_runs(
            local_frame_points,
            list(local_refs) + corner_recovered,
            frame_args,
        )
        frame_segments = list(frame_segments) + corner_recovered + dense_vertical_recovered

        for seg in frame_segments:
            mapped = replace(seg)
            mapped.p1 = seg.p1 - frame["source_center"] + frame["layout_offset"]
            mapped.p2 = seg.p2 - frame["source_center"] + frame["layout_offset"]
            mapped.idx_start = seg.idx_start + start
            mapped.idx_end = seg.idx_end + start
            mapped.merged_from = [
                (int(s) + start, int(e) + start)
                for s, e in seg.merged_from
            ]
            all_segments.append(mapped)

    all_segments = sort_segments_by_mid_angle(all_segments)
    if args.final_quality_enable:
        all_segments = [
            seg for seg in all_segments
            if (
                seg.n_points >= args.min_pts
                and
                seg.length >= args.final_quality_min_len_m
                and
                seg.rms <= args.final_quality_rms_m
                and seg.max_res <= args.final_quality_max_res_m
                and seg.straightness >= args.final_quality_straightness_min
            )
        ]
        all_segments = sort_segments_by_mid_angle(all_segments)
    if angle_values:
        return all_segments, median(angle_values), True

    segments, angle_increment = extract_segments(points, args)
    return segments, angle_increment, False


def plot_segments(
    points: np.ndarray,
    segments: Sequence[Segment],
    out_path: Path,
    show_segments: bool,
    title: str,
    bottom_label: str = "",
) -> None:
    fig, ax = plt.subplots(figsize=(16.8, 9.8), dpi=720)
    point_size = 148.0 if len(points) <= 220 else 112.0
    line_width = 7.2 if show_segments else 0.0
    segment_color = "#d26900"
    ax.set_facecolor("#ffffff")
    ax.scatter(
        points[:, 0],
        points[:, 1],
        s=point_size,
        c="#0b1f5b",
        edgecolors="#111827",
        linewidths=1.55,
        alpha=0.98,
        label="Raw points",
        zorder=1,
        antialiased=True,
    )

    if show_segments:
        drawn = False
        for seg in segments:
            ax.plot(
                [seg.p1[0], seg.p2[0]],
                [seg.p1[1], seg.p2[1]],
                color=segment_color,
                linewidth=line_width,
                alpha=0.98,
                solid_capstyle="round",
                label="Extracted segments" if not drawn else None,
                zorder=3,
                antialiased=True,
            )
            ax.scatter(
                [seg.p1[0], seg.p2[0]],
                [seg.p1[1], seg.p2[1]],
                s=90.0,
                c=segment_color,
                edgecolors="#111827",
                linewidths=1.10,
                zorder=4,
            )
            drawn = True

    ax.set_xlabel("X (m)", fontsize=24, labelpad=10)
    ax.set_ylabel("Y (m)", fontsize=24, labelpad=10)
    if title:
        ax.set_title(title, fontsize=34, pad=18)
    ax.set_aspect("equal")
    ax.grid(True, linestyle="--", linewidth=0.8, alpha=0.36, zorder=0)
    ax.tick_params(axis="both", which="major", width=1.1, length=6, labelsize=20)
    for spine in ax.spines.values():
        spine.set_linewidth(1.1)

    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    y_min, y_max = np.min(points[:, 1]), np.max(points[:, 1])
    x_span = max(x_max - x_min, 1e-6)
    y_span = max(y_max - y_min, 1e-6)
    ax.set_xlim(x_min - 0.03 * x_span, x_max + 0.18 * x_span)
    ax.set_ylim(y_min - 0.05 * y_span, y_max + 0.05 * y_span)

    ax.legend(
        loc="lower right",
        bbox_to_anchor=(0.985, 0.06),
        borderaxespad=0.0,
        frameon=True,
        framealpha=0.94,
        edgecolor="#d0d0d0",
        fontsize=24,
        markerscale=1.45,
        borderpad=0.56,
        labelspacing=0.52,
        handlelength=2.45,
        handletextpad=0.72,
    )

    if bottom_label:
        fig.text(0.5, 0.025, bottom_label, ha="center", va="bottom", fontsize=34)

    fig.subplots_adjust(
        left=0.08,
        right=0.97,
        bottom=0.18 if bottom_label else 0.12,
        top=0.96 if not title else 0.90,
    )
    plt.savefig(out_path, dpi=720, bbox_inches="tight", pad_inches=0.03)
    plt.close()


def summary_metrics(segments: Sequence[Segment]) -> Tuple[float, float, float]:
    if not segments:
        return float("nan"), float("nan"), float("nan")
    weights = np.array([max(1, seg.n_points) for seg in segments], dtype=np.float64)
    total_w = float(np.sum(weights))
    weighted_rms = float(np.sum(np.array([seg.rms for seg in segments]) * weights) / max(total_w, 1.0))
    max_res = float(np.max([seg.max_res for seg in segments]))
    weighted_straightness = float(np.sum(np.array([seg.straightness for seg in segments]) * weights) / max(total_w, 1.0))
    return weighted_rms, max_res, weighted_straightness


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Feature extraction aligned with lidar_line_feature_node.cpp")
    p.add_argument("--input", default="map_points.json", help="Input point cloud JSON")
    p.add_argument("--output-png", default="feature.png", help="Output visualization image")
    p.add_argument("--angle-increment", type=float, default=None, help="Laser angle increment in radians; if omitted, estimate from ordered points")

    p.add_argument("--min-pts", type=int, default=8)
    p.add_argument("--min-len-m", type=float, default=0.20)
    p.add_argument("--preclean-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--preclean-passes", type=int, default=2)
    p.add_argument("--preclean-window", type=int, default=2)
    p.add_argument("--preclean-isolated-gap-scale", type=float, default=2.8)
    p.add_argument("--preclean-gap-scale", type=float, default=1.55)
    p.add_argument("--preclean-run-gap-scale", type=float, default=1.45)
    p.add_argument("--preclean-residual-scale", type=float, default=1.85)
    p.add_argument("--preclean-residual-abs-m", type=float, default=0.028)
    p.add_argument("--preclean-radial-scale", type=float, default=2.40)
    p.add_argument("--preclean-radial-abs-m", type=float, default=0.06)
    p.add_argument("--preclean-small-run-max-pts", type=int, default=4)
    p.add_argument("--preclean-small-run-max-len-m", type=float, default=0.06)
    p.add_argument("--preclean-small-run-straightness", type=float, default=0.90)
    p.add_argument("--adaptive-min-len-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--adaptive-min-len-ref-range-m", type=float, default=2.0)
    p.add_argument("--adaptive-min-len-dist-exp", type=float, default=0.45)
    p.add_argument("--adaptive-min-len-noise-gain", type=float, default=0.05)
    p.add_argument("--adaptive-min-len-scale-min", type=float, default=0.65)
    p.add_argument("--adaptive-min-len-scale-max", type=float, default=1.45)

    p.add_argument("--frag-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--frag-min-pts", type=int, default=4)
    p.add_argument("--frag-min-len-m", type=float, default=0.03)
    p.add_argument("--frag-straightness-min", type=float, default=0.985)
    p.add_argument("--frag-rms-scale", type=float, default=0.02)
    p.add_argument("--frag-chain-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--frag-chain-angle-deg", type=float, default=8.0)
    p.add_argument("--frag-chain-endpoint-gap-m", type=float, default=0.16)
    p.add_argument("--frag-chain-support-gap-m", type=float, default=0.05)
    p.add_argument("--frag-chain-max-span-pts", type=int, default=16)
    p.add_argument("--frag-chain-min-pts", type=int, default=8)
    p.add_argument("--frag-chain-min-len-m", type=float, default=0.15)
    p.add_argument("--frag-chain-gap-relax", type=float, default=2.10)
    p.add_argument("--frag-chain-rms-relax", type=float, default=1.60)
    p.add_argument("--frag-chain-max-relax", type=float, default=1.60)
    p.add_argument(
        "--corner-branch-left-lookback-extra",
        type=int,
        default=14,
        help="Extra points to search backward when splitting a left horizontal branch from a near-vertical segment",
    )

    p.add_argument("--gap0-m", type=float, default=0.01)
    p.add_argument("--cgap", type=float, default=4.0)
    p.add_argument("--cmean", type=float, default=2.5)

    p.add_argument("--merge-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--merge-angle-deg", type=float, default=8.0)
    p.add_argument("--merge-max-index-gap", type=int, default=50)
    p.add_argument("--merge-perp-base-m", type=float, default=0.03)
    p.add_argument("--merge-perp-cr", type=float, default=0.005)
    p.add_argument("--merge-gap0-m", type=float, default=0.10)
    p.add_argument("--merge-cgap", type=float, default=10.0)
    p.add_argument("--merge-min-pts", type=int, default=6)
    p.add_argument("--adaptive-merge-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--adaptive-merge-ref-range-m", type=float, default=2.0)
    p.add_argument("--adaptive-merge-noise-gain", type=float, default=0.25)
    p.add_argument("--adaptive-merge-dist-gain", type=float, default=0.12)
    p.add_argument("--adaptive-merge-scale-min", type=float, default=0.90)
    p.add_argument("--adaptive-merge-scale-max", type=float, default=1.70)

    p.add_argument("--huber-delta", type=float, default=0.02)
    p.add_argument("--huber-iters", type=int, default=6)

    p.add_argument("--rms-a", type=float, default=0.01)
    p.add_argument("--rms-b", type=float, default=0.003)
    p.add_argument("--max-a", type=float, default=0.03)
    p.add_argument("--max-b", type=float, default=0.006)
    p.add_argument("--straightness-min", type=float, default=0.97)
    p.add_argument("--grow-rms-relax", type=float, default=1.20)
    p.add_argument("--grow-max-relax", type=float, default=1.20)
    p.add_argument("--grow-straightness-relax", type=float, default=0.03)
    p.add_argument("--merge-relax-factor", type=float, default=1.25)

    p.add_argument("--global-map-merge-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--global-map-merge-angle-deg", type=float, default=6.0)
    p.add_argument("--global-map-merge-perp-m", type=float, default=0.05)
    p.add_argument("--global-map-merge-endpoint-gap-m", type=float, default=0.20)
    p.add_argument("--global-map-merge-overlap-tol-m", type=float, default=0.08)
    p.add_argument("--global-map-merge-min-len-m", type=float, default=0.20)
    p.add_argument("--global-map-merge-max-passes", type=int, default=4)

    p.add_argument("--final-quality-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--final-quality-min-len-m", type=float, default=0.30)
    p.add_argument("--final-quality-rms-m", type=float, default=0.015)
    p.add_argument("--final-quality-max-res-m", type=float, default=0.045)
    p.add_argument("--final-quality-straightness-min", type=float, default=0.99)
    p.add_argument("--corner-fragment-recover-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--corner-fragment-seed-min-pts", type=int, default=5)
    p.add_argument("--corner-fragment-seed-min-len-m", type=float, default=0.25)
    p.add_argument("--corner-fragment-seed-straightness-min", type=float, default=0.985)
    p.add_argument("--corner-fragment-max-index-gap", type=int, default=18)
    p.add_argument("--corner-fragment-angle-deg", type=float, default=8.0)
    p.add_argument("--corner-fragment-endpoint-gap-m", type=float, default=0.34)
    p.add_argument("--corner-fragment-normal-offset-m", type=float, default=0.04)
    p.add_argument("--corner-fragment-context-pts", type=int, default=6)
    p.add_argument("--corner-fragment-collect-dist-m", type=float, default=0.055)
    p.add_argument("--corner-fragment-refine-dist-m", type=float, default=0.022)
    p.add_argument("--corner-fragment-projection-margin-m", type=float, default=0.45)
    p.add_argument("--corner-fragment-refine-iters", type=int, default=4)
    p.add_argument("--corner-fragment-min-len-m", type=float, default=1.0)
    p.add_argument("--corner-fragment-straightness-min", type=float, default=0.998)
    p.add_argument("--dense-vertical-recover-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--dense-vertical-min-pts", type=int, default=8)
    p.add_argument("--dense-vertical-max-pts", type=int, default=18)
    p.add_argument("--dense-vertical-min-len-m", type=float, default=0.34)
    p.add_argument("--dense-vertical-max-len-m", type=float, default=0.80)
    p.add_argument("--dense-vertical-abs-dir-y-min", type=float, default=0.93)
    p.add_argument("--dense-vertical-rms-m", type=float, default=0.012)
    p.add_argument("--dense-vertical-max-res-m", type=float, default=0.020)
    p.add_argument("--dense-vertical-straightness-min", type=float, default=0.995)
    p.add_argument("--dense-vertical-max-segments", type=int, default=1)
    return p


def run_cli(args: argparse.Namespace) -> None:
    input_path = Path(args.input)
    if args.angle_increment is None:
        hinted_angle_increment = load_angle_increment_hint(input_path)
        if hinted_angle_increment is not None:
            args.angle_increment = hinted_angle_increment

    points = load_points(input_path)
    segments, angle_increment, used_frame_layout = extract_segments_from_input_layout(points, input_path, args)

    output_png_path = Path(args.output_png)
    points_png_path = output_png_path.with_name("points.png")

    plot_title = "UCG-LineFit Line Extraction result"
    points_title = "Original Point Cloud"
    plot_segments(points, segments, output_png_path, show_segments=True, title=plot_title)
    plot_segments(points, segments, points_png_path, show_segments=False, title=points_title)

    avg_rms, max_res, avg_straightness = summary_metrics(segments)

    print("Feature extraction completed")
    print(f"Number of points: {len(points)}")
    print(f"Number of segments: {len(segments)}")
    print(f"Angle increment used: {angle_increment:.8f} rad")
    print(f"Frame layout mode: {'enabled' if used_frame_layout else 'disabled'}")
    if segments:
        print("---- Segment metrics (sorted by midpoint angle) ----")
        for seg in segments:
            print(
                f"line_id={seg.id:02d}, angle={segment_mid_angle_deg(seg):7.2f} deg, "
                f"n={seg.n_points:4d}, length={seg.length:.4f} m, "
                f"RMS={seg.rms:.6f} m, max_res={seg.max_res:.6f} m, "
                f"straightness={seg.straightness:.6f}"
            )
        print("---- Summary metrics ----")
        print(f"Average point-to-line RMS error: {avg_rms:.6f} m")
        print(f"Maximum residual: {max_res:.6f} m")
        print(f"Average straightness: {avg_straightness:.6f}")
    else:
        print("No segments satisfied the thresholds. Please adjust the parameters and try again.")

    print(f"Visualization file: {output_png_path.resolve()}")
    print(f"Points-only visualization file: {points_png_path.resolve()}")


def main() -> None:
    args = build_parser().parse_args()
    run_cli(args)


if __name__ == "__main__":
    main()
''',
    'feature_tour_batch': r'''"""NumPy batch evaluation of equal-length TLS-Huber support windows.

No model or threshold approximation is used: covariance, eigendecomposition,
MAD scales and Huber weights are evaluated along an extra batch dimension.
The caller retains scan order and all acceptance/merging decisions.
"""

from __future__ import annotations

import numpy as np

EPS = 1e-12


def tls_batch(points, weights=None):
    """Vectorized equivalent of feature.fit_line_tls_core for float64 windows."""
    if weights is None:
        weights = np.ones(points.shape[:2], dtype=np.float64)
    denom = np.maximum(np.sum(weights, axis=1), EPS)
    mu = np.sum(points * weights[..., None], axis=1) / denom[:, None]
    q = points - mu[:, None, :]
    cov = np.swapaxes(q * weights[..., None], 1, 2) @ q / denom[:, None, None]
    eigvals, eigvecs = np.linalg.eigh(cov)
    idx = np.argmax(eigvals, axis=1)
    direction = eigvecs[np.arange(len(points)), :, idx].copy()
    direction /= (np.linalg.norm(direction, axis=1) + EPS)[:, None]
    flip = (direction[:, 0] < 0.0) | ((np.abs(direction[:, 0]) < EPS) & (direction[:, 1] < 0.0))
    direction[flip] *= -1.0
    normal = np.column_stack((-direction[:, 1], direction[:, 0]))
    residual = (q @ normal[..., None])[..., 0]
    return mu, direction, residual, eigvals


def fit_windows(points, cfg, angle_increment, huber_iters, sensor_sigma):
    """Return (mu, direction, RMS, MaxRes, straightness) for each window."""
    ranges = np.linalg.norm(points, axis=2)
    r_med = np.median(ranges, axis=1)
    radial_steps = np.abs(np.diff(ranges, axis=1))
    radial_mad = 1.4826 * np.median(
        np.abs(radial_steps - np.median(radial_steps, axis=1)[:, None]), axis=1,
    )
    # Use the existing scalar sensor model so its rounding stays unchanged.
    sensor_scales = np.array([sensor_sigma(float(r), angle_increment, cfg) for r in r_med])
    mu, direction, residual, eigvals = tls_batch(points)
    residual_mad = 1.4826 * np.median(
        np.abs(residual - np.median(residual, axis=1)[:, None]), axis=1,
    )
    sigma = np.maximum.reduce([
        sensor_scales, radial_mad / np.sqrt(2.0), residual_mad,
        np.full(len(points), float(cfg.huber_min_scale_m)),
    ])
    weights = np.ones(points.shape[:2], dtype=np.float64)
    active = np.arange(len(points))
    for _ in range(max(1, int(huber_iters))):
        active_residual = residual[active]
        sigma_res = 1.4826 * np.median(
            np.abs(active_residual - np.median(active_residual, axis=1)[:, None]), axis=1,
        )
        delta = np.maximum(float(cfg.huber_min_delta_m), float(cfg.huber_sigma_gain) * np.maximum(sigma[active], sigma_res))
        abs_res = np.abs(active_residual)
        next_weights = np.where(abs_res <= delta[:, None], 1.0, delta[:, None] / (abs_res + EPS))
        changed = np.any(next_weights != weights, axis=1)
        if not np.any(changed):
            break
        active = active[changed]
        weights = next_weights[changed]
        update = tls_batch(points[active], weights)
        mu[active], direction[active], residual[active], eigvals[active] = update
    rms = np.sqrt(np.mean(residual ** 2, axis=1))
    max_res = np.max(np.abs(residual), axis=1)
    lam1 = np.maximum(eigvals[:, 1], 0.0)
    lam2 = np.maximum(eigvals[:, 0], 0.0)
    straightness = 1.0 - lam2 / (lam1 + lam2 + EPS)
    return mu, direction, rms, max_res, straightness
''',
    'feature_tour_native': r'''"""Optional compiled kernels; the model and its stopping rules stay unchanged.

Install numba and scipy to enable. No fast-math, parallel
reductions, relaxed Huber convergence, or reduced iteration count is used.
Compilation/cache loading belongs to prepare(), never to reported core timing.
"""
from __future__ import annotations

import math
import numpy as np
from typing import NamedTuple

try:
    from numba import njit
    import scipy.linalg  # Numba's LAPACK bridge requires SciPy.
except ImportError:
    AVAILABLE = False
else:
    AVAILABLE = True

EPS = 1e-12
_READY = False


class FitConfig(NamedTuple):
    angle: float
    iters: int
    noise_r: float
    noise_slope: float
    noise_angle: float
    min_scale: float
    min_delta: float
    sigma_gain: float


class GapConfig(NamedTuple):
    enabled: bool
    noise_r: float
    noise_slope: float
    noise_angle: float
    quantile: float
    base: float
    floor: float
    cap: float
    gap_scale: float
    mean_scale: float
    config_gap0: float
    gap0: float
    cgap: float
    cmean: float


class GrowConfig(NamedTuple):
    min_pts: int
    rms_a: float
    rms_b: float
    max_a: float
    max_b: float
    straight_min: float
    rms_relax: float
    max_relax: float
    straight_relax: float


class BranchConfig(NamedTuple):
    min_pts: int
    frag_pts: int
    frag_len: float
    frag_straight: float
    straight_min: float
    rms_a: float
    rms_b: float
    merge_gap: float
    lookback: int
    perp_base: float
    perp_cr: float
    perp_floor: float
    perp_cap: float
    perp_scale: float


class Geometry(NamedTuple):
    p1: np.ndarray
    p2: np.ndarray
    length: float
    rms: float
    max_res: float
    straight: float
    count: int
    start: int
    end: int


class PrecleanConfig(NamedTuple):
    passes: int
    window: int
    run_gap_scale: float
    isolated_gap_scale: float
    gap_scale: float
    residual_abs: float
    residual_scale: float
    radial_abs: float
    radial_scale: float
    small_max_pts: int
    small_max_len: float
    small_straight: float


class DenseConfig(NamedTuple):
    min_pts: int
    max_pts: int
    min_len: float
    max_len: float
    min_vertical: float
    rms: float
    max_res: float
    straight: float


if AVAILABLE:
    @njit(cache=False)
    def median(values):
        return np.median(values)

    @njit(cache=False)
    def branch_support(points, seed_start, seed_end, search_start, search_end,
                       origin, direction, attach_point, perp_thr, proj_gap, back_tol):
        """Original 16-step projection growth, without intermediate masks."""
        window = points[search_start:search_end + 1]
        normal = np.array([-direction[1], direction[0]])
        proj = (window - origin) @ direction
        perp = np.abs((window - origin) @ normal)
        seed_proj = (points[seed_start:seed_end + 1] - origin) @ direction
        seed_lo, seed_hi = np.min(seed_proj), np.max(seed_proj)
        attach_proj = (attach_point - origin) @ direction
        low = abs(attach_proj - seed_lo) <= abs(attach_proj - seed_hi)
        lo, hi = seed_lo, seed_hi
        for _ in range(16):
            found = False
            edge = -np.inf if low else np.inf
            for i in range(len(window)):
                if perp[i] > perp_thr:
                    continue
                if low and seed_lo - back_tol <= proj[i] <= hi + proj_gap:
                    edge = max(edge, proj[i])
                    found = True
                elif not low and lo - proj_gap <= proj[i] <= seed_hi + back_tol:
                    edge = min(edge, proj[i])
                    found = True
            if not found:
                break
            if low:
                if edge <= hi + 1e-6:
                    break
                hi = edge
            else:
                if edge >= lo - 1e-6:
                    break
                lo = edge
        selected = np.empty(len(window), dtype=np.int64)
        count = 0
        for i in range(len(window)):
            inside = (seed_lo - back_tol <= proj[i] <= hi + 1e-9) if low else (lo - 1e-9 <= proj[i] <= seed_hi + back_tol)
            if perp[i] <= perp_thr and inside:
                selected[count] = search_start + i
                count += 1
        return selected[:count]

    @njit(cache=False)
    def tls_lapack(points, weights):
        """Reference path for nearly isotropic or non-finite covariance."""
        denom = max(np.sum(weights), EPS)
        mu = np.sum(points * weights[:, None], axis=0) / denom
        q = points - mu
        cov = (q * weights[:, None]).T @ q / denom
        eigvals, eigvecs = np.linalg.eigh(cov)
        direction = eigvecs[:, np.argmax(eigvals)].copy()
        direction /= np.sqrt(np.sum(direction * direction)) + EPS
        if direction[0] < 0.0 or (abs(direction[0]) < EPS and direction[1] < 0.0):
            direction = -direction
        normal = np.array([-direction[1], direction[0]])
        return mu, direction, q @ normal, eigvals

    @njit(cache=False)
    def tls(points, weights):
        """Two-pass 2-D TLS without temporary matrices or a LAPACK call.

        Center before accumulating covariance (no raw-moment subtraction).
        The analytic symmetric 2x2 eigensystem is algebraically identical to
        eigh; retain LAPACK where its repeated-eigenvalue convention matters.
        No fast-math or approximate convergence is used.
        """
        total, sx, sy = 0.0, 0.0, 0.0
        for i in range(len(points)):
            w = weights[i]
            total += w
            sx += points[i, 0] * w
            sy += points[i, 1] * w
        denom = max(total, EPS)
        mx, my = sx / denom, sy / denom
        xx, xy, yy = 0.0, 0.0, 0.0
        for i in range(len(points)):
            x, y = points[i, 0] - mx, points[i, 1] - my
            xx += (x * weights[i]) * x
            xy += (y * weights[i]) * x  # eigh reads the lower triangle.
            yy += (y * weights[i]) * y
        xx, xy, yy = xx / denom, xy / denom, yy / denom
        gap = math.hypot(xx - yy, 2.0 * xy)
        if not math.isfinite(gap) or gap <= 1e-6 * max(abs(xx), abs(yy), 1e-300):
            return tls_lapack(points, weights)
        # Choose the longer of the equivalent eigenvectors to avoid
        # cancellation when the principal axis is nearly horizontal/vertical.
        if xx >= yy:
            dx, dy = xx - yy + gap, 2.0 * xy
        else:
            dx, dy = 2.0 * xy, yy - xx + gap
        length = math.hypot(dx, dy)
        dx, dy = dx / length, dy / length
        length = math.sqrt(dx * dx + dy * dy) + EPS
        dx, dy = dx / length, dy / length
        if dx < 0.0 or (abs(dx) < EPS and dy < 0.0):
            dx, dy = -dx, -dy
        residual = np.empty(len(points))
        for i in range(len(points)):
            residual[i] = (points[i, 0] - mx) * -dy + (points[i, 1] - my) * dx
        eigvals = np.array([(xx + yy - gap) * 0.5, (xx + yy + gap) * 0.5])
        return np.array([mx, my]), np.array([dx, dy]), residual, eigvals

    @njit(cache=False)
    def fit(points, angle, iters, noise_r, noise_slope, noise_angle,
            min_scale, min_delta, sigma_gain):
        n = len(points)
        weights = np.ones(n)
        mu, direction, residual, eigvals = tls(points, weights)
        if n < 3:
            rr = 0.5
            radial_mad = 0.0
            residual_mad = 0.0
        else:
            ranges = np.sqrt(np.sum(points * points, axis=1))
            rr = max(np.median(ranges), 0.05)
            steps = np.abs(np.diff(ranges))
            radial_mad = 1.4826 * np.median(np.abs(steps - np.median(steps)))
            residual_mad = 1.4826 * np.median(np.abs(residual - np.median(residual)))
        sr = max(noise_r, 1e-7) + max(noise_slope, 0.0) * rr
        sa = max(noise_angle, 0.0)
        sigma = math.hypot(sr, rr * sa)
        if n >= 3:
            sigma = max(sigma, radial_mad / math.sqrt(2.0), residual_mad, min_scale)
        for _ in range(max(1, iters)):
            sigma_res = 1.4826 * np.median(np.abs(residual - np.median(residual)))
            delta = max(min_delta, sigma_gain * max(sigma, sigma_res, min_scale))
            changed = False
            for i in range(n):
                ar = abs(residual[i])
                weight = 1.0 if ar <= delta else delta / (ar + EPS)
                if weight != weights[i]:
                    changed = True
                weights[i] = weight
            if not changed:
                break
            mu, direction, residual, eigvals = tls(points, weights)
        rms = math.sqrt(np.mean(residual ** 2))
        max_res = np.max(np.abs(residual))
        lam1, lam2 = max(eigvals[1], 0.0), max(eigvals[0], 0.0)
        return mu, direction, rms, max_res, 1.0 - lam2 / (lam1 + lam2 + EPS)

    @njit(cache=False)
    def gap_threshold(r, angle, cfg, mean=False):
        rr, da = max(r, 0.05), max(angle, 1e-9)
        if not cfg.enabled:
            if mean:
                return max(cfg.gap0 + cfg.cmean * rr * angle, cfg.gap0 * 2.4)
            return max(cfg.gap0 + cfg.cgap * rr * angle, cfg.gap0 * 3.0)
        sr = max(cfg.noise_r, 1e-7) + max(cfg.noise_slope, 0.0) * rr
        sa = max(cfg.noise_angle, 0.0)
        sigma = math.hypot(sr, rr * sa)
        scale = cfg.mean_scale if mean else cfg.gap_scale
        value = cfg.base + scale * (2.0 * rr * math.sin(0.5 * da) + cfg.quantile * math.sqrt(2.0) * sigma)
        floor = max(cfg.floor, 0.5 * cfg.config_gap0)
        return min(max(value, floor), max(cfg.cap, floor))

    @njit(cache=False)
    def configured_fit(points, fc):
        return fit(points, fc.angle, fc.iters, fc.noise_r, fc.noise_slope,
                   fc.noise_angle, fc.min_scale, fc.min_delta, fc.sigma_gain)

    @njit(cache=False)
    def interval_fit(points, start, end, fc, cache):
        """Bounded, run-local exact memoization of overlapping support windows.

        The caller owns one immutable point array and one FitConfig for the
        cache lifetime. Both indices are checked, so hash collisions only
        evict old entries. No fitting results survive an extraction request.
        """
        slot = 0
        if cache is not None:
            slot = (start * 131 + end) % len(cache)
            row = cache[slot]
            if row[9] == 1.0 and row[0] == start and row[1] == end:
                return (np.array([row[2], row[3]]), np.array([row[4], row[5]]),
                        row[6], row[7], row[8])
        mu, direction, rms, max_res, straight = configured_fit(points[start:end + 1], fc)
        if cache is not None:
            row = cache[slot]
            row[0], row[1] = start, end
            row[2], row[3] = mu[0], mu[1]
            row[4], row[5] = direction[0], direction[1]
            row[6], row[7], row[8], row[9] = rms, max_res, straight, 1.0
        return mu, direction, rms, max_res, straight

    @njit(cache=False)
    def prune_small_runs(points, angle, gc, pc):
        if len(points) <= 2:
            return points
        keep = np.ones(len(points), dtype=np.bool_)
        start = 0
        for end in range(len(points)):
            if end + 1 < len(points):
                rr = 0.5 * (np.linalg.norm(points[end]) + np.linalg.norm(points[end + 1]))
                gap = np.linalg.norm(points[end + 1] - points[end])
                if gap <= gap_threshold(rr, angle, gc) * pc.run_gap_scale:
                    continue
            count = end - start + 1
            if count <= pc.small_max_pts:
                support = points[start:end + 1]
                _, _, _, eigenvalues = tls(support, np.ones(count))
                lam1, lam2 = max(eigenvalues[1], 0.0), max(eigenvalues[0], 0.0)
                straight = 1.0 - lam2 / (lam1 + lam2 + EPS)
                length = np.linalg.norm(points[end] - points[start])
                if length <= pc.small_max_len or straight <= pc.small_straight:
                    keep[start:end + 1] = False
            start = end + 1
        pruned = points[keep]
        return pruned if len(pruned) >= 2 else points

    @njit(cache=False)
    def preprocess(points, angle, gc, pc):
        """Unchanged local-MAD rejection, compiled as one per-frame operation."""
        filtered = points.copy()
        for _ in range(max(1, pc.passes)):
            if len(filtered) < max(7, 2 * pc.window + 3):
                break
            ranges = np.sqrt(np.sum(filtered * filtered, axis=1))
            distances = np.empty(len(filtered) - 1)
            for j in range(len(distances)):
                distances[j] = np.linalg.norm(filtered[j + 1] - filtered[j])
            keep = np.ones(len(filtered), dtype=np.bool_)
            for i in range(1, len(filtered) - 1):
                left = max(0, i - pc.window)
                right = min(len(filtered), i + pc.window + 1)
                d_prev, d_next = distances[i - 1], distances[i]
                run_gap = gap_threshold(max(ranges[i], 0.05), angle, gc) * pc.run_gap_scale
                if d_prev > run_gap:
                    left = i
                if d_next > run_gap:
                    right = i + 1
                while left < i and distances[left] > run_gap:
                    left += 1
                while right > i + 1 and distances[right - 2] > run_gap:
                    right -= 1
                if right - left < max(4, pc.window + 2):
                    continue
                size = right - left - 1
                if size < 3:
                    continue
                neighbors = np.empty((size, 2))
                local_ranges = np.empty(size)
                k = 0
                for j in range(left, right):
                    if j != i:
                        neighbors[k] = filtered[j]
                        local_ranges[k] = ranges[j]
                        k += 1
                mu, direction, _, _ = tls(neighbors, np.ones(size))
                residual = abs((filtered[i, 0] - mu[0]) * -direction[1]
                               + (filtered[i, 1] - mu[1]) * direction[0])
                r_med = np.median(local_ranges)
                gap = gap_threshold(r_med, angle, gc)
                mean_gap = gap_threshold(r_med, angle, gc, True)
                radial_sigma = 1.4826 * np.median(np.abs(local_ranges - r_med))
                radial_dev = abs(ranges[i] - r_med)
                isolated = d_prev > gap * pc.isolated_gap_scale and d_next > gap * pc.isolated_gap_scale
                bridge = d_prev > gap * pc.gap_scale or d_next > gap * pc.gap_scale
                deviated = residual > max(pc.residual_abs, mean_gap * pc.residual_scale)
                radial_bad = radial_dev > max(pc.radial_abs, (radial_sigma + gap) * pc.radial_scale)
                if isolated or (deviated and (bridge or radial_bad)):
                    keep[i] = False
            if np.all(keep):
                break
            candidate = filtered[keep]
            if len(candidate) < 2:
                break
            candidate = prune_small_runs(candidate, angle, gc, pc)
            if len(candidate) == len(filtered):
                break
            filtered = candidate
        return filtered if len(filtered) >= 2 else points

    @njit(cache=False)
    def dense_window_mask(points, fc, dc):
        """Conservative screening with original length, TLS and Huber gates.

        Survivors still take the existing scalar acceptance and deduplication
        path. Bounding boxes grow incrementally; no sliding-window tensor or
        batch temporary is materialized. The same roundoff guards are retained.
        """
        maximum = min(dc.max_pts, len(points))
        viable = np.zeros((len(points), max(0, maximum - dc.min_pts + 1)), dtype=np.bool_)
        for start in range(len(points) - dc.min_pts + 1):
            lo_x, hi_x = np.inf, -np.inf
            lo_y, hi_y = np.inf, -np.inf
            for width in range(1, min(maximum, len(points) - start) + 1):
                x, y = points[start + width - 1]
                lo_x, hi_x = min(lo_x, x), max(hi_x, x)
                lo_y, hi_y = min(lo_y, y), max(hi_y, y)
                if width < dc.min_pts:
                    continue
                bound = math.hypot(hi_x - lo_x, hi_y - lo_y)
                guard = 1e-10 * max(1.0, abs(lo_x), abs(hi_x), abs(lo_y), abs(hi_y), bound)
                if bound + guard < dc.min_len:
                    continue
                support = points[start:start + width]
                _, _, residual, _ = tls(support, np.ones(width))
                if math.sqrt(np.mean(residual ** 2)) > dc.rms + guard:
                    continue
                mu, direction, rms, max_res, straight = configured_fit(support, fc)
                projection = (support - mu) @ direction
                p1 = mu + np.min(projection) * direction
                p2 = mu + np.max(projection) * direction
                length = np.linalg.norm(p2 - p1)
                vertical = abs((p2[1] - p1[1]) / (length + EPS))
                keep = (length + guard >= dc.min_len and length - guard <= dc.max_len
                        and vertical + 1e-9 >= dc.min_vertical and rms <= dc.rms + guard
                        and max_res <= dc.max_res + guard and straight + 1e-9 >= dc.straight)
                keep = keep or abs(straight - 0.5) < 1e-7 or length <= 100.0 * guard
                viable[start, width - dc.min_pts] = keep
        return viable

    @njit(cache=False)
    def geometry(points, start, end, fc):
        return fitted_geometry(points, start, end, configured_fit(points, fc))

    @njit(cache=False)
    def fitted_geometry(points, start, end, fitted):
        mu, direction, rms, max_res, straight = fitted
        projection = (points - mu) @ direction
        p1, p2 = mu + np.min(projection) * direction, mu + np.max(projection) * direction
        return Geometry(p1, p2, np.linalg.norm(p2 - p1), rms, max_res, straight, len(points), start, end)

    @njit(cache=False)
    def interval_geometry(points, indices, start, end, fc, cache):
        fitted = interval_fit(points, start, end, fc, cache)
        return fitted_geometry(points[start:end + 1], indices[start], indices[end], fitted)

    @njit(cache=False)
    def segment_direction(segment):
        v = segment.p2 - segment.p1
        return v / (np.linalg.norm(v) + EPS)

    @njit(cache=False)
    def angle_between(a, b):
        return np.degrees(np.arccos(min(max(abs(a @ b), -1.0), 1.0)))

    @njit(cache=False)
    def range_median(points):
        return np.median(np.sqrt(np.sum(points * points, axis=1)))

    @njit(cache=False)
    def extend_branch(points, indices, seed_start, seed_end, search_start,
                      search_end, seed, attach, parent_dir, fc, gc, bc):
        if search_start > search_end or search_end - search_start + 1 < seed.count:
            return seed
        median_range = range_median(points[seed_start:seed_end + 1])
        if gc.enabled:
            rr = max(median_range, 0.05)
            sr = max(fc.noise_r, 1e-7) + max(fc.noise_slope, 0.0) * rr
            sa = max(fc.noise_angle, 0.0)
            sigma = math.hypot(sr, rr * sa)
            floor = max(bc.perp_floor, 0.5 * bc.perp_base)
            perp = min(max(bc.perp_scale * gc.quantile * sigma, floor), max(bc.perp_cap, floor))
        else:
            perp = bc.perp_base + bc.perp_cr * max(median_range, 0.05)
        selected = branch_support(points, seed_start, seed_end, search_start, search_end,
                                  seed.p1, segment_direction(seed), attach, max(perp * 2.5, 0.07),
                                  max(bc.merge_gap * 2.1, 0.15), max(bc.merge_gap, 0.06))
        if len(selected) <= seed.count:
            return seed
        selected_points, selected_indices = points[selected], indices[selected]
        extended = geometry(selected_points, np.min(selected_indices), np.max(selected_indices), fc)
        angle = angle_between(segment_direction(extended), parent_dir)
        attach_dist = min(np.linalg.norm(extended.p1 - attach), np.linalg.norm(extended.p2 - attach))
        if not (45.0 <= angle <= 135.0):
            return seed
        if extended.straight < max(0.90, bc.frag_straight - 0.09):
            return seed
        if extended.rms > (bc.rms_a + bc.rms_b * range_median(selected_points)) * 2.4:
            return seed
        if attach_dist > max(bc.merge_gap * 2.2, 0.28) or extended.length <= seed.length + 0.01:
            return seed
        return extended

    @njit(cache=False)
    def endpoint_branches(points, indices, start, end, parent_dir, parent_p1, parent_p2, fc, bc, cache=None):
        result = []
        if end - start + 1 < max(bc.frag_pts + 1, 4):
            return result
        max_window = min(end - start + 1, max(bc.frag_pts + 10, bc.min_pts + 2))
        min_window = max(3, bc.frag_pts)
        for side in range(2):
            found = False
            best_score = (-np.inf, -np.inf, -np.inf, -np.inf)
            for win in range(min_window, max_window + 1):
                a, b = (start, start + win - 1) if side == 0 else (end - win + 1, end)
                attach = parent_p1 if side == 0 else parent_p2
                branch = interval_geometry(points, indices, a, b, fc, cache)
                angle = angle_between(parent_dir, segment_direction(branch))
                if not (45.0 <= angle <= 135.0):
                    continue
                if branch.length < bc.frag_len or branch.count < min_window:
                    continue
                if branch.straight < max(0.94, bc.frag_straight - 0.05):
                    continue
                if branch.rms > (bc.rms_a + bc.rms_b * range_median(points[a:b + 1])) * 1.9:
                    continue
                attach_dist = min(np.linalg.norm(branch.p1 - attach), np.linalg.norm(branch.p2 - attach))
                if attach_dist > max(bc.merge_gap * 1.6, 0.22):
                    continue
                score = (branch.length, -abs(angle - 90.0), branch.straight, -branch.rms)
                if not found or score > best_score:
                    best, best_score, found = branch, score, True
            if found:
                result.append(best)
        return result

    @njit(cache=False)
    def corner_branches(points, indices, start, end, parent_dir, fc, gc, bc, cache=None):
        result = []
        if end - start + 1 < max(bc.min_pts, 6):
            return result
        min_branch_pts = max(3, bc.frag_pts - 1)
        max_branch_pts = min(max(bc.frag_pts + 30, bc.min_pts + 12), end - start)
        for side in range(2):
            found = False
            best_score = (-np.inf, -np.inf, -np.inf)
            for count in range(min_branch_pts, max_branch_pts + 1):
                if side == 0:
                    a, b, t_start, t_end = start, start + count - 1, start + count - 1, end
                    attach = points[b]
                    search_start = max(0, start - max(bc.min_pts + 20, 52))
                    search_end = min(len(points) - 1, b + 5)
                else:
                    a, b, t_start, t_end = end - count + 1, end, start, end - count + 1
                    attach = points[a]
                    search_start = max(0, a - 8)
                    search_end = min(len(points) - 1, end + max(bc.min_pts + 30, 68))
                if t_end - t_start + 1 < max(bc.min_pts // 2, 4):
                    continue
                seed = interval_geometry(points, indices, a, b, fc, cache)
                seed_dir = segment_direction(seed)
                if side == 0 and abs(parent_dir[1]) >= 0.9 and abs(seed_dir[0]) >= 0.94:
                    search_start = max(0, search_start - bc.lookback)
                    search_end = min(len(points) - 1, search_end + 1)
                branch = extend_branch(points, indices, a, b, search_start, search_end,
                                       seed, attach, parent_dir, fc, gc, bc)
                trunk = interval_geometry(points, indices, t_start, t_end, fc, cache)
                angle = angle_between(segment_direction(branch), segment_direction(trunk))
                if not (45.0 <= angle <= 135.0):
                    continue
                if branch.length < max(bc.frag_len, 0.04) or branch.count < min_branch_pts:
                    continue
                if branch.straight < max(0.93, bc.frag_straight - 0.06):
                    continue
                if trunk.straight < max(bc.straight_min - 0.07, 0.90):
                    continue
                attach_dist = min(np.linalg.norm(branch.p1 - attach), np.linalg.norm(branch.p2 - attach))
                if attach_dist > 0.22:
                    continue
                score = (branch.length, -abs(angle - 90.0), branch.straight - branch.rms)
                if not found or score > best_score:
                    best, best_score, found = branch, score, True
            if found:
                result.append(best)
        return result

    @njit(cache=False)
    def grow_window(points, ranges, start, angle, fc, gc, qc, cache=None):
        end = start
        while end + 1 < len(points):
            r = 0.5 * (ranges[end] + ranges[end + 1])
            gap = np.linalg.norm(points[end + 1] - points[end])
            if gap > gap_threshold(r, angle, gc):
                break
            end += 1
            if end - start + 1 >= qc.min_pts:
                _, _, rms, max_res, straight = interval_fit(points, start, end, fc, cache)
                med_r = np.median(ranges[start:end + 1])
                if (rms > (qc.rms_a + qc.rms_b * med_r) * max(1.0, qc.rms_relax)
                        or max_res > (qc.max_a + qc.max_b * med_r) * max(1.0, qc.max_relax)
                        or straight < qc.straight_min - min(max(qc.straight_relax, 0.0), 0.20)):
                    end -= 1
                    break
        return end

    @njit(cache=False)
    def extend_segment(points, start, end, angle, fc, gc, qc, cache=None):
        if start < 0 or end >= len(points) or start >= end:
            return start, end
        ranges = np.sqrt(np.sum(points * points, axis=1))
        distances = np.empty(max(0, len(points) - 1))
        for i in range(len(distances)):
            distances[i] = np.sqrt(np.sum((points[i + 1] - points[i]) ** 2))
        changed = True
        while changed:
            changed = False
            for side in range(2):
                best_start, best_end, best_count, best_quality = start, end, -1, -np.inf
                for step in range(1, 6):
                    a = start - step if side == 0 else start
                    b = end if side == 0 else end + step
                    if a < 0 or b >= len(points):
                        continue
                    # Keep the original right-side boundary convention.
                    other = a + 1 if side == 0 else b - 1
                    r = 0.5 * (np.linalg.norm(points[a]) + np.linalg.norm(points[other]))
                    gap = np.linalg.norm(points[a] - points[other])
                    if gap > gap_threshold(r, angle, gc) * 1.18 * max(1.0, step * 0.9):
                        continue
                    med_r = np.median(ranges[a:b + 1])
                    dif = distances[a:b]
                    if (np.mean(dif) > gap_threshold(med_r, angle, gc, True) * 1.18 * max(1.0, step * 0.9)
                            or np.max(dif) > gap_threshold(med_r, angle, gc) * 1.18 * max(1.0, step * 1.2)):
                        continue
                    _, _, rms, max_res, straight = interval_fit(points, a, b, fc, cache)
                    if (rms > (qc.rms_a + qc.rms_b * med_r) * (max(1.0, qc.rms_relax) * 1.15)
                            or max_res > (qc.max_a + qc.max_b * med_r) * (max(1.0, qc.max_relax) * 1.20) * max(1.0, step * 1.15)
                            or straight < qc.straight_min - min(max(qc.straight_relax, 0.0), 0.20) - 0.015):
                        continue
                    count, quality = b - a + 1, straight - rms
                    if count > best_count or (count == best_count and quality > best_quality):
                        best_start, best_end, best_count, best_quality = a, b, count, quality
                if best_count >= 0:
                    start, end = best_start, best_end
                    changed = True
        return start, end


def prepare():
    """Load/compile all used signatures once; return backend availability."""
    global _READY
    if not AVAILABLE:
        return False
    if not _READY:
        points = np.array([[0.0, 0.0], [0.1, 0.01], [0.2, 0.0]])
        fit(points, 0.01, 6, 0.003, 0.001, 0.0013248022, 0.002, 0.006, 1.75)
        median(points[:, 0].copy())
        branch_support(points, 0, 1, 0, 2, points[0], np.array([1.0, 0.0]), points[0], 0.1, 0.2, 0.1)
        fc = FitConfig(0.01, 6, 0.003, 0.001, 0.0013248022, 0.002, 0.006, 1.75)
        gc = GapConfig(True, 0.003, 0.001, 0.0013248022, 3.0, 0.003, 0.008, 0.8, 1.2, 0.92, 0.01, 0.01, 1.0, 1.0)
        qc = GrowConfig(3, 0.01, 0.01, 0.02, 0.01, 0.98, 1.1, 1.1, 0.01)
        grow_window(points, np.linalg.norm(points, axis=1), 0, 0.01, fc, gc, qc)
        extend_segment(points, 0, 1, 0.01, fc, gc, qc)
        bc = BranchConfig(8, 3, 0.04, 0.98, 0.98, 0.01, 0.01, 0.05, 10, 0.02, 0.01, 0.025, 0.3, 1.25)
        indices, direction = np.arange(len(points)), np.array([1.0, 0.0])
        endpoint_branches(points, indices, 0, 2, direction, points[0], points[-1], fc, bc)
        corner_branches(points, indices, 0, 2, direction, fc, gc, bc)
        interval_cache = np.zeros((4096, 10))
        grow_window(points, np.linalg.norm(points, axis=1), 0, 0.01, fc, gc, qc, interval_cache)
        extend_segment(points, 0, 1, 0.01, fc, gc, qc, interval_cache)
        endpoint_branches(points, indices, 0, 2, direction, points[0], points[-1], fc, bc, interval_cache)
        corner_branches(points, indices, 0, 2, direction, fc, gc, bc, interval_cache)
        pc = PrecleanConfig(2, 2, 1.45, 2.8, 1.55, 0.028, 1.85, 0.06, 2.4, 4, 0.06, 0.90)
        preprocess(points, 0.01, gc, pc)
        dc = DenseConfig(3, 18, 0.34, 0.8, 0.93, 0.012, 0.020, 0.995)
        dense_window_mask(points, fc, dc)
        _READY = True
    return True
''',
}


def _load_embedded_support(name):
    """Initialize the built-in helper code without reading any project files."""
    module_name = __name__ + "._embedded_" + name
    if module_name in sys.modules:
        return sys.modules[module_name]
    module = types.ModuleType(module_name)
    module.__file__ = __file__
    module.__package__ = ""
    sys.modules[module_name] = module
    try:
        exec(compile(_EMBEDDED_SUPPORT[name], __file__ + ":" + name, "exec"), module.__dict__)
    except BaseException:
        sys.modules.pop(module_name, None)
        raise
    return module


base = _load_embedded_support("feature_base")
_batch = _load_embedded_support("feature_tour_batch")
fit_windows, tls_batch = _batch.fit_windows, _batch.tls_batch
native = _load_embedded_support("feature_tour_native")



EPS = 1e-12

# Keep references to the original functions before monkey-patching the base
# module.  The base implementation uses module globals internally, so a small
# scoped patch lets all of its candidate-growth routines use the new models.
_ORIGINAL_GAP_THR = base.gap_thr_m
_ORIGINAL_MEAN_GAP_THR = base.mean_gap_thr_m
_ORIGINAL_MERGE_GAP_THR = base.merge_gap_thr_m
_ORIGINAL_MERGE_PERP_THR = base.merge_perp_thr_m
_ORIGINAL_FIT = base.fit_line_tls_huber
_ORIGINAL_TLS_CORE = base.fit_line_tls_core
_ORIGINAL_BUILD_SEGMENT = base.build_segment_from_points
_ORIGINAL_EXTRACT = base.extract_segments
_ORIGINAL_EXTEND_SEGMENT = base.extend_segment_in_run
_ORIGINAL_CANDIDATES_RUN = base.extract_candidates_from_run
_ORIGINAL_PREPROCESS = base.preprocess_points
_ORIGINAL_LOCAL_MERGE = base.try_merge_two_segments
_ORIGINAL_SEGMENT_ANGLE = base.segment_included_angle_deg
_ORIGINAL_MIDPOINT_DISTANCE = base.segment_midpoint_distance
_ORIGINAL_AXIS_DISTANCE = base.segment_support_axis_distance

_ACTIVE_ARGS: Optional[argparse.Namespace] = None
_ACTIVE_ANGLE_INCREMENT: Optional[float] = None
_LAST_DIAGNOSTICS: Dict[str, float] = {}
_FALLBACK_ARGS: Optional[argparse.Namespace] = None
_FIT_CACHE: Optional[dict] = None
_NOISE_CACHE: Optional[dict] = None
_SEGMENT_CACHE: Optional[dict] = None
_FIT_CACHE_LIMIT = 8192
_MEASUREMENT_POINTS = None
_MEASUREMENT_LOOKUP = None
_MEASUREMENT_SUPPORT = None


def _support_key(segment):
    return (segment.idx_start, segment.idx_end, segment.p1.tobytes(), segment.p2.tobytes())


def _record_support(segment, points):
    if _MEASUREMENT_SUPPORT is not None:
        indices = set()
        for point in points:
            indices.update(_MEASUREMENT_LOOKUP.get(tuple(point), ()))
        _MEASUREMENT_SUPPORT[_support_key(segment)] = tuple(sorted(indices))
    return segment


def _support_indices(segment):
    if _MEASUREMENT_SUPPORT is None:
        return ()
    found = _MEASUREMENT_SUPPORT.get(_support_key(segment))
    if found is not None:
        return found
    # Compiled corner branches expose an original contiguous measurement span.
    if 0 <= segment.idx_start <= segment.idx_end < len(_MEASUREMENT_POINTS):
        return tuple(range(segment.idx_start, segment.idx_end+1))
    return ()


def _supported_merge_geometry(a, b, args, angle_limit):
    """Do not let sparsity relax direction or turn an empty gap into evidence."""
    # These predicates operate on two 2-D vectors. Scalar arithmetic avoids
    # thousands of tiny NumPy allocations/reductions in the all-pairs search.
    ax, ay = float(a.p1[0]), float(a.p1[1])
    bx, by = float(a.p2[0]), float(a.p2[1])
    cx, cy = float(b.p1[0]), float(b.p1[1])
    dx, dy = float(b.p2[0]), float(b.p2[1])
    ux, uy, vx, vy = bx-ax, by-ay, dx-cx, dy-cy
    un, vn = math.hypot(ux, uy), math.hypot(vx, vy)
    if min(un, vn) < EPS:
        return False
    ux, uy, vx, vy = ux/un, uy/un, vx/vn, vy/vn
    if abs(ux*vx+uy*vy) < math.cos(math.radians(angle_limit)):
        return False
    perp = max(abs((cx-ax)*uy-(cy-ay)*ux), abs((dx-ax)*uy-(dy-ay)*ux),
               abs((ax-cx)*vy-(ay-cy)*vx), abs((bx-cx)*vy-(by-cy)*vx))
    radius = .25 * (math.hypot(ax+bx, ay+by) + math.hypot(cx+dx, cy+dy))
    scale = adaptive_merge_scale_from_segments(a, b, _active_angle(), None, args)
    band = uncertainty_merge_perp_thr_m(radius, args.merge_perp_base_m, args.merge_perp_cr)
    if perp > min(args.global_map_merge_perp_m, band * math.sqrt(scale)):
        return False
    ta = sorted((ax*ux+ay*uy, bx*ux+by*uy))
    tb = sorted((cx*ux+cy*uy, dx*ux+dy*uy))
    gap = max(0.0, max(ta[0], tb[0])-min(ta[1], tb[1]))
    limit = max(uncertainty_gap_thr_m(radius, _active_angle(), args.gap0_m, args.cgap),
                getattr(args, 'merge_gap_length_ratio', .75) * min(a.length, b.length))
    return gap <= limit


def _refit_parent_measurements(a, b, args):
    ids = sorted(set(_support_indices(a)) | set(_support_indices(b)))
    if not ids or not _support_indices(a) or not _support_indices(b):
        return None
    return base.build_segment_from_points(
        _MEASUREMENT_POINTS[ids], min(ids), max(ids), args.huber_delta, args.huber_iters, args=args)


def _try_local_merge(a, b, points, angle, args):
    if not _supported_merge_geometry(a, b, args, args.merge_angle_deg):
        return None
    proposal = _ORIGINAL_LOCAL_MERGE(a, b, points, angle, args)
    if proposal is None:
        return None
    refit = _refit_parent_measurements(a, b, args)
    if refit is not None:
        refit.is_feature, refit.is_fragment = proposal.is_feature, proposal.is_fragment
        refit.merged_from = proposal.merged_from
        proposal = refit
    return proposal


def _fit_line_tls_core(points, weights=None):
    """Same TLS arithmetic, avoiding all-one arrays and reduction dispatch."""
    if (not len(points) or points.dtype != np.float64
            or not points.flags.c_contiguous):
        return _ORIGINAL_TLS_CORE(points, weights)
    if weights is None:
        denom = float(len(points))
        mu = points.sum(axis=0) / denom
        q = points - mu
        cov = q.T @ q / denom
    else:
        denom = max(float(weights.sum()), EPS)
        mu = (points * weights[:, None]).sum(axis=0) / denom
        q = points - mu
        cov = (q * weights[:, None]).T @ q / denom
    eigvals, eigvecs = np.linalg.eigh(cov)
    direction = base.normalize(eigvecs[:, int(np.argmax(eigvals))])
    if direction[0] < 0.0 or (abs(direction[0]) < EPS and direction[1] < 0.0):
        direction = -direction
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    return mu, direction, q @ normal, eigvals


def _median_1d(values: np.ndarray) -> float:
    """Small 1-D median without NumPy's general axis-dispatch overhead."""
    values = np.asarray(values)
    if values.dtype != np.float64 or values.ndim != 1:
        return float(np.median(values))
    size = len(values)
    if not size:
        return float("nan")
    middle = size // 2
    kth = (middle, -1) if size % 2 else (middle - 1, middle, -1)
    ordered = np.partition(values, kth)
    if np.isnan(ordered[-1]):
        return float("nan")
    if size % 2:
        return float(ordered[middle])
    return float((ordered[middle - 1] + ordered[middle]) / 2.0)


@dataclass(frozen=True)
class FragmentEdge:
    """A candidate connection in the fragment graph."""

    i: int
    j: int
    cost: float
    angle_deg: float
    endpoint_gap_m: float
    axis_gap_m: float
    perp_sigma_m: float


def segment_mean_spacing_m(seg: base.Segment) -> float:
    """Average scan spacing along a segment support."""

    if seg.n_points <= 1:
        return float(max(seg.length, 0.0))
    return float(seg.length / max(seg.n_points - 1, 1))


def adaptive_merge_scale_from_segments(
    seg1: base.Segment,
    seg2: base.Segment,
    angle_increment: float,
    endpoint_gap_m: Optional[float] = None,
    args: Optional[argparse.Namespace] = None,
) -> float:
    """Widen merge thresholds when scan points are sparse."""

    cfg = _active_args(args)
    if not getattr(cfg, "adaptive_merge_enable", True):
        return 1.0

    da = _active_angle(angle_increment)
    r = 0.5 * (
        np.linalg.norm(base.segment_midpoint(seg1))
        + np.linalg.norm(base.segment_midpoint(seg2))
    )
    expected_step = max(2.0 * max(r, 0.05) * math.sin(0.5 * max(da, 1e-9)), 1e-6)
    spacing = 0.5 * (segment_mean_spacing_m(seg1) + segment_mean_spacing_m(seg2))
    sparsity = spacing / expected_step
    excess = max(0.0, sparsity - 1.0)

    gap_excess = 0.0
    if endpoint_gap_m is not None:
        gap_excess = max(0.0, float(endpoint_gap_m) / expected_step - 1.0)

    scale = 1.0
    scale += float(cfg.adaptive_merge_sparsity_gain) * (
        excess ** float(cfg.adaptive_merge_sparsity_power)
    )
    scale += 1.0 * float(cfg.adaptive_merge_sparsity_gain) * (gap_excess ** 1.0)
    return float(np.clip(scale, 1.0, float(cfg.adaptive_merge_scale_max)))


def _active_args(args: Optional[argparse.Namespace] = None) -> argparse.Namespace:
    global _FALLBACK_ARGS
    if args is not None:
        return args
    if _ACTIVE_ARGS is not None:
        return _ACTIVE_ARGS
    # The layout recovery pass also calls the patched functions outside the
    # per-frame extraction context. Construct its unchanged defaults only once
    # per request, rather than rebuilding a parser for every support window.
    if _FIT_CACHE is not None:
        if _FALLBACK_ARGS is None:
            _FALLBACK_ARGS = argparse.Namespace(**_default_argument_values())
        return _FALLBACK_ARGS
    return build_parser().parse_args([])


def _active_angle(angle_increment: Optional[float] = None) -> float:
    if angle_increment is not None and angle_increment > 0.0:
        return float(angle_increment)
    if _ACTIVE_ANGLE_INCREMENT is not None and _ACTIVE_ANGLE_INCREMENT > 0.0:
        return float(_ACTIVE_ANGLE_INCREMENT)
    return math.radians(0.5)


@lru_cache(maxsize=32)
def _normal_quantile(confidence: float) -> float:
    """Return a two-sided Gaussian quantile without requiring SciPy."""

    c = float(np.clip(confidence, 0.500001, 0.999999))
    # A two-sided confidence interval has tail probability (1-c)/2.
    return float(NormalDist().inv_cdf(0.5 + 0.5 * c))


def sensor_point_sigma_m(
    r: float,
    angle_increment: float,
    args: Optional[argparse.Namespace] = None,
) -> float:
    """Model one Cartesian point's uncertainty in metres.

    The radial component follows ``sigma_r0 + sigma_r_slope*r``. The angular
    component is the calibrated effective standard deviation, sigma_theta_eff.
    Thus sigma_p = sqrt(sigma_r**2 + (r*sigma_theta_eff)**2). The nominal beam
    increment is retained in this API for compatibility and is used separately
    for deterministic chord-length compensation, not as a random error.
    """

    cfg = _active_args(args)
    rr = max(float(r), 0.05)
    sigma_r = max(float(cfg.sensor_range_noise_m), 1e-7) + max(
        float(cfg.sensor_range_noise_slope), 0.0
    ) * rr
    angular_sigma = max(float(cfg.sensor_angle_noise_rad), 0.0)
    sigma_t = rr * angular_sigma
    return float(math.hypot(sigma_r, sigma_t))


def _uncertainty_gap_core(
    r: float,
    angle_increment: float,
    args: argparse.Namespace,
    scale: float,
) -> float:
    rr = max(float(r), 0.05)
    da = max(float(angle_increment), 1e-9)
    expected_step = 2.0 * rr * math.sin(0.5 * da)
    sigma = sensor_point_sigma_m(rr, da, args)
    # Difference of two independent point errors has sqrt(2) larger sigma.
    q = _normal_quantile(args.threshold_confidence)
    threshold = float(args.uncertainty_base_m) + scale * (
        expected_step + q * math.sqrt(2.0) * sigma
    )
    floor = max(float(args.uncertainty_floor_m), 0.5 * float(args.gap0_m))
    ceiling = max(float(args.uncertainty_cap_m), floor)
    return float(np.clip(threshold, floor, ceiling))


def uncertainty_gap_thr_m(
    r: float,
    angle_increment: float,
    gap0_m: float,
    cgap: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_GAP_THR(r, angle_increment, gap0_m, cgap)
    return _uncertainty_gap_core(r, angle_increment, cfg, cfg.uncertainty_gap_scale)


def uncertainty_mean_gap_thr_m(
    r: float,
    angle_increment: float,
    gap0_m: float,
    cmean: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_MEAN_GAP_THR(r, angle_increment, gap0_m, cmean)
    return _uncertainty_gap_core(r, angle_increment, cfg, cfg.uncertainty_mean_scale)


def uncertainty_merge_gap_thr_m(
    r: float,
    angle_increment: float,
    merge_gap0_m: float,
    merge_cgap: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_MERGE_GAP_THR(r, angle_increment, merge_gap0_m, merge_cgap)
    return _uncertainty_gap_core(r, angle_increment, cfg, cfg.uncertainty_merge_scale)


def uncertainty_merge_perp_thr_m(
    r: float,
    merge_perp_base_m: float,
    merge_perp_cr: float,
) -> float:
    cfg = _active_args()
    if not getattr(cfg, "uncertainty_enable", True):
        return _ORIGINAL_MERGE_PERP_THR(r, merge_perp_base_m, merge_perp_cr)
    sigma = sensor_point_sigma_m(r, _active_angle(), cfg)
    q = _normal_quantile(cfg.threshold_confidence)
    floor = max(float(cfg.uncertainty_perp_floor_m), 0.5 * float(merge_perp_base_m))
    ceiling = max(float(cfg.uncertainty_perp_cap_m), floor)
    return float(np.clip(cfg.uncertainty_perp_scale * q * sigma, floor, ceiling))


def estimate_local_noise_sigma_m(
    points: np.ndarray,
    angle_increment: Optional[float] = None,
    args: Optional[argparse.Namespace] = None,
) -> float:
    """Estimate local Cartesian noise from residual and radial-step MAD."""

    return _local_noise_and_tls(points, angle_increment, args)[0]


def _local_noise_and_tls(
    points: np.ndarray,
    angle_increment: Optional[float] = None,
    args: Optional[argparse.Namespace] = None,
):
    """Return the noise scale and reusable all-one-weight provisional TLS."""

    cfg = _active_args(args)
    if len(points) < 3:
        return sensor_point_sigma_m(0.5, _active_angle(angle_increment), cfg), None

    da = _active_angle(angle_increment)
    key = None
    if _NOISE_CACHE is not None:
        key = (points.dtype.str, points.shape, points.strides, points.tobytes())
        cached = _NOISE_CACHE.get(key)
        if cached is not None:
            r_med, radial_mad, residual_mad, provisional = cached
            sensor_sigma = sensor_point_sigma_m(r_med, da, cfg)
            scale = max(sensor_sigma, radial_mad / math.sqrt(2.0), residual_mad, cfg.huber_min_scale_m)
            return float(scale), tuple(item.copy() for item in provisional) if provisional is not None else None
    ranges = np.linalg.norm(points, axis=1)
    r_med = _median_1d(ranges)
    radial_steps = np.abs(np.diff(ranges))
    radial_mad = 1.4826 * _median_1d(np.abs(radial_steps - _median_1d(radial_steps)))
    sensor_sigma = sensor_point_sigma_m(r_med, da, cfg)

    # A provisional TLS fit gives a second, geometry-aware scale estimate.
    provisional = None
    try:
        provisional = base.fit_line_tls_core(points)
        residual = provisional[2]
        residual_mad = 1.4826 * _median_1d(np.abs(residual - _median_1d(residual)))
    except (ValueError, FloatingPointError):
        residual_mad = 0.0

    if key is not None:
        if len(_NOISE_CACHE) >= _FIT_CACHE_LIMIT:
            _NOISE_CACHE.clear()
        _NOISE_CACHE[key] = (r_med, radial_mad, residual_mad,
                             tuple(item.copy() for item in provisional) if provisional is not None else None)
    return float(max(sensor_sigma, radial_mad / math.sqrt(2.0), residual_mad, cfg.huber_min_scale_m)), provisional


def _copy_line_fit(fit: base.LineFit) -> base.LineFit:
    # Cached arrays must never be exposed to a caller that may mutate them.
    return base.LineFit(fit.mu.copy(), fit.direction.copy(), fit.rms, fit.max_res, fit.straightness)


def _fit_key(points, huber_delta, huber_iters, cfg):
    return (
        points.dtype.str, points.shape, points.strides, points.tobytes(),
        huber_delta, huber_iters, _active_angle(),
        getattr(cfg, "adaptive_huber_enable", True),
        getattr(cfg, "native_enable", False),
        *(getattr(cfg, name, None) for name in (
            "sensor_range_noise_m", "sensor_range_noise_slope", "sensor_angle_noise_rad",
            "huber_min_scale_m", "huber_min_delta_m", "huber_sigma_gain",
        )),
    )


def _copy_segment(segment):
    if type(segment) is base.Segment:
        copied = object.__new__(base.Segment)
        copied.__dict__ = segment.__dict__.copy()
        copied.p1 = segment.p1.copy()
        copied.p2 = segment.p2.copy()
        copied.merged_from = list(segment.merged_from)
        return copied
    return replace(segment, p1=segment.p1.copy(), p2=segment.p2.copy(),
                   merged_from=list(segment.merged_from))


def _base_median(values):
    if not len(values):
        return 0.0
    values = np.asarray(values, dtype=np.float64)
    if (values.ndim == 1 and values.flags.c_contiguous and values.flags.writeable
            and native._READY and native.AVAILABLE and getattr(_active_args(), "native_enable", False)):
        return float(native.median(values))
    return _median_1d(values)


def _base_mad(values):
    if not len(values):
        return 0.0
    values = np.asarray(values, dtype=np.float64)
    return _base_median(np.abs(values - _base_median(values)))


if native.AVAILABLE:
    @native.njit(cache=False)
    def _finite_small_coordinates(points):
        for value in points.flat:
            if not math.isfinite(value) or abs(value) >= 1e6:
                return False
        return True


def _native_eligible(points, cfg):
    return (getattr(cfg, "native_enable", False) and native.AVAILABLE
            and points.dtype == np.float64 and points.flags.c_contiguous
            and points.flags.writeable
            and len(points) > 0 and _finite_small_coordinates(points))


def _native_growth_configs(points, angle, args):
    cfg = _active_args()
    if (not _native_eligible(points, cfg) or not getattr(cfg, "adaptive_huber_enable", True)
            or args.huber_delta <= 0.0 or args.huber_iters <= 0):
        return None
    fc = native.FitConfig(_active_angle(), int(args.huber_iters), float(cfg.sensor_range_noise_m),
                          float(cfg.sensor_range_noise_slope), float(cfg.sensor_angle_noise_rad),
                          float(cfg.huber_min_scale_m), float(cfg.huber_min_delta_m), float(cfg.huber_sigma_gain))
    gc = native.GapConfig(bool(cfg.uncertainty_enable), float(cfg.sensor_range_noise_m),
                          float(cfg.sensor_range_noise_slope), float(cfg.sensor_angle_noise_rad),
                          _normal_quantile(cfg.threshold_confidence), float(cfg.uncertainty_base_m),
                          float(cfg.uncertainty_floor_m), float(cfg.uncertainty_cap_m),
                          float(cfg.uncertainty_gap_scale), float(cfg.uncertainty_mean_scale),
                          float(cfg.gap0_m), float(args.gap0_m), float(args.cgap), float(args.cmean))
    qc = native.GrowConfig(int(args.frag_min_pts if args.frag_enable else args.min_pts),
                           float(args.rms_a), float(args.rms_b), float(args.max_a), float(args.max_b),
                           float(args.straightness_min), float(args.grow_rms_relax),
                           float(args.grow_max_relax), float(args.grow_straightness_relax))
    return fc, gc, qc


def _extend_segment_in_run(points, start, end, angle, args):
    configs = _native_growth_configs(points, angle, args)
    if configs is None:
        return _ORIGINAL_EXTEND_SEGMENT(points, start, end, angle, args)
    return native.extend_segment(points, int(start), int(end), float(angle), *configs)


def _preprocess_points(points, angle, args):
    if not args.preclean_enable or len(points) < max(7, 2 * args.preclean_window + 3):
        return points
    configs = _native_growth_configs(points, angle, args)
    if configs is None or args.preclean_window < 1:
        return _ORIGINAL_PREPROCESS(points, angle, args)
    pc = native.PrecleanConfig(
        int(args.preclean_passes), int(args.preclean_window),
        float(args.preclean_run_gap_scale), float(args.preclean_isolated_gap_scale),
        float(args.preclean_gap_scale), float(args.preclean_residual_abs_m),
        float(args.preclean_residual_scale), float(args.preclean_radial_abs_m),
        float(args.preclean_radial_scale), int(args.preclean_small_run_max_pts),
        float(args.preclean_small_run_max_len_m), float(args.preclean_small_run_straightness),
    )
    return native.preprocess(points, float(angle), configs[1], pc)


def _extract_candidates_from_run(points, indices, angle, args):
    configs = _native_growth_configs(points, angle, args)
    if configs is None:
        return _ORIGINAL_CANDIDATES_RUN(points, indices, angle, args)
    # Candidate selection, branch searches and their lexicographic ordering
    # intentionally match feature.extract_candidates_from_run. Only the
    # numerical growth and branch-search loops cross into the compiled backend.
    ranges = np.linalg.norm(points, axis=1)
    cfg = _active_args()
    bc = native.BranchConfig(
        int(args.min_pts), int(args.frag_min_pts), float(args.frag_min_len_m),
        float(args.frag_straightness_min), float(args.straightness_min),
        float(args.rms_a), float(args.rms_b), float(args.merge_gap0_m),
        int(args.corner_branch_left_lookback_extra), float(args.merge_perp_base_m),
        float(args.merge_perp_cr), float(cfg.uncertainty_perp_floor_m),
        float(cfg.uncertainty_perp_cap_m), float(cfg.uncertainty_perp_scale),
    )
    grow_min_pts = args.frag_min_pts if args.frag_enable else args.min_pts
    # One bounded cache per immutable run/configuration; never reuse between
    # frames, callers or changed parameters. Collisions are checked in native.
    interval_cache = np.zeros((4096, 10), dtype=np.float64)
    candidates, start = [], 0
    while start < len(points) - 1:
        end = native.grow_window(points, ranges, start, float(angle), *configs, interval_cache)
        accepted = False
        if end - start + 1 >= grow_min_pts:
            ext_start, ext_end = native.extend_segment(points, start, end, float(angle), *configs, interval_cache)
            windows = [(ext_start, ext_end)]
            if (start, end) != (ext_start, ext_end):
                windows.append((start, end))
            best_seg, best_window, best_score = None, None, None
            for a, b in windows:
                segment = base.build_candidate_from_window(points, indices, ranges, a, b, angle, args)
                if segment is None:
                    continue
                score = (int(segment.is_feature), int(segment.is_fragment), segment.length,
                         segment.straightness, -segment.rms)
                if best_score is None or score > best_score:
                    best_seg, best_window, best_score = segment, (a, b), score
            if best_seg is not None:
                a, b = best_window
                candidates.append(best_seg)
                accepted = True
                direction = base.seg_dir(best_seg)
                branches = native.endpoint_branches(points, indices, a, b, direction, best_seg.p1, best_seg.p2, configs[0], bc, interval_cache)
                branches += native.corner_branches(points, indices, a, b, direction, configs[0], configs[1], bc, interval_cache)
                for branch in branches:
                    candidates.append(base.Segment(
                        idx_start=branch.start, idx_end=branch.end, p1=branch.p1, p2=branch.p2,
                        length=branch.length, rms=branch.rms, max_res=branch.max_res,
                        straightness=branch.straight, feature=float(branch.straight * np.exp(-branch.rms / 0.02)),
                        n_points=branch.count, is_fragment=True,
                    ))
        start = end + 1 if accepted else start + 1
    candidates.sort(key=lambda s: (s.idx_start, s.idx_end))
    return candidates


def _build_segment_geometry(points, idx_start, idx_end, huber_delta, huber_iters, args):
    cfg = _active_args()
    if not (native.AVAILABLE and native._READY and getattr(cfg, "native_enable", False)
            and points.dtype == np.float64 and points.flags.c_contiguous and points.flags.writeable):
        return _ORIGINAL_BUILD_SEGMENT(points, idx_start, idx_end, huber_delta, huber_iters, args)
    use_points, fit = base.robust_refine_segment_points(points, huber_delta, huber_iters, args)
    geo = native.fitted_geometry(use_points, idx_start, idx_end,
                                (fit.mu, fit.direction, fit.rms, fit.max_res, fit.straightness))
    return base.Segment(
        idx_start=idx_start, idx_end=idx_end, p1=geo.p1, p2=geo.p2,
        length=float(geo.length), rms=fit.rms, max_res=fit.max_res,
        straightness=fit.straightness,
        feature=float(fit.straightness * np.exp(-fit.rms / 0.02)), n_points=len(points),
    )


def _build_segment_from_points(seg_points, idx_start, idx_end, huber_delta, huber_iters, args=None):
    if _SEGMENT_CACHE is None:
        return _record_support(_build_segment_geometry(seg_points, idx_start, idx_end, huber_delta, huber_iters, args), seg_points)
    key = (_fit_key(seg_points, huber_delta, huber_iters, _active_args()), idx_start, idx_end)
    cached = _SEGMENT_CACHE.get(key)
    if cached is not None:
        return _record_support(_copy_segment(cached), seg_points)
    segment = _build_segment_geometry(seg_points, idx_start, idx_end, huber_delta, huber_iters, args)
    if len(_SEGMENT_CACHE) >= _FIT_CACHE_LIMIT:
        _SEGMENT_CACHE.clear()
    _SEGMENT_CACHE[key] = _copy_segment(segment)
    return _record_support(segment, seg_points)


if native.AVAILABLE:
    @native.njit(cache=False)
    def _noise_split_supports_native(points, angle, fc, gc, count, min_delta,
                                     perp_base, perp_cr, spacing_factor):
        parts = []
        radii = []
        bands = []
        for start in range(0, max(0, len(points)-count+1), max(1,count//2)):
            seed_ids=np.arange(start,start+count)
            seed=points[seed_ids]
            mu,direction,_,_,_=native.configured_fit(seed,fc)
            radius=np.median(np.sqrt(np.sum(seed*seed,axis=1)))
            if gc.enabled:
                rr=max(radius,0.05)
                sr=max(fc.noise_r,1e-7)+max(fc.noise_slope,0.0)*rr
                sa=max(fc.noise_angle,0.0)
                band=max(min_delta,gc.quantile*math.hypot(sr,rr*sa))
            else:
                band=perp_base+perp_cr*max(radius,0.05)
            valid=True
            near=np.ones(len(seed),dtype=np.bool_)
            for iteration in range(2):
                normal=np.array([-direction[1],direction[0]])
                near=np.abs((seed-mu)@normal)<=band
                if np.count_nonzero(near)<max(4,math.ceil(.6*count)):
                    valid=False
                    break
                mu,direction,_,_,_=native.configured_fit(seed[near],fc)
            if not valid:
                continue
            normal=np.array([-direction[1],direction[0]])
            ids=np.flatnonzero(np.abs((points-mu)@normal)<=band)
            projected=(points[ids]-mu)@direction
            ordered=ids[np.argsort(projected,kind='mergesort')]
            steps=np.diff((points[ordered]-mu)@direction)
            positive=steps[steps>1e-6]
            if not len(positive):
                continue
            gap_limit=max(native.gap_threshold(radius,angle,gc),spacing_factor*np.median(positive))
            seed_steps=np.diff((seed[near]-mu)@direction)
            forward=1.0 if np.median(seed_steps)>=0 else -1.0
            scan_steps=np.diff((points[ids]-mu)@direction)*forward
            scan_start=0
            for scan_end in range(1,len(ids)+1):
                if scan_end<len(ids) and scan_steps[scan_end-1]>=-gap_limit:
                    continue
                scan_run=ids[scan_start:scan_end]
                order=np.argsort((points[scan_run]-mu)@direction,kind='mergesort')
                ordered_run=scan_run[order]
                run_steps=np.diff((points[ordered_run]-mu)@direction)
                part_start=0
                for part_end in range(1,len(ordered_run)+1):
                    if part_end<len(ordered_run) and run_steps[part_end-1]<=gap_limit:
                        continue
                    part=ordered_run[part_start:part_end]
                    if len(part)>=count:
                        overlap=0
                        for index in part:
                            if start<=index<start+count:
                                overlap+=1
                        if overlap>=4:
                            parts.append(np.sort(part))
                            radii.append(radius)
                            bands.append(band)
                    part_start=part_end
                scan_start=scan_end
        return parts,radii,bands



def recover_noise_split_candidates(points, angle, args):
    """Compile support discovery; preserve final fitting, gates and ordering."""
    configs=_native_growth_configs(points,angle,args)
    active = _active_args()
    band_fields = ("uncertainty_enable", "sensor_range_noise_m", "sensor_range_noise_slope",
                   "sensor_angle_noise_rad", "threshold_confidence")
    if configs is None or any(getattr(args, key) != getattr(active, key) for key in band_fields):
        return _recover_noise_split_candidates_python(points,angle,args)
    count=max(6,args.min_pts)
    parts,radii,bands=_noise_split_supports_native(
        points,float(angle),configs[0],configs[1],int(count),float(args.huber_min_delta_m),
        float(args.merge_perp_base_m),float(args.merge_perp_cr),
        float(getattr(args,'candidate_gap_spacing_factor',2.0)))
    proposals={}
    for part,radius,band in zip(parts,radii,bands):
        segment=base.build_segment_from_points(
            points[part],int(part[0]),int(part[-1]),args.huber_delta,args.huber_iters,args=args)
        if (segment.length<args.frag_min_len_m or segment.rms>.6*band
                or segment.max_res>1.5*band):
            continue
        segment.is_feature=(segment.length>=args.min_len_m
                            or base.short_feature_candidate_ok(segment,radius,0.0,args))
        segment.is_fragment=not segment.is_feature
        proposals[tuple(part)]=segment
    kept=[]
    for indices,segment in sorted(proposals.items(),key=lambda item:(-len(item[0]),item[1].rms)):
        if any(len(set(indices)&set(old))/len(indices)>.8 for old,_ in kept):
            continue
        kept.append((indices,segment))
    _LAST_DIAGNOSTICS['noise_split_candidates']=float(len(kept))
    return [segment for _,segment in kept]


def _recover_noise_split_candidates_python(points, angle, args):
    """Recover measured line support lost by strict adjacent-return gap tests.

    Short ordered TLS-Huber seeds identify a perpendicular support band. Grow
    only connected projected support, splitting substantial empty intervals;
    later geometry checks decide whether separate pieces may be joined. No
    truth labels, scene coordinates, target counts or file access are used.
    """
    count = max(6, args.min_pts)
    proposals = {}
    for start in range(0, max(0, len(points)-count+1), max(1, count//2)):
        seed_ids = np.arange(start, start+count)
        seed = points[seed_ids]
        fit = fit_line_tls_huber_adaptive(seed, args.huber_delta, args.huber_iters)
        radius = float(np.median(np.linalg.norm(seed, axis=1)))
        if args.uncertainty_enable:
            band = max(args.huber_min_delta_m, _normal_quantile(args.threshold_confidence)
                       * sensor_point_sigma_m(radius, angle, args))
        else:
            band = _ORIGINAL_MERGE_PERP_THR(radius, args.merge_perp_base_m, args.merge_perp_cr)
        for _ in range(2):
            normal = np.array([-fit.direction[1], fit.direction[0]])
            near = np.abs((seed-fit.mu) @ normal) <= band
            if np.count_nonzero(near) < max(4, math.ceil(.6*count)):
                break
            fit = fit_line_tls_huber_adaptive(seed[near], args.huber_delta, args.huber_iters)
        else:
            normal = np.array([-fit.direction[1], fit.direction[0]])
            ids = np.flatnonzero(np.abs((points-fit.mu) @ normal) <= band)
            ordered = ids[np.argsort((points[ids]-fit.mu) @ fit.direction, kind="stable")]
            steps = np.diff((points[ordered]-fit.mu) @ fit.direction)
            positive = steps[steps > 1e-6]
            if not len(positive):
                continue
            gap_limit = max(uncertainty_gap_thr_m(radius, angle, args.gap0_m, args.cgap),
                            getattr(args, 'candidate_gap_spacing_factor', 2.0) * float(np.median(positive)))
            # A later point cluster can project into an earlier missing interval.
            # Preserve scan progression so such a return cannot fill a hole merely
            # because a global projection sort places it between two fragments.
            seed_steps = np.diff((seed[near]-fit.mu) @ fit.direction)
            forward = 1.0 if np.median(seed_steps) >= 0 else -1.0
            scan_steps = np.diff((points[ids]-fit.mu) @ fit.direction) * forward
            components = []
            for scan_run in np.split(ids, np.flatnonzero(scan_steps < -gap_limit)+1):
                ordered_run = scan_run[np.argsort((points[scan_run]-fit.mu) @ fit.direction, kind="stable")]
                run_steps = np.diff((points[ordered_run]-fit.mu) @ fit.direction)
                components.extend(np.split(ordered_run, np.flatnonzero(run_steps > gap_limit)+1))
            for part in components:
                if len(part) < count or len(np.intersect1d(part, seed_ids)) < 4:
                    continue
                part = np.sort(part)
                segment = base.build_segment_from_points(
                    points[part], int(part[0]), int(part[-1]), args.huber_delta, args.huber_iters, args=args)
                if (segment.length < args.frag_min_len_m or segment.rms > .6*band
                        or segment.max_res > 1.5*band):
                    continue
                segment.is_feature = (segment.length >= args.min_len_m
                                      or base.short_feature_candidate_ok(segment, radius, 0.0, args))
                segment.is_fragment = not segment.is_feature
                proposals[tuple(part)] = segment
    kept = []
    for indices, segment in sorted(proposals.items(), key=lambda item: (-len(item[0]), item[1].rms)):
        if any(len(set(indices) & set(old))/len(indices) > .8 for old, _ in kept):
            continue
        kept.append((indices, segment))
    _LAST_DIAGNOSTICS["noise_split_candidates"] = float(len(kept))
    return [segment for _, segment in kept]


def fit_line_tls_huber_adaptive(
    points: np.ndarray,
    huber_delta: float,
    huber_iters: int,
) -> base.LineFit:
    """TLS-Huber fit whose transition point follows local noise scale."""

    cfg = _active_args()
    if (
        not getattr(cfg, "adaptive_huber_enable", True)
        or huber_delta <= 0.0
        or huber_iters <= 0
        or len(points) < 2
    ):
        # These legacy paths also accept a minimal Namespace without any of
        # the adaptive sensor settings used in the cache key below.
        return _ORIGINAL_FIT(points, huber_delta, huber_iters)
    cache_key = None
    if _FIT_CACHE is not None:
        cache_key = _fit_key(points, huber_delta, huber_iters, cfg)
        cached = _FIT_CACHE.get(cache_key)
        if cached is not None:
            return _copy_line_fit(cached)
    result = _fit_line_tls_huber_adaptive_uncached(points, huber_delta, huber_iters, cfg)
    if cache_key is not None:
        if len(_FIT_CACHE) >= _FIT_CACHE_LIMIT:
            _FIT_CACHE.clear()
        _FIT_CACHE[cache_key] = _copy_line_fit(result)
    return result


def _fit_line_tls_huber_adaptive_uncached(
    points: np.ndarray,
    huber_delta: float,
    huber_iters: int,
    cfg: argparse.Namespace,
) -> base.LineFit:
    if (
        not getattr(cfg, "adaptive_huber_enable", True)
        or huber_delta <= 0.0
        or huber_iters <= 0
        or len(points) < 2
    ):
        return _ORIGINAL_FIT(points, huber_delta, huber_iters)

    if _native_eligible(points, cfg):
        result = native.fit(
            points, _active_angle(), int(huber_iters),
            float(cfg.sensor_range_noise_m), float(cfg.sensor_range_noise_slope),
            float(cfg.sensor_angle_noise_rad), float(cfg.huber_min_scale_m),
            float(cfg.huber_min_delta_m), float(cfg.huber_sigma_gain),
        )
        return base.LineFit(*result)

    weights = np.ones(len(points), dtype=np.float64)
    sigma_sensor, provisional = _local_noise_and_tls(points, _active_angle(), cfg)

    for iteration in range(max(1, int(huber_iters))):
        if iteration == 0 and provisional is not None:
            mu, direction, residual, eigvals = provisional
        else:
            mu, direction, residual, eigvals = base.fit_line_tls_core(points, weights=weights)
        med_res = _median_1d(residual)
        sigma_res = 1.4826 * _median_1d(np.abs(residual - med_res))
        local_sigma = max(sigma_sensor, sigma_res, float(cfg.huber_min_scale_m))
        delta_eff = max(
            float(cfg.huber_min_delta_m),
            float(cfg.huber_sigma_gain) * local_sigma,
        )
        abs_res = np.abs(residual)
        next_weights = np.where(abs_res <= delta_eff, 1.0, delta_eff / (abs_res + EPS))
        if np.array_equal(next_weights, weights):
            # Strict fixed point: every remaining iteration, including the
            # final TLS, would perform the identical arithmetic on these data.
            break
        weights = next_weights
    else:
        mu, direction, residual, eigvals = base.fit_line_tls_core(points, weights=weights)

    rms = float(np.sqrt(np.mean(residual**2)))
    max_res = float(np.max(np.abs(residual)))
    eigvals = np.sort(eigvals)[::-1]
    lam1 = float(max(eigvals[0], 0.0))
    lam2 = float(max(eigvals[1], 0.0))
    straightness = 1.0 - lam2 / (lam1 + lam2 + EPS)
    return base.LineFit(
        mu=mu,
        direction=direction,
        rms=rms,
        max_res=max_res,
        straightness=float(straightness),
    )


def _fragment_edge(
    a: base.Segment,
    b: base.Segment,
    points: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[FragmentEdge]:
    if b.idx_start < a.idx_start:
        a, b = b, a
    idx_gap = int(b.idx_start - a.idx_end)
    if idx_gap < 0 or idx_gap > int(args.graph_max_index_gap):
        return None

    angle_deg = base.segment_included_angle_deg(a, b)
    if angle_deg > float(args.graph_angle_deg):
        return None

    endpoint_gap = base.segment_endpoint_to_endpoint_distance(a, b)
    axis_gap = base.segment_support_axis_distance(a, b)
    r = 0.5 * (
        np.linalg.norm(base.segment_midpoint(a))
        + np.linalg.norm(base.segment_midpoint(b))
    )
    gap_thr = uncertainty_merge_gap_thr_m(r, angle_increment, args.merge_gap0_m, args.merge_cgap)
    merge_scale = adaptive_merge_scale_from_segments(a, b, angle_increment, endpoint_gap, args)
    gap_limit = max(float(args.graph_gap_scale), 1.0) * gap_thr * merge_scale
    sigma = sensor_point_sigma_m(r, angle_increment, args)
    q = _normal_quantile(args.threshold_confidence)
    perp_thr = (
        max(float(args.graph_perp_floor_m), float(args.graph_perp_sigma_scale) * q * sigma) * math.sqrt(merge_scale)
        + 0.75 * endpoint_gap
    )

    if endpoint_gap > gap_limit or axis_gap > perp_thr:
        return None

    angle_term = angle_deg / max(float(args.graph_angle_deg), 1e-6)
    gap_term = endpoint_gap / max(gap_limit, 1e-6)
    perp_term = axis_gap / max(perp_thr, 1e-6)
    index_term = idx_gap / max(float(args.graph_max_index_gap), 1.0)
    cost = (
        float(args.graph_weight_angle) * angle_term
        + float(args.graph_weight_gap) * gap_term
        + float(args.graph_weight_perp) * perp_term
        + float(args.graph_weight_index) * index_term
    )
    cost_limit = float(args.graph_edge_cost_max) * (1.0 + 0.25 * (merge_scale - 1.0))
    if cost > cost_limit:
        return None
    return FragmentEdge(
        i=-1,
        j=-1,
        cost=float(cost),
        angle_deg=float(angle_deg),
        endpoint_gap_m=float(endpoint_gap),
        axis_gap_m=float(axis_gap),
        perp_sigma_m=float(perp_thr),
    )


class _UnionFind:
    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> bool:
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1
        return True


def graph_recover_fragment_paths(
    points: np.ndarray,
    candidates: Sequence[base.Segment],
    features: Sequence[base.Segment],
    angle_increment: float,
    args: argparse.Namespace,
) -> List[base.Segment]:
    """Recover fragment chains with a degree-limited minimum-cost forest.

    Each candidate fragment is a graph node.  Edges encode angular, endpoint,
    perpendicular and scan-index consistency.  Kruskal selection with degree
    <= 2 produces path-like components, avoiding the arbitrary pair order of
    the original fragment-chain loop.
    """

    if not args.graph_recovery_enable:
        return list(features)

    fragments = [
        s
        for s in candidates
        if s.is_fragment and not s.is_feature and s.n_points >= args.frag_min_pts
    ]
    if len(fragments) < 2:
        _LAST_DIAGNOSTICS["graph_nodes"] = float(len(fragments))
        _LAST_DIAGNOSTICS["graph_edges"] = 0.0
        _LAST_DIAGNOSTICS["graph_components"] = 0.0
        _LAST_DIAGNOSTICS["graph_promoted"] = 0.0
        return list(features)

    edges: List[FragmentEdge] = []
    for i in range(len(fragments)):
        for j in range(i + 1, len(fragments)):
            if not _supported_merge_geometry(fragments[i], fragments[j], args, args.graph_angle_deg):
                continue
            raw = _fragment_edge(fragments[i], fragments[j], points, angle_increment, args)
            if raw is not None:
                edges.append(
                    FragmentEdge(
                        i=i,
                        j=j,
                        cost=raw.cost,
                        angle_deg=raw.angle_deg,
                        endpoint_gap_m=raw.endpoint_gap_m,
                        axis_gap_m=raw.axis_gap_m,
                        perp_sigma_m=raw.perp_sigma_m,
                    )
                )

    edges.sort(key=lambda e: e.cost)
    uf = _UnionFind(len(fragments))
    degree = [0] * len(fragments)
    selected: List[FragmentEdge] = []
    for edge in edges:
        if degree[edge.i] >= 2 or degree[edge.j] >= 2:
            continue
        if not uf.union(edge.i, edge.j):
            continue
        degree[edge.i] += 1
        degree[edge.j] += 1
        selected.append(edge)

    component_nodes: Dict[int, List[int]] = {}
    for idx in range(len(fragments)):
        root = uf.find(idx)
        component_nodes.setdefault(root, []).append(idx)

    recovered = list(features)
    promoted = 0
    for nodes in component_nodes.values():
        if len(nodes) < 2:
            continue
        ordered = sorted(nodes, key=lambda k: (fragments[k].idx_start, fragments[k].idx_end))
        idx_lo = min(fragments[k].idx_start for k in ordered)
        idx_hi = max(fragments[k].idx_end for k in ordered)
        if idx_lo < 0 or idx_hi >= len(points) or idx_hi <= idx_lo:
            continue

        ids = sorted({index for k in ordered for index in _support_indices(fragments[k])})
        support = points[ids] if ids else points[idx_lo : idx_hi + 1]
        if len(support) < int(args.graph_min_pts):
            continue
        dif = np.linalg.norm(np.diff(support, axis=0), axis=1)
        r_med = float(np.median(np.linalg.norm(support, axis=1)))
        gap_limit = uncertainty_gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
        support_scale = adaptive_merge_scale_from_segments(
            fragments[ordered[0]], fragments[ordered[-1]], angle_increment, None, args
        )
        if len(dif) and float(np.max(dif)) > float(args.graph_max_gap_scale) * gap_limit * support_scale:
            continue

        proposal = base.build_segment_from_points(
            support,
            idx_lo,
            idx_hi,
            args.huber_delta,
            args.huber_iters,
            args=args,
        )
        thr_rms = float(args.rms_a) + float(args.rms_b) * r_med
        thr_max = float(args.max_a) + float(args.max_b) * r_med
        quality_relax = max(float(args.graph_rms_relax), 1.0 + 0.5 * support_scale)
        local_sigma = estimate_local_noise_sigma_m(support, angle_increment, args)
        thr_rms = max(
            thr_rms * quality_relax,
            float(args.graph_rms_sigma_scale) * local_sigma,
        )
        thr_max = max(
            thr_max * max(float(args.graph_max_relax), quality_relax),
            1.25 * local_sigma,
        )
        old_length = max(fragments[k].length for k in ordered)
        if proposal.length < max(float(args.graph_min_len_m), old_length + float(args.graph_min_gain_m)):
            continue
        if proposal.rms > thr_rms:
            continue
        if proposal.max_res > thr_max:
            continue
        if proposal.straightness < float(args.graph_straightness_min):
            continue

        proposal.is_feature = True
        proposal.is_fragment = False
        proposal.merged_from = [
            (fragments[k].idx_start, fragments[k].idx_end) for k in ordered
        ]
        if base.segment_is_duplicate_like(proposal, recovered):
            continue
        recovered.append(proposal)
        promoted += 1

    _LAST_DIAGNOSTICS["graph_nodes"] = float(len(fragments))
    _LAST_DIAGNOSTICS["graph_edges"] = float(len(edges))
    _LAST_DIAGNOSTICS["graph_selected_edges"] = float(len(selected))
    _LAST_DIAGNOSTICS["graph_components"] = float(sum(len(v) >= 2 for v in component_nodes.values()))
    _LAST_DIAGNOSTICS["graph_promoted"] = float(promoted)
    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def adaptive_try_global_merge_two_segments(
    seg1: base.Segment,
    seg2: base.Segment,
    args: argparse.Namespace,
) -> Optional[Tuple[base.Segment, float, float]]:
    """Geometry-bounded merge refitted to unique original measurements."""

    if not _supported_merge_geometry(seg1, seg2, args, args.global_map_merge_angle_deg):
        return None

    a1 = seg1.p1.copy()
    b1 = seg1.p2.copy()
    a2 = seg2.p1.copy()
    b2 = seg2.p2.copy()

    d1 = base.normalize(b1 - a1)
    d2 = base.normalize(b2 - a2)

    dot = float(d1 @ d2)
    if dot < 0.0:
        d2 = -d2
        a2, b2 = b2, a2
        dot = -dot

    dot = float(np.clip(dot, -1.0, 1.0))
    angle_deg = float(np.degrees(np.arccos(dot)))
    if angle_deg > float(args.global_map_merge_angle_deg):
        return None
    endpoint_gap = base.segment_endpoint_to_endpoint_distance(seg1, seg2)
    merge_scale = adaptive_merge_scale_from_segments(seg1, seg2, _active_angle(), endpoint_gap, args)

    n1 = np.array([-d1[1], d1[0]], dtype=np.float64)
    perp_a2 = abs(float((a2 - a1) @ n1))
    perp_b2 = abs(float((b2 - a1) @ n1))
    perp_mid2 = abs(float((0.5 * (a2 + b2) - a1) @ n1))
    perp_err = max(perp_a2, perp_b2, perp_mid2)
    perp_limit = float(args.global_map_merge_perp_m)
    if perp_err > perp_limit:
        return None

    t1a = float(a1 @ d1)
    t1b = float(b1 @ d1)
    t2a = float(a2 @ d1)
    t2b = float(b2 @ d1)

    s1, e1 = min(t1a, t1b), max(t1a, t1b)
    s2, e2 = min(t2a, t2b), max(t2a, t2b)
    overlap = min(e1, e2) - max(s1, s2)
    gap_m = 0.0 if overlap >= -args.global_map_merge_overlap_tol_m else -overlap
    gap_limit = float(args.global_map_merge_endpoint_gap_m) * merge_scale
    if gap_m > gap_limit:
        return None

    merged = _refit_parent_measurements(seg1, seg2, args)
    if merged is None:
        # Layout-level callers can supply segments without a measurement scan.
        merge_pts = np.vstack([seg1.p1, seg1.p2, seg2.p1, seg2.p2])
        merged = base.build_segment_from_points(
            merge_pts, min(seg1.idx_start, seg2.idx_start), max(seg1.idx_end, seg2.idx_end),
            args.huber_delta, args.huber_iters, args=args)
        merged.n_points = max(merged.n_points, seg1.n_points + seg2.n_points)
    merged.feature = max(seg1.feature, seg2.feature)
    merged.is_feature = merged.length >= args.global_map_merge_min_len_m
    merged.is_fragment = not merged.is_feature
    if merged.length < args.global_map_merge_min_len_m:
        return None

    merged_from = list(seg1.merged_from) if seg1.merged_from else [(seg1.idx_start, seg1.idx_end)]
    merged_from.extend(seg2.merged_from if seg2.merged_from else [(seg2.idx_start, seg2.idx_end)])
    merged.merged_from = sorted(set(merged_from))
    return merged, gap_m, angle_deg


def adaptive_stitch_feature_chains(
    segments: List[base.Segment],
    args: argparse.Namespace,
) -> List[base.Segment]:
    """Aggressively connect collinear feature chains."""

    if not segments or not getattr(args, "global_map_merge_enable", True):
        return segments

    segs = list(segments)
    # Only pairs touching the newly merged segment can change. Keep all nodes
    # alive until this call ends so Python object IDs cannot be recycled. This
    # cache is request-local: changed scans/configurations are always refitted.
    nodes = list(segs)
    attempts = {}
    for _ in range(max(1, int(args.global_map_merge_max_passes))):
        changed = False
        while True:
            best_i = -1
            best_j = -1
            best_result: Optional[Tuple[base.Segment, float, float]] = None
            best_score: Optional[Tuple[float, float, float]] = None

            for i in range(len(segs)):
                for j in range(i + 1, len(segs)):
                    pair = (id(segs[i]), id(segs[j]))
                    if pair not in attempts:
                        attempts[pair] = adaptive_try_global_merge_two_segments(segs[i], segs[j], args)
                    attempt = attempts[pair]
                    if attempt is None:
                        continue
                    merged, gap_m, angle_deg = attempt
                    length_gain = merged.length - max(segs[i].length, segs[j].length)
                    score = (length_gain, -gap_m, -angle_deg)
                    if best_score is None or score > best_score:
                        best_i, best_j, best_result = i, j, attempt
                        best_score = score

            if best_result is None:
                break

            merged, _, _ = best_result
            if best_i > best_j:
                best_i, best_j = best_j, best_i
            segs.pop(best_j)
            segs.pop(best_i)
            segs.append(merged)
            nodes.append(merged)
            changed = True

        if not changed:
            break
        segs = base.sort_segments_by_mid_angle(base.deduplicate_segments(segs))

    return base.sort_segments_by_mid_angle(base.deduplicate_segments(segs))


def _dense_window_mask(points, args):
    """Batch-reject only windows safely outside the original quality gates.

    Survivors are fitted again by the scalar implementation before acceptance,
    retaining its exact endpoints and boundary decisions. Large coordinates,
    unusual dtypes and disabled adaptive Huber use the existing scalar path.
    """
    cfg = _active_args()
    if (not getattr(args, "batch_fit_enable", True)
            or not getattr(cfg, "adaptive_huber_enable", True)
            or args.huber_delta <= 0 or args.huber_iters <= 0
            or points.dtype != np.float64 or not np.isfinite(points).all()
            or float(np.max(np.abs(points))) > 1e6
            or args.dense_vertical_min_pts < 3):
        return None
    minimum = args.dense_vertical_min_pts
    maximum = min(args.dense_vertical_max_pts, len(points))
    configs = _native_growth_configs(points, _active_angle(), args)
    if configs is not None:
        dc = native.DenseConfig(int(minimum), int(maximum), float(args.dense_vertical_min_len_m),
                                float(args.dense_vertical_max_len_m), float(args.dense_vertical_abs_dir_y_min),
                                float(args.dense_vertical_rms_m), float(args.dense_vertical_max_res_m),
                                float(args.dense_vertical_straightness_min))
        return native.dense_window_mask(points, configs[0], dc)
    viable = np.zeros((len(points), max(0, maximum - minimum + 1)), dtype=bool)
    for width in range(minimum, maximum + 1):
        windows = np.lib.stride_tricks.sliding_window_view(points, (width, 2)).reshape(-1, width, 2)
        for start in range(0, len(windows), 256):
            group = windows[start:start + 256]
            span = group.max(axis=1) - group.min(axis=1)
            bounds = np.hypot(span[:, 0], span[:, 1])
            guard = 1e-10 * np.maximum(1.0, np.maximum(np.max(np.abs(group), axis=(1, 2)), bounds))
            selected = np.flatnonzero(bounds + guard >= args.dense_vertical_min_len_m)
            if not len(selected):
                continue
            residual = tls_batch(group[selected])[2]
            minimum_rms = np.sqrt(np.mean(residual ** 2, axis=1))
            selected = selected[minimum_rms <= args.dense_vertical_rms_m + guard[selected]]
            if not len(selected):
                continue
            support = group[selected]
            mu, direction, rms, max_res, straightness = fit_windows(
                support, cfg, _active_angle(), args.huber_iters, sensor_point_sigma_m,
            )
            projection = ((support - mu[:, None, :]) @ direction[..., None])[..., 0]
            p1 = mu + projection.min(axis=1)[:, None] * direction
            p2 = mu + projection.max(axis=1)[:, None] * direction
            lengths = np.linalg.norm(p2 - p1, axis=1)
            vertical = np.abs((p2 - p1)[:, 1] / (lengths + EPS))
            keep = ((lengths + guard[selected] >= args.dense_vertical_min_len_m)
                    & (lengths - guard[selected] <= args.dense_vertical_max_len_m)
                    & (vertical + 1e-9 >= args.dense_vertical_abs_dir_y_min)
                    & (rms <= args.dense_vertical_rms_m + guard[selected])
                    & (max_res <= args.dense_vertical_max_res_m + guard[selected])
                    & (straightness + 1e-9 >= args.dense_vertical_straightness_min))
            # Near repeated eigenvalues the principal direction is ill-defined;
            # leave those and sub-resolution supports to the scalar gates.
            keep |= ((np.abs(straightness - 0.5) < 1e-7)
                     | (lengths <= 100.0 * guard[selected]))
            viable[start + selected[keep], width - minimum] = True
    return viable


if native.AVAILABLE:
    @native.njit(cache=False)
    def _dense_geometries_native(points, fc, dc):
        """Retain the fitted geometry from conservative dense-window screening."""
        maximum = min(dc.max_pts, len(points))
        geometries = []
        for start in range(len(points) - dc.min_pts + 1):
            lo_x, hi_x = np.inf, -np.inf
            lo_y, hi_y = np.inf, -np.inf
            for width in range(1, min(maximum, len(points) - start) + 1):
                x, y = points[start + width - 1]
                lo_x, hi_x = min(lo_x, x), max(hi_x, x)
                lo_y, hi_y = min(lo_y, y), max(hi_y, y)
                if width < dc.min_pts:
                    continue
                bound = math.hypot(hi_x - lo_x, hi_y - lo_y)
                guard = 1e-10 * max(1.0, abs(lo_x), abs(hi_x), abs(lo_y), abs(hi_y), bound)
                if bound + guard < dc.min_len:
                    continue
                support = points[start:start + width]
                _, _, residual, _ = native.tls(support, np.ones(width))
                if math.sqrt(np.mean(residual ** 2)) > dc.rms + guard:
                    continue
                fitted = native.configured_fit(support, fc)
                geo = native.fitted_geometry(support, start, start + width - 1, fitted)
                vertical = abs((geo.p2[1] - geo.p1[1]) / (geo.length + EPS))
                keep = (geo.length + guard >= dc.min_len and geo.length - guard <= dc.max_len
                        and vertical + 1e-9 >= dc.min_vertical and geo.rms <= dc.rms + guard
                        and geo.max_res <= dc.max_res + guard and geo.straight + 1e-9 >= dc.straight)
                keep = keep or abs(geo.straight - 0.5) < 1e-7 or geo.length <= 100.0 * guard
                if keep:
                    geometries.append(geo)
        return geometries



def _recover_dense_vertical_runs(points, refs, args):
    """Reuse screened geometry without changing acceptance or duplicate checks."""
    if not args.dense_vertical_recover_enable or len(points) < args.dense_vertical_min_pts:
        return []
    configs = _native_growth_configs(points, _active_angle(), args)
    if (configs is None or not getattr(args, "batch_fit_enable", True)
            or args.dense_vertical_min_pts < 3):
        return _recover_dense_vertical_runs_python(points, refs, args)
    dc = native.DenseConfig(
        int(args.dense_vertical_min_pts), int(min(args.dense_vertical_max_pts, len(points))),
        float(args.dense_vertical_min_len_m), float(args.dense_vertical_max_len_m),
        float(args.dense_vertical_abs_dir_y_min), float(args.dense_vertical_rms_m),
        float(args.dense_vertical_max_res_m), float(args.dense_vertical_straightness_min),
    )
    proposals = []
    for geo in _dense_geometries_native(points, configs[0], dc):
        seg = base.Segment(
            idx_start=geo.start, idx_end=geo.end, p1=geo.p1, p2=geo.p2,
            length=float(geo.length), rms=float(geo.rms), max_res=float(geo.max_res),
            straightness=float(geo.straight),
            feature=float(geo.straight * np.exp(-geo.rms / 0.02)), n_points=geo.count,
        )
        _record_support(seg, points[geo.start:geo.end + 1])
        if seg.length < args.dense_vertical_min_len_m or seg.length > args.dense_vertical_max_len_m:
            continue
        if abs(base.seg_dir(seg)[1]) < args.dense_vertical_abs_dir_y_min:
            continue
        if seg.rms > args.dense_vertical_rms_m or seg.max_res > args.dense_vertical_max_res_m:
            continue
        if seg.straightness < args.dense_vertical_straightness_min:
            continue
        if base.segment_is_duplicate_like(seg, refs) or base.segment_is_duplicate_like(seg, proposals):
            continue
        seg.is_fragment = False
        seg.is_feature = True
        proposals.append(seg)
    proposals.sort(key=lambda s: (s.length, s.n_points, -s.rms), reverse=True)
    kept = []
    for seg in proposals:
        if base.segment_is_duplicate_like(seg, kept):
            continue
        kept.append(seg)
        if len(kept) >= args.dense_vertical_max_segments:
            break
    return kept


def _recover_dense_vertical_runs_python(
    points: np.ndarray,
    refs: Sequence[base.Segment],
    args: argparse.Namespace,
) -> List[base.Segment]:
    """Original recovery order with conservative impossible-length rejection.

    The distance between projected endpoints cannot exceed the support's
    bounding-box diagonal. Leave a coordinate-scaled rounding allowance so
    boundary cases still take the original fitting and acceptance path.
    """
    if not args.dense_vertical_recover_enable or len(points) < args.dense_vertical_min_pts:
        return []
    proposals: List[base.Segment] = []
    max_window = min(args.dense_vertical_max_pts, len(points))
    viable = _dense_window_mask(points, args)
    for start in range(len(points) - args.dense_vertical_min_pts + 1):
        for count in range(args.dense_vertical_min_pts, max_window + 1):
            end = start + count - 1
            if end >= len(points):
                break
            if viable is not None and not viable[start, count - args.dense_vertical_min_pts]:
                continue
            support = points[start:end + 1]
            if viable is None:
                lo, hi = np.min(support, axis=0), np.max(support, axis=0)
                bound = math.hypot(float(hi[0]) - float(lo[0]), float(hi[1]) - float(lo[1]))
                rounding = 32.0 * np.finfo(np.float64).eps * max(
                    1.0, float(np.max(np.abs(support))), bound,
                )
                if bound + rounding < args.dense_vertical_min_len_m:
                    continue
                _, _, residual, _ = base.fit_line_tls_core(support)
                minimum_rms = float(np.sqrt(np.mean(residual ** 2)))
                rms_guard = rounding + 1e-10 * max(1.0, bound)
                if minimum_rms > args.dense_vertical_rms_m + rms_guard:
                    continue
            seg = base.build_segment_from_points(
                support, start, end, args.huber_delta, args.huber_iters, args=args,
            )
            if seg.length < args.dense_vertical_min_len_m or seg.length > args.dense_vertical_max_len_m:
                continue
            if abs(base.seg_dir(seg)[1]) < args.dense_vertical_abs_dir_y_min:
                continue
            if seg.rms > args.dense_vertical_rms_m or seg.max_res > args.dense_vertical_max_res_m:
                continue
            if seg.straightness < args.dense_vertical_straightness_min:
                continue
            if base.segment_is_duplicate_like(seg, refs) or base.segment_is_duplicate_like(seg, proposals):
                continue
            seg.is_fragment = False
            seg.is_feature = True
            proposals.append(seg)
    proposals.sort(key=lambda s: (s.length, s.n_points, -s.rms), reverse=True)
    kept: List[base.Segment] = []
    for seg in proposals:
        if base.segment_is_duplicate_like(seg, kept):
            continue
        kept.append(seg)
        if len(kept) >= args.dense_vertical_max_segments:
            break
    return kept


def _extract_segments_core(
    points: np.ndarray,
    args: argparse.Namespace,
) -> Tuple[List[base.Segment], float]:
    global _ACTIVE_ARGS, _ACTIVE_ANGLE_INCREMENT
    global _MEASUREMENT_POINTS, _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT
    previous_args, previous_angle = _ACTIVE_ARGS, _ACTIVE_ANGLE_INCREMENT
    previous_measurements = (_MEASUREMENT_POINTS, _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT)
    _ACTIVE_ARGS = args
    angle_increment = float(args.angle_increment) if args.angle_increment is not None else base.estimate_angle_increment(points)
    _ACTIVE_ANGLE_INCREMENT = angle_increment
    try:
        points_for_extract = base.preprocess_points(points, angle_increment, args)
        _MEASUREMENT_POINTS = points_for_extract
        _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT = {}, {}
        for i, point in enumerate(points_for_extract):
            _MEASUREMENT_LOOKUP.setdefault(tuple(point), []).append(i)
        candidates = base.extract_all_candidates(points_for_extract, angle_increment, args)
        candidates += recover_noise_split_candidates(points_for_extract, angle_increment, args)

        if args.merge_enable:
            segments = base.merge_and_extend_candidates(
                points_for_extract, candidates, angle_increment, args
            )
        else:
            segments = [s for s in candidates if s.is_feature]

        # The graph optimizer replaces the original fragment-chain recovery.
        segments = graph_recover_fragment_paths(
            points_for_extract, candidates, segments, angle_increment, args
        )

        # Keep the original geometric global merge and deduplication as a final
        # conservative pass.  They now use uncertainty-driven thresholds due to
        # the scoped patch below.
        segments = base.attach_collinear_fragments_to_features(candidates, segments, args)
        segments = adaptive_stitch_feature_chains(segments, args)
        segments = base.sort_segments_by_mid_angle(segments)
        segments = base.deduplicate_segments(segments)
        segments = base.sort_segments_by_mid_angle(segments)
        segments = base.stitch_collinear_segments_global(segments, args)
        segments = base.sort_segments_by_mid_angle(base.deduplicate_segments(segments))
        segments = _finish_measured_segments(points, segments, angle_increment, args)
        return segments, angle_increment
    finally:
        _ACTIVE_ARGS = previous_args
        _ACTIVE_ANGLE_INCREMENT = previous_angle
        _MEASUREMENT_POINTS, _MEASUREMENT_LOOKUP, _MEASUREMENT_SUPPORT = previous_measurements


def _recover_measured_endpoints(points, segment, angle, args):
    """Extend a fitted segment only to connected, observed raw scan support.

    Precleaning can remove valid returns next to an occlusion/corner. Search a
    bounded scan-order neighbourhood and refit the measured inliers, retaining
    the adaptive Huber estimator. No synthetic intersections or truth endpoints
    are used. A disconnected collinear component cannot extend the segment.
    """
    if (len(points) < args.min_pts or segment.n_points < args.min_pts
            or segment.length < args.final_quality_min_len_m
            or segment.rms > args.final_quality_rms_m
            or segment.max_res > args.final_quality_max_res_m
            or segment.straightness < args.final_quality_straightness_min):
        return segment
    pad = max(args.min_pts + 14, 26)
    lo = max(0, segment.idx_start - pad)
    hi = min(len(points), segment.idx_end + pad + 1)
    if hi <= lo:
        return segment
    ids = np.arange(lo, hi)
    support = points[lo:hi]
    direction = base.seg_dir(segment)
    normal = np.array([-direction[1], direction[0]])
    center = .5 * (segment.p1 + segment.p2)
    projection = (support - center) @ direction
    residual = np.abs((support - center) @ normal)
    radius = float(np.median(np.linalg.norm(support, axis=1)))
    band = min(args.final_quality_max_res_m,
               max(args.huber_min_delta_m, _normal_quantile(args.threshold_confidence)
                   * sensor_point_sigma_m(radius, angle, args)))
    if not args.uncertainty_enable:
        band = min(args.final_quality_max_res_m,
                   max(args.huber_min_delta_m, 3.0 * segment.rms))
    margin = min(.5 * segment.length, args.global_map_merge_endpoint_gap_m * 2.5)
    half = .5 * segment.length
    selected = np.flatnonzero((residual <= band) & (projection >= -half-margin)
                             & (projection <= half+margin))
    if len(selected) < args.min_pts:
        return segment
    selected = selected[np.argsort(projection[selected], kind='stable')]
    steps = np.diff(projection[selected])
    positive = steps[steps > 1e-6]
    if not len(positive):
        return segment
    gap_limit = max(
        uncertainty_gap_thr_m(radius, angle, args.gap0_m, args.cgap) * args.graph_max_gap_scale,
        args.candidate_gap_spacing_factor * float(np.median(positive)),
    )
    components = np.split(selected, np.flatnonzero(steps > gap_limit) + 1)
    best, best_gain = segment, max(args.graph_min_gain_m, 1e-6)
    for component in components:
        if len(component) < args.min_pts:
            continue
        first, last = projection[component[0]], projection[component[-1]]
        overlap = max(0., min(last, half) - max(first, -half))
        if overlap < .9 * segment.length or last-first <= segment.length+best_gain:
            continue
        # One or two isolated aligned returns do not establish continuation.
        # Count evidence separately on each side; do not combine isolated
        # points from opposite ends into a fictitious supported extension.
        projected = projection[component]
        new_left = np.count_nonzero(projected < -half-band)
        new_right = np.count_nonzero(projected > half+band)
        minimum_new = getattr(args, 'endpoint_min_new_points', 3)
        if max(new_left, new_right) < minimum_new:
            continue
        if new_left < minimum_new:
            component = component[projection[component] >= -half-band]
        if new_right < minimum_new:
            component = component[projection[component] <= half+band]
        measured_ids = np.sort(ids[component])
        proposal = _ORIGINAL_BUILD_SEGMENT(
            points[measured_ids], int(measured_ids[0]), int(measured_ids[-1]),
            args.huber_delta, args.huber_iters, args=args,
        )
        gain = proposal.length - segment.length
        if (gain <= best_gain or proposal.rms > args.final_quality_rms_m
                or proposal.max_res > args.final_quality_max_res_m
                or proposal.straightness < args.final_quality_straightness_min
                or base.segment_included_angle_deg(proposal, segment) > args.global_map_merge_angle_deg):
            continue
        proposal.id = segment.id
        proposal.is_feature, proposal.is_fragment = segment.is_feature, segment.is_fragment
        proposal.merged_from = list(segment.merged_from)
        best, best_gain = proposal, gain
    return best


def _remove_contained_segments(segments, args):
    """Remove an overlapping short subsegment without deleting separate walls.

    Midpoint-distance deduplication misses a short segment lying near the end
    of a long one. Require shared scan support, orientation, perpendicular
    agreement and near-complete interval containment instead.
    """
    kept = []
    for small in sorted(segments, key=lambda s: (-s.length, -s.n_points, s.rms)):
        duplicate = False
        for large in kept:
            if (large.rms > args.final_quality_rms_m
                    or large.max_res > args.final_quality_max_res_m
                    or large.straightness < args.final_quality_straightness_min
                    or base.support_overlap_ratio(small, large) < .8
                    or base.segment_included_angle_deg(small, large) > args.global_map_merge_angle_deg):
                continue
            direction = base.seg_dir(large)
            normal = np.array([-direction[1], direction[0]])
            relative = np.array([small.p1-large.p1, small.p2-large.p1])
            tolerance = min(args.global_map_merge_perp_m,
                            max(args.huber_min_delta_m, 3. * max(small.rms, large.rms)))
            if float(np.max(np.abs(relative @ normal))) > tolerance:
                continue
            start, end = sorted(relative @ direction)
            covered = max(0., min(end, large.length)-max(start, 0.))
            if covered >= .98 * max(end-start, EPS):
                duplicate = True
                break
        if not duplicate:
            kept.append(small)
    return base.sort_segments_by_mid_angle(kept)


def _finish_measured_segments(points, segments, angle, args):
    if getattr(args, 'endpoint_recovery_enable', True):
        segments = [_recover_measured_endpoints(points, s, angle, args) for s in segments]
    if getattr(args, 'contained_dedup_enable', True):
        segments = _remove_contained_segments(segments, args)
    return segments


@lru_cache(maxsize=1)
def _default_argument_values():
    """Cache parser construction only; never cache scans or extraction results."""
    return vars(build_parser().parse_args([]))


def _direction_components(seg):
    dx, dy = float(seg.p2[0]-seg.p1[0]), float(seg.p2[1]-seg.p1[1])
    scale = math.sqrt(dx*dx+dy*dy) + EPS
    return dx/scale, dy/scale


def _segment_angle_scalar(a, b):
    ax, ay = _direction_components(a)
    bx, by = _direction_components(b)
    dot = min(1.0, max(-1.0, abs(ax*bx+ay*by)))
    return math.degrees(math.acos(dot))


def _segment_midpoint_distance_scalar(a, b):
    dx = .5*float(a.p1[0]+a.p2[0]-b.p1[0]-b.p2[0])
    dy = .5*float(a.p1[1]+a.p2[1]-b.p1[1]-b.p2[1])
    return math.sqrt(dx*dx+dy*dy)


def _segment_axis_distance_scalar(a, b):
    ux, uy = _direction_components(a)
    ox, oy = .5*float(a.p1[0]+a.p2[0]), .5*float(a.p1[1]+a.p2[1])
    ta = sorted(((float(a.p1[0])-ox)*ux+(float(a.p1[1])-oy)*uy,
                 (float(a.p2[0])-ox)*ux+(float(a.p2[1])-oy)*uy))
    tb = sorted(((float(b.p1[0])-ox)*ux+(float(b.p1[1])-oy)*uy,
                 (float(b.p2[0])-ox)*ux+(float(b.p2[1])-oy)*uy))
    return max(0.0, tb[0]-ta[1], ta[0]-tb[1])


def _segment_is_duplicate_scalar(candidate, refs):
    for ref in refs:
        angle = _segment_angle_scalar(candidate, ref)
        # Preserve the original predicates at floating-point threshold boundaries.
        if abs(angle-10.0) <= 1e-9:
            angle = _ORIGINAL_SEGMENT_ANGLE(candidate, ref)
        if angle >= 10.0:
            continue
        if base.support_overlap_ratio(candidate, ref) > .60:
            return True
        midpoint = _segment_midpoint_distance_scalar(candidate, ref)
        if abs(midpoint-.15) <= 1e-12:
            midpoint = _ORIGINAL_MIDPOINT_DISTANCE(candidate, ref)
        if midpoint < .15:
            axis = _segment_axis_distance_scalar(candidate, ref)
            if abs(axis-.05) <= 1e-12:
                axis = _ORIGINAL_AXIS_DISTANCE(candidate, ref)
            if axis <= .05:
                return True
    return False


@contextmanager
def _patched_base(cfg=None):
    global _FALLBACK_ARGS, _FIT_CACHE, _NOISE_CACHE, _SEGMENT_CACHE
    previous_fallback, previous_cache = _FALLBACK_ARGS, _FIT_CACHE
    previous_noise_cache = _NOISE_CACHE
    previous_segment_cache = _SEGMENT_CACHE
    _FALLBACK_ARGS, _FIT_CACHE = None, {}
    if cfg is not None:
        _FALLBACK_ARGS = argparse.Namespace(**_default_argument_values())
        _FALLBACK_ARGS.native_enable = getattr(cfg, "native_enable", False)
    _NOISE_CACHE = {}
    _SEGMENT_CACHE = {}
    names = {
        "gap_thr_m": uncertainty_gap_thr_m,
        "mean_gap_thr_m": uncertainty_mean_gap_thr_m,
        "merge_gap_thr_m": uncertainty_merge_gap_thr_m,
        "merge_perp_thr_m": uncertainty_merge_perp_thr_m,
        "fit_line_tls_huber": fit_line_tls_huber_adaptive,
        "fit_line_tls_core": _fit_line_tls_core,
        "build_segment_from_points": _build_segment_from_points,
        "median": _base_median,
        "mad": _base_mad,
        "preprocess_points": _preprocess_points,
        "extend_segment_in_run": _extend_segment_in_run,
        "extract_candidates_from_run": _extract_candidates_from_run,
        "try_global_merge_two_segments": adaptive_try_global_merge_two_segments,
        "try_merge_two_segments": _try_local_merge,
        "extract_segments": _extract_segments_core,
        "recover_dense_vertical_runs": _recover_dense_vertical_runs,
        "segment_is_duplicate_like": _segment_is_duplicate_scalar,
    }
    saved = {name: getattr(base, name) for name in names}
    try:
        for name, value in names.items():
            setattr(base, name, value)
        yield
    finally:
        for name, value in saved.items():
            setattr(base, name, value)
        _FALLBACK_ARGS, _FIT_CACHE = previous_fallback, previous_cache
        _NOISE_CACHE = previous_noise_cache
        _SEGMENT_CACHE = previous_segment_cache


def build_parser() -> argparse.ArgumentParser:
    parser = base.build_parser()
    parser.description = "Uncertainty-aware graph-optimized LiDAR line extraction"
    # Geometry-error-priority configuration B, verified on 20 Intel + 10 R2000 scans.
    parser.set_defaults(adaptive_merge_scale_max=4.0, rms_a=0.007, rms_b=0.001, max_b=0.0)
    parser.add_argument("--candidate-gap-spacing-factor", type=float, default=2.0,
                        help="Maximum ordinary projected step relative to median spacing during candidate recovery")
    parser.add_argument("--merge-gap-length-ratio", type=float, default=0.75,
                        help="Bound unsupported merge gaps by the shorter measured segment length")
    parser.add_argument('--endpoint-recovery-enable', action=argparse.BooleanOptionalAction,
                        default=True, help='Restore connected measured endpoint support after precleaning')
    parser.add_argument('--endpoint-min-new-points', type=int, default=3,
                        help='Minimum observed continuation points on an extended side')
    parser.add_argument('--contained-dedup-enable', action=argparse.BooleanOptionalAction,
                        default=True, help='Suppress scan-overlapping contained subsegments')
    parser.add_argument(
        "--native-enable", action=argparse.BooleanOptionalAction, default=False,
        help="Use optional compiled kernels (Numba/SciPy); --no-native-enable keeps NumPy",
    )
    parser.add_argument(
        "--batch-fit-enable", action=argparse.BooleanOptionalAction, default=True,
        help="Batch-screen dense recovery windows; accepted segments retain scalar fitting",
    )

    parser.add_argument(
        "--uncertainty-enable",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Use sensor uncertainty and confidence-quantile thresholds",
    )
    # Intel calibration: constant radial scale and effective angular estimate
    # reported in 标定/Inter/result.txt (conditional local-wall residual model).
    # For R2000 input, override the sensor scales with --sensor-range-noise-m
    # 0.007332930140722351 --sensor-angle-noise-rad 0.0012673763.
    parser.add_argument("--sensor-range-noise-m", type=float, default=0.006209645867461785)
    parser.add_argument("--sensor-range-noise-slope", type=float, default=0.0)
    parser.add_argument("--sensor-angle-noise-rad", type=float, default=0.0013248022,
                        help="Calibrated effective angular standard deviation in radians")
    parser.add_argument("--threshold-confidence", type=float, default=0.9973)
    parser.add_argument("--uncertainty-base-m", type=float, default=0.003)
    parser.add_argument("--uncertainty-floor-m", type=float, default=0.008)
    parser.add_argument("--uncertainty-cap-m", type=float, default=0.80)
    parser.add_argument("--uncertainty-perp-floor-m", type=float, default=0.025)
    parser.add_argument("--uncertainty-perp-cap-m", type=float, default=0.30)
    parser.add_argument("--uncertainty-perp-scale", type=float, default=1.25)
    parser.add_argument("--uncertainty-gap-scale", type=float, default=1.50)
    parser.add_argument("--uncertainty-mean-scale", type=float, default=0.92)
    parser.add_argument("--uncertainty-merge-scale", type=float, default=1.35)

    parser.add_argument(
        "--adaptive-huber-enable",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Tie Huber transition point to the local robust noise estimate",
    )
    parser.add_argument("--huber-sigma-gain", type=float, default=0.25)
    parser.add_argument("--huber-min-scale-m", type=float, default=0.002)
    parser.add_argument("--huber-min-delta-m", type=float, default=0.006)
    parser.add_argument(
        "--graph-recovery-enable",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Recover fragment paths with a degree-limited minimum-cost forest",
    )
    parser.add_argument("--graph-angle-deg", type=float, default=11.0)
    parser.add_argument("--graph-max-index-gap", type=int, default=60)
    parser.add_argument("--graph-gap-scale", type=float, default=3.0)
    parser.add_argument("--graph-perp-floor-m", type=float, default=0.035)
    parser.add_argument("--graph-perp-sigma-scale", type=float, default=2.0)
    parser.add_argument("--graph-weight-angle", type=float, default=0.35)
    parser.add_argument("--graph-weight-gap", type=float, default=0.35)
    parser.add_argument("--graph-weight-perp", type=float, default=0.20)
    parser.add_argument("--graph-weight-index", type=float, default=0.10)
    parser.add_argument("--graph-edge-cost-max", type=float, default=1.0)
    parser.add_argument("--graph-min-pts", type=int, default=8)
    parser.add_argument("--graph-min-len-m", type=float, default=0.15)
    parser.add_argument("--graph-min-gain-m", type=float, default=0.015)
    parser.add_argument("--graph-max-gap-scale", type=float, default=2.5)
    parser.add_argument("--graph-rms-relax", type=float, default=2.0)
    parser.add_argument("--graph-max-relax", type=float, default=2.0)
    parser.add_argument("--graph-rms-sigma-scale", type=float, default=0.85)
    parser.add_argument("--graph-straightness-min", type=float, default=0.975)
    parser.add_argument("--adaptive-merge-sparsity-gain", type=float, default=1.15)
    parser.add_argument("--adaptive-merge-sparsity-power", type=float, default=1.0)
    return parser


def extract_segments(
    points: np.ndarray,
    args: Optional[argparse.Namespace] = None,
) -> Tuple[List[base.Segment], float]:
    """Drop-in extraction API compatible with ``feature.py``."""

    cfg = args if args is not None else build_parser().parse_args([])
    prepare_backend(cfg)
    with _patched_base(cfg):
        return _extract_segments_core(points, cfg)


def extract_segments_from_layout(
    points: np.ndarray,
    frame_layouts: Sequence[dict],
    args: Optional[argparse.Namespace] = None,
) -> Tuple[List[base.Segment], float, bool]:
    """Extract prepared data; call prepare_backend(cfg) before external timing.

    Input files are never read here. On first use, optional JIT/cache setup is
    automatic; preparing explicitly separates that one-time cost from logic.
    """
    cfg = args if args is not None else build_parser().parse_args([])
    prepare_backend(cfg)
    with _patched_base(cfg):
        return base.extract_segments_from_layout(points, frame_layouts, cfg)



_EXTENSION_NATIVE_READY = False


def _prepare_extension_backend():
    """Compile in memory once; do not create cache files beside this module."""
    global _EXTENSION_NATIVE_READY
    if _EXTENSION_NATIVE_READY:
        return
    points = np.column_stack((np.linspace(0.0, 1.5, 16), np.full(16, 2.0)))
    fc = native.FitConfig(0.01, 6, 0.006, 0.0, 0.0013248022, 0.002, 0.006, 1.75)
    gc = native.GapConfig(True, 0.006, 0.0, 0.0013248022, 3.0, 0.003, 0.008,
                         0.8, 1.2, 0.92, 0.01, 0.01, 1.0, 1.0)
    dc = native.DenseConfig(6, 16, 0.34, 0.8, 0.93, 0.012, 0.020, 0.995)
    _finite_small_coordinates(points)
    fitted = native.configured_fit(points, fc)
    native.fitted_geometry(points, 0, len(points) - 1, fitted)
    _noise_split_supports_native(points, 0.01, fc, gc, 12, 0.006, 0.02, 0.01, 2.0)
    _dense_geometries_native(points, fc, dc)
    _EXTENSION_NATIVE_READY = True


def prepare_backend(args: argparse.Namespace) -> float:
    """Prepare optional JIT kernels, returning setup ms separately from logic."""
    start = perf_counter()
    if getattr(args, "native_enable", False) and native.prepare():
        _prepare_extension_backend()
    return (perf_counter() - start) * 1000.0


def run_cli(args: argparse.Namespace) -> None:
    """Run the original plotting/summary CLI and append graph diagnostics."""

    original_layout_extract = base.extract_segments_from_input_layout
    elapsed_ms = 0.0
    fallback_args = build_parser().parse_args([])
    fallback_args.native_enable = getattr(args, "native_enable", False)
    setup_ms = prepare_backend(args)

    def timed_layout_extract(points, input_path, cfg):
        nonlocal elapsed_ms
        global _FALLBACK_ARGS
        layouts = base.load_frame_layouts(input_path)
        _FALLBACK_ARGS = fallback_args
        started = perf_counter()
        result = base.extract_segments_from_layout(points, layouts, cfg)
        elapsed_ms = (perf_counter() - started) * 1000.0
        return result

    with _patched_base():
        try:
            base.extract_segments_from_input_layout = timed_layout_extract
            base.run_cli(args)
        finally:
            base.extract_segments_from_input_layout = original_layout_extract
    print(f"Algorithm runtime (excluding data loading and plotting): {elapsed_ms:.3f} ms")
    print(f"Acceleration backend: {'Numba' if native._READY and getattr(args, 'native_enable', False) else 'NumPy'}; setup (excluded above): {setup_ms:.3f} ms")
    if _LAST_DIAGNOSTICS:
        print("---- Uncertainty/graph diagnostics ----")
        for key in sorted(_LAST_DIAGNOSTICS):
            print(f"{key}: {_LAST_DIAGNOSTICS[key]:.3f}")


def main() -> None:
    args = build_parser().parse_args()
    run_cli(args)


if __name__ == "__main__":
    main()
