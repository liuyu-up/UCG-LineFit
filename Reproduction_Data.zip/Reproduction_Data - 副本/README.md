# UCG-LineFit Experimental Files and Running Instructions

This directory contains the point clouds, manually annotated reference segments, algorithm scripts, result figures, and calibration materials used in the manuscript experiments. This guide identifies the files associated with Figures 9–15 and Tables 3–5 and provides examples for running a single experiment on one scan.

- `Intel_data_experiment/`: Public Intel data, manual references for 40 scans, Figure 9 materials, and the corresponding algorithms, including the English-language timing script `runtime_analysis.py`.
- `Self_test_experiment/`: Recordings from real environments, manual references for 20 scans, Figure 10 materials, and the corresponding algorithms, including a separate English-language timing script `runtime_analysis.py`.
- `ablation_experiment/`: The Full core, three ablation variants, 30 shared raw scans with annotations, and three local point-cloud crops for Figure 12.
- `sensitivity_experiment/`: The Full method, two sets of 30 scans, and the result PDFs for Figures 13, 14, and 15.
- `error_calibration/`: The Intel calibration report in `Inter/` and the R2000 calibration report in `R2000/`.
- `parameter_list.docx`: Method parameters and sensor calibration parameters.

## 1. Runtime Environment and Common Settings

The target environment is Ubuntu 22.04.3 LTS with ROS2, Python 3.10.12, and NumPy 1.24.4. The experiments below read exported JSON point clouds directly; launching ROS2 nodes or replaying the original recordings is unnecessary.

Matplotlib and SciPy are required in addition to NumPy. The following dependency versions support Python 3.10; see [Matplotlib 3.7.5](https://pypi.org/project/matplotlib/3.7.5/) and [SciPy 1.10.1](https://pypi.org/project/scipy/1.10.1/) for their Python version requirements.

```bash
python3 -m pip install numpy==1.24.4 matplotlib==3.7.5 scipy==1.10.1
```

Run all commands below in Bash from the `Reproduction_Data` root directory. Replace the path on the first line with the actual local path:

```bash
cd /path/to/Reproduction_Data

export PYTHONDONTWRITEBYTECODE=1
export MPLBACKEND=Agg
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1

OUT=/tmp/ucg_linefit_demo
mkdir -p "$OUT"
```

Visualization examples write their output to `$OUT`; the ablation and timing scripts print single-scan results directly to the terminal. Visualization scripts may also save auxiliary outputs such as `points.png`. The timing commands do not require the `$OUT` directory.

The Full scripts used for Tables 3 and 4 and the sensitivity experiments support configurable sensor parameters.

## 2. Figure 9: Line Fitting for Two Intel Scans

The files are located in `Intel_data_experiment/figure9/`:

- Algorithms: `feature.py`, `ransac.py`, `iepf.py`, and `srg.py`.
- Input: `inter.json`, containing two scans with original zero-based scan indices 1759 and 1933, totaling 360 points.
- Original figure: `fig9_new.pdf`.

Use the figure-specific scripts in this directory with their default configurations. The `feature.py` script reads the layout of the two scans and the angular increment from the input metadata; it does not use `INTEL_CFG`.

```bash
D=Intel_data_experiment/figure9
INPUT="$D/inter.json"

python3 -B "$D/feature.py" --input "$INPUT" \
  --output-png "$OUT/fig9_full.png"

python3 -B "$D/ransac.py" --input "$INPUT" \
  --output-png "$OUT/fig9_ransac.png" \
  --output-json "$OUT/fig9_ransac.json"

iconv -f GB18030 -t UTF-8 "$D/iepf.py" | \
  python3 -B - --input "$INPUT" --output "$OUT/fig9_iepf.png"

python3 -B "$D/srg.py" --input "$INPUT" \
  --output-png "$OUT/fig9_srg.png" \
  --output-json "$OUT/fig9_srg.json"
```

The IEPF command converts the source encoding in memory without modifying the original script. This conversion uses the `iconv` command available on Ubuntu.

These commands generate the fitting results for the four methods separately.

## 3. Table 3: Experiments on 40 Intel Scans

Use the following files:

- Algorithms: `feature.py`, `ransac.py`, `iepf.py`, and `srg.py` in `Intel_data_experiment/`.
- Inputs and reference segments: 40 JSON files in `Intel_data_experiment/annotated_scans_40/data_and_references/`, containing 179 reference segments in total.
- Manual annotation visualizations: The corresponding PDFs in `Intel_data_experiment/annotated_scans_40/`.
- Timing entry point: `Intel_data_experiment/runtime_analysis.py`.

These algorithm files are stored separately from the figure-specific versions in `figure9/`. The following example uses `inter1.json`:

```bash
D=Intel_data_experiment
INPUT="$D/annotated_scans_40/data_and_references/inter1.json"

python3 -B "$D/feature.py" --input "$INPUT" \
  "${INTEL_CFG[@]}" --output-png "$OUT/table3_full.png"

python3 -B "$D/ransac.py" --input "$INPUT" \
  --output-png "$OUT/table3_ransac.png" \
  --output-json "$OUT/table3_ransac.json"

python3 -B "$D/iepf.py" --input "$INPUT" \
  --output "$OUT/table3_iepf.png"

python3 -B "$D/srg.py" --input "$INPUT" \
  --output-png "$OUT/table3_srg.png" \
  --output-json "$OUT/table3_srg.json"
```

The main settings are stored as script defaults:

| Method | Main settings |
|---|---|
| Full | `threshold_confidence=0.9973`, `huber_sigma_gain=0.25`, `graph_angle_deg=11` |
| RANSAC | Distance threshold: 0.02 m; 240 iterations; at least 12 inliers; projection gap: 0.24 m; minimum length: 0.30 m; random seed: 42 |
| IEPF | `gap_scale=8`, `eps_a=0.01`, `eps_b=0.003`; merging residual threshold: 0.03 m; at least 12 points; minimum length: 0.30 m |
| SRG | `least_thresh=0.03`, `predict_distance=0.10`; 6 seed points; at least 12 points; minimum length: 0.30 m |

To compare only the algorithm runtimes of the four methods on this scan, run:

```bash
python3 -B Intel_data_experiment/runtime_analysis.py \
  --input Intel_data_experiment/annotated_scans_40/data_and_references/inter1.json \
  --method all --no-breakdown
```

The timing entry point uses the default algorithm settings from the same directory, configures single-threaded execution, and applies a common final filter requiring at least 12 points and a length of at least 0.30 m to the output of every method.

## 4. Figure 10: Line Fitting for a Laboratory Scan

The files are located in `Self_test_experiment/figure10/`:

- Algorithms: `feature.py`, `ransac.py`, `iepf.py`, and `srg.py`.
- Input: `single_frame.json`, containing 1166 valid measurement points.
- Original figure: `fig10.pdf`.

The `feature.py` script in this directory is a dedicated version adjusted to produce the seven segments in Figure 10. Its final quality filter requires at least 12 supporting points and a minimum length of 0.30 m; all other settings use the script defaults.

```bash
D=Self_test_experiment/figure10
INPUT="$D/single_frame.json"

python3 -B "$D/feature.py" --input "$INPUT" \
  --angle-increment 0.002617993877991494 \
  --output-png "$OUT/fig10_full.png"

python3 -B "$D/ransac.py" --input "$INPUT" \
  --output-png "$OUT/fig10_ransac.png" \
  --output-json "$OUT/fig10_ransac.json"

iconv -f GB18030 -t UTF-8 "$D/iepf.py" | \
  python3 -B - --input "$INPUT" --output "$OUT/fig10_iepf.png"

python3 -B "$D/srg.py" --input "$INPUT" \
  --output-png "$OUT/fig10_srg.png" \
  --output-json "$OUT/fig10_srg.json"
```

The Figure 10 IEPF script uses the same in-memory encoding conversion.

**Configuration note for Figures 9 and 10:** The RANSAC scripts in both figure directories retain their historical default settings.

## 5. Table 4: Experiments on 20 R2000 Scans

Use the following files:

- Algorithms: `feature.py`, `ransac.py`, `iepf.py`, and `srg.py` in `Self_test_experiment/`.
- Inputs and reference segments: 20 JSON files in `Self_test_experiment/annotated_scans_20/data_and_references/`, containing 117 reference segments in total.
- Manual annotation visualizations: The corresponding PDFs in `Self_test_experiment/annotated_scans_20/`.
- Original recordings: The ROS2 data files in `Corridor/`, `Hall/`, and `Office/`.
- Timing entry point: `Self_test_experiment/runtime_analysis.py`.

Single-scan experiments read JSON files directly and do not require point-cloud extraction from the ROS2 recordings. The following example uses `Corridor01.json`:

```bash
D=Self_test_experiment
INPUT="$D/annotated_scans_20/data_and_references/Corridor01.json"

python3 -B "$D/feature.py" --input "$INPUT" \
  "${R2000_CFG[@]}" --output-png "$OUT/table4_full.png"

python3 -B "$D/ransac.py" --input "$INPUT" \
  --output-png "$OUT/table4_ransac.png" \
  --output-json "$OUT/table4_ransac.json"

python3 -B "$D/iepf.py" --input "$INPUT" \
  --output "$OUT/table4_iepf.png"

python3 -B "$D/srg.py" --input "$INPUT" \
  --output-png "$OUT/table4_srg.png" \
  --output-json "$OUT/table4_srg.json"
```

The main settings are as follows:

| Method | Main settings in the current scripts |
|---|---|
| Full | R2000 sensor parameters; `c=0.9973`, `huber_sigma_gain=0.25`, `graph_angle_deg=11`; continuous-support recovery enabled; minimum output length: 0.50 m |
| RANSAC | Distance threshold: 0.02 m; 480 iterations; at least 12 inliers; projection gap: 0.40 m; minimum length: 0.50 m; random seed: 42 |
| IEPF | `gap_scale=24`, `eps_a=0.05`, `eps_b=0`; merging residual threshold: 0.04 m; at least 12 points; minimum length: 0.50 m |
| SRG | `least_thresh=0.04`, `predict_distance=0.15`; 10 seed points; at least 12 points; minimum length: 0.50 m |

The 0.50 m threshold listed above is the actual internal setting in the current real-environment scripts. The added timing scripts preserve these internal settings and apply the common 12-point, 0.30 m filter after each algorithm returns.

To compare only the algorithm runtimes of the four methods on this scan, run:

```bash
python3 -B Self_test_experiment/runtime_analysis.py \
  --input Self_test_experiment/annotated_scans_20/data_and_references/Corridor01.json \
  --method all --no-breakdown
```

The single-scan commands do not perform reference-segment matching or aggregate metrics over the full manuscript datasets.

## 6. Figure 11: Runtime of the Internal Stages of the Full Method

Each dataset has its own English-language timing script:

| Dataset | Timing script | Full implementation used | Corresponding manuscript inputs |
|---|---|---|---|
| Intel | `Intel_data_experiment/runtime_analysis.py` | `feature.py` in the same directory | 40 scans in `annotated_scans_40/data_and_references/` |
| R2000 | `Self_test_experiment/runtime_analysis.py` | `feature.py` in the same directory, including continuous wall-support recovery | 20 scans in `annotated_scans_20/data_and_references/` |

Both scripts use Python's cross-platform monotonic high-resolution timer, `time.perf_counter_ns()`.

Run a Full stage-runtime analysis on one scan from each dataset:

```bash
python3 -B Intel_data_experiment/runtime_analysis.py \
  --input Intel_data_experiment/annotated_scans_40/data_and_references/inter1.json \
  --method Full

python3 -B Self_test_experiment/runtime_analysis.py \
  --input Self_test_experiment/annotated_scans_20/data_and_references/Corridor01.json \
  --method Full
```

If `--input` is omitted, the two scripts default to the `inter1.json` and `Corridor01.json` files shown above, respectively. Replace `--method Full` with `--method RANSAC`, `--method IEPF`, or `--method SRG` to measure the total single-scan runtime of that method. The `--method all` option runs all four methods sequentially; only Full provides a stage breakdown.

### Timing Procedure and Scope

A default analysis includes one untimed warm-up call, one uninstrumented timed call, and one additional call for Full stage profiling. The profiling call is excluded from the uninstrumented total runtime. Use `--no-breakdown` to disable the additional profiling call.

Timing covers preprocessing, candidate search, fitting, structural recovery, endpoint generation, applicable scan-layout coordinate restoration, and the final 12-point, 0.30 m filter after the in-memory point cloud enters the fitting pipeline.

The default configuration uses the NumPy backend and a single thread; Numba is not required. The `--backend numba` option is available for environments with a compatible Numba installation. Compilation initialization and warm-up occur before the timed call.

### Four Stages and Reported Outputs

| Stage | Included operations |
|---|---|
| Preprocessing | Point-level preprocessing, noisy point-run cleanup, and internal provisional fitting |
| Candidate search / gating | Candidate search and growth, support search, fragment candidates, and dense-window gating |
| Independent TLS-Huber fitting | TLS-Huber calls outside preprocessing, local scale estimation, and batch fitting |
| Endpoints + merge / optimization | Endpoint geometry, merging, graph recovery, deduplication, continuous-support recovery, coordinate restoration, final filtering, and remaining pipeline overhead |

The timing wrappers subtract time already assigned to child stages from parent calls to avoid double-counting nested calls. Provisional fits within preprocessing remain assigned to preprocessing. Compiled kernels are treated as indivisible calls assigned to the calling stage; fitting operations within a kernel are not additionally counted under independent fitting.

Terminal output includes the input point count, effective configuration, valid segment count, uninstrumented single-scan total runtime, and the instrumented runtime, share, and normalized allocation for each Full stage:

```text
Normalized stage time = Uninstrumented total time × Instrumented stage share
```

Normalized values are estimates allocated according to the instrumented stage shares; they are not independent measurements of each stage during production execution. Instrumentation itself affects these shares. The scripts also print the instrumented total runtime to distinguish the two measurements.

Each command measures only the specified scan. Hardware, backend, and scan content affect runtime; a single-scan result cannot directly replace the manuscript values obtained from repeated measurements over 40 and 20 scans.

## 7. Figure 12: Ablation Comparisons for Three Local Structures

The algorithms are located in `ablation_experiment/`:

| Method | File |
|---|---|
| Full | `Full_core_frozen.py`, called through `reproduce_table5.py` |
| Heuristic | `ablation_no_uncertainty.py` |
| Fixed-Huber | `ablation_no_adaptive_huber.py` |
| Graph-off | `ablation_no_graph.py` |

The three local point-cloud crops are located in `ablation_experiment/figure12_point_cloud_crops/`:

| Figure 12 panels | Input file | Methods compared |
|---|---|---|
| (a), (b) | `Fig12_ab_Heuristic_Corridor08.json` | Full, Heuristic |
| (c), (d) | `Fig12_cd_FixedHuber_Intel01683.json` | Full, Fixed-Huber |
| (e), (f) | `Fig12_ef_GraphOff_Intel00596.json` | Full, Graph-off |

Commands for fitting each local crop once:

```bash
D=ablation_experiment
CROP="$D/figure12_point_cloud_crops"

python3 -B "$D/reproduce_table5.py" \
  --input "$CROP/Fig12_ab_Heuristic_Corridor08.json" --method Full

python3 -B "$D/ablation_no_uncertainty.py" \
  --input "$CROP/Fig12_ab_Heuristic_Corridor08.json"

python3 -B "$D/reproduce_table5.py" \
  --input "$CROP/Fig12_cd_FixedHuber_Intel01683.json" --method Full

python3 -B "$D/ablation_no_adaptive_huber.py" \
  --input "$CROP/Fig12_cd_FixedHuber_Intel01683.json"

python3 -B "$D/reproduce_table5.py" \
  --input "$CROP/Fig12_ef_GraphOff_Intel00596.json" --method Full

python3 -B "$D/ablation_no_graph.py" \
  --input "$CROP/Fig12_ef_GraphOff_Intel00596.json"
```

Results are printed to the terminal as JSON, including endpoints, support-point counts, lengths, and residuals. The `effective_segments` field contains the segments that satisfy the 12-point and 0.30 m requirements.

These commands refit the local point-cloud crops.

## 8. Table 5: Ablation Experiments on 30 Shared Scans

Use the same algorithm files as for Figure 12, with complete scans as input:

- `ablation_experiment/raw_scans/Intel/`: 20 scans.
- `ablation_experiment/raw_scans/R2000/`: 10 scans.
- `ablation_experiment/annotated_scans/`: Corresponding manually reviewed PDFs and `.segments.json` files, containing 157 reference segments in total.

All four methods share the same sensor parameters; each ablation changes the corresponding module:

| Method | Configuration change |
|---|---|
| Full | All modules retained |
| Heuristic | Heuristic thresholds and the corresponding connection criteria |
| Fixed-Huber | Adaptive Huber disabled; transition point fixed at 0.02 m |
| Graph-off | Graph recovery disabled |

The following example uses `Intel_02566.json`:

```bash
D=ablation_experiment
INPUT="$D/raw_scans/Intel/Intel_02566.json"

python3 -B "$D/reproduce_table5.py" --input "$INPUT" --method Full
python3 -B "$D/ablation_no_uncertainty.py" --input "$INPUT"
python3 -B "$D/ablation_no_adaptive_huber.py" --input "$INPUT"
python3 -B "$D/ablation_no_graph.py" --input "$INPUT"
```

For a single scan from a real environment, change `INPUT` to:

```bash
INPUT=ablation_experiment/raw_scans/R2000/Hall_04919.json
```

The entry point automatically configures the corresponding parameters using the `dataset` field and angular-increment metadata in the JSON input.

## 9. Figure 13: Sensitivity to the Gaussian Quantile Parameter

Use the following files and settings:

- Algorithm: `sensitivity_experiment/feature.py`.
- Data: `sensitivity_experiment/confidence_and_noise_gain_30_frames/`.
- Dataset size: 20 Intel scans and 10 R2000 scans, with 142 reference segments in total.
- Original figure: `fig13_sensitivity_confidence.pdf`.
- Varied parameter: `--threshold-confidence`; the manuscript range is 0.80–0.9999.

The following example uses the default value of `0.9973` on one Intel scan, with the other two sensitivity parameters fixed at 0.25 and 11°:

```bash
python3 -B sensitivity_experiment/feature.py \
  --input sensitivity_experiment/confidence_and_noise_gain_30_frames/inter1.json \
  "${INTEL_CFG[@]}" \
  --threshold-confidence 0.9973 \
  --huber-sigma-gain 0.25 \
  --graph-angle-deg 11 \
  --output-png "$OUT/fig13_single.png"
```

Change the value of `--threshold-confidence` to run another single-parameter experiment.

## 10. Figure 14: Sensitivity to the Local Noise-Scale Gain

Figures 14 and 13 use the same `feature.py` script and the same 30 scans. The original figure is `fig14_sensitivity_huber_gain.pdf`. The varied parameter is `--huber-sigma-gain`, with a manuscript range of 0.10–6.

```bash
python3 -B sensitivity_experiment/feature.py \
  --input sensitivity_experiment/confidence_and_noise_gain_30_frames/inter1.json \
  "${INTEL_CFG[@]}" \
  --threshold-confidence 0.9973 \
  --huber-sigma-gain 0.25 \
  --graph-angle-deg 11 \
  --output-png "$OUT/fig14_single.png"
```

Change `--huber-sigma-gain` while keeping the other parameters fixed.

For real-environment inputs in Figures 13 and 14, replace the input with `Corridor01.json` from the same directory and replace `"${INTEL_CFG[@]}"` with `"${R2000_CFG[@]}"`.

## 11. Figure 15: Sensitivity to the Graph-Recovery Orientation Threshold

Use the following files and settings:

- Algorithm: `sensitivity_experiment/feature.py`.
- Data: `sensitivity_experiment/graph_direction_threshold_30_frames/`.
- Dataset size: A separately selected set of 20 Intel scans and 10 R2000 scans, with 176 reference segments in total.
- Original figure: `fig15_sensitivity_graph_angle.pdf`.
- Varied parameter: `--graph-angle-deg`; the manuscript range is 0.1°–30°.

The following example uses `Intel_00418.json` and the default orientation threshold of 11°:

```bash
python3 -B sensitivity_experiment/feature.py \
  --input sensitivity_experiment/graph_direction_threshold_30_frames/Intel_00418.json \
  "${INTEL_CFG[@]}" \
  --threshold-confidence 0.9973 \
  --huber-sigma-gain 0.25 \
  --graph-angle-deg 11 \
  --output-png "$OUT/fig15_single.png"
```

For a real-environment input, use `Hall_02600.json` from the same directory with `R2000_CFG`.

The commands above for Figures 13–15 each perform fitting on one scan at one parameter setting and output the corresponding visualization and runtime information.
