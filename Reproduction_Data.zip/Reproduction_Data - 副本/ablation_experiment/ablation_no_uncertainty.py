"""Heuristic ablation of the frozen Full method; calibrated CLI: --input FILE."""
import os
import sys
sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[_key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import copy
from contextlib import contextmanager
import numpy as np
import Full_core_frozen as full

def make_config(data):
    """The same sensor parameters used for the final 30-frame Table 5."""
    dataset = data["dataset"]
    if dataset not in ("Intel", "R2000"):
        raise ValueError("dataset must be Intel or R2000")
    cfg = full.build_parser().parse_args([])
    cfg.native_enable = False
    cfg.angle_increment = abs(float(data["metadata"]["angle_increment_rad"]))
    cfg.sensor_range_noise_m = .006209645867461785 if dataset == "Intel" else .007332930140722351
    cfg.sensor_angle_noise_rad = .0013248022 if dataset == "Intel" else .0012673763
    cfg.sensor_range_noise_slope = 0.
    return cfg

def configure(args):
    cfg = copy.copy(args)
    cfg.uncertainty_enable = False
    cfg.adaptive_merge_enable = False
    return cfg

def heuristic_edge(m,a,b,points,angle_increment,args):
    base=m.base
    if b.idx_start<a.idx_start:a,b=b,a
    idx_gap=int(b.idx_start-a.idx_end)
    if idx_gap<0 or idx_gap>args.graph_max_index_gap:return None
    angle=base.segment_included_angle_deg(a,b)
    if angle>args.graph_angle_deg:return None
    gap=base.segment_endpoint_to_endpoint_distance(a,b)
    axis_gap=base.segment_support_axis_distance(a,b)
    r=.5*(np.linalg.norm(base.segment_midpoint(a))+np.linalg.norm(base.segment_midpoint(b)))
    gap_limit=max(args.graph_gap_scale,1.)*m._ORIGINAL_MERGE_GAP_THR(r,angle_increment,args.merge_gap0_m,args.merge_cgap)
    band=max(args.graph_perp_floor_m,m._ORIGINAL_MERGE_PERP_THR(r,args.merge_perp_base_m,args.merge_perp_cr))+.75*gap
    if gap>gap_limit or axis_gap>band:return None
    cost=(args.graph_weight_angle*angle/max(args.graph_angle_deg,1e-6)+args.graph_weight_gap*gap/max(gap_limit,1e-6)
          +args.graph_weight_perp*axis_gap/max(band,1e-6)+args.graph_weight_index*idx_gap/max(args.graph_max_index_gap,1))
    if cost>args.graph_edge_cost_max:return None
    return m.FragmentEdge(-1,-1,float(cost),float(angle),float(gap),float(axis_gap),float(band))

@contextmanager
def ablation_context(points=None):
    original = full._fragment_edge
    full._fragment_edge = lambda *args: heuristic_edge(full, *args)
    try:
        yield
    finally:
        full._fragment_edge = original

def extract_segments(points, args=None):
    cfg = configure(args if args is not None else full.build_parser().parse_args([]))
    cfg.native_enable = False
    with ablation_context(points):
        return full.extract_segments(points, cfg)

if __name__ == "__main__":
    from reproduce_table5 import main
    main(default_method="Heuristic")
