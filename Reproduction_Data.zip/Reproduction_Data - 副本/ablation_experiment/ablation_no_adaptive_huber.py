"""Fixed-Huber ablation of the frozen Full method; calibrated CLI: --input FILE."""
import sys
sys.dont_write_bytecode = True
import copy
from contextlib import nullcontext
import ablation_no_uncertainty as common

def configure(args):
    cfg = copy.copy(args)
    cfg.adaptive_huber_enable = False
    cfg.huber_delta = .02
    return cfg

def ablation_context(points=None):
    return nullcontext()

def extract_segments(points, args=None):
    cfg = configure(args if args is not None else common.full.build_parser().parse_args([]))
    cfg.native_enable = False
    return common.full.extract_segments(points, cfg)

if __name__ == "__main__":
    from reproduce_table5 import main
    main(default_method="Fixed-Huber")
