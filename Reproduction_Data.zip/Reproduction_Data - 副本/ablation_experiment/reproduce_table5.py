"""Recompute Table 5 from the shared raw data and reviewed ideal segments.
No prediction, result or visualization files are written. Results go to stdout.
"""
import os
import sys
sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"):
    os.environ[_key] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

import argparse
import hashlib
import json
import math
import time
from pathlib import Path
from contextlib import nullcontext
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from scipy.optimize import linear_sum_assignment
import ablation_no_uncertainty as heuristic
import ablation_no_adaptive_huber as fixed_huber
import ablation_no_graph as graph_off

HERE = Path(__file__).resolve().parent
METHODS = ("Full", "Heuristic", "Fixed-Huber", "Graph-off")
VARIANTS = {"Full": None, "Heuristic": heuristic, "Fixed-Huber": fixed_huber, "Graph-off": graph_off}
CORE_SHA256 = "eeddfc5cce40c8c1decfa6c80b18d436dd8af02c231b25f74456789253e681c2"

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def run_method(data, method):
    if method not in VARIANTS:
        raise ValueError(method)
    points = np.asarray([[p["x"], p["y"]] for p in data["points"]], dtype=float)
    cfg = heuristic.make_config(data)
    variant = VARIANTS[method]
    if variant is not None:
        cfg = variant.configure(cfg)
    full = heuristic.full
    full._LAST_DIAGNOSTICS.clear()
    start = time.monotonic()
    with variant.ablation_context(points) if variant is not None else nullcontext():
        segments, _ = full.extract_segments(points.copy(), cfg)
    serialized = [
        {"p1": s.p1.tolist(), "p2": s.p2.tolist(),
         "idx_start": int(s.idx_start), "idx_end": int(s.idx_end),
         "n_points": int(s.n_points), "length": float(s.length),
         "rms": float(s.rms), "max_res": float(s.max_res),
         "is_fragment": bool(s.is_fragment), "merged_from": s.merged_from}
        for s in segments
    ]
    return {"segments": serialized,
            "effective_segments": [s for s in serialized if s["n_points"] >= 12 and s["length"] >= .30],
            "parameters": vars(cfg), "seconds": time.monotonic() - start}

def geometry(p,g):
    a,b,c,d=map(np.asarray,[p['p1'],p['p2'],g['p1'],g['p2']])
    lp,lg=np.linalg.norm(b-a),np.linalg.norm(d-c)
    if min(lp,lg)<=1e-12:return {'eligible':False}
    u,v=(b-a)/lp,(d-c)/lg
    angle=float(np.degrees(np.arccos(np.clip(abs(u@v),0.,1.))))
    nu,nv=np.array([-u[1],u[0]]),np.array([-v[1],v[0]])
    normal=float((abs((a-c)@nv)+abs((b-c)@nv)+abs((c-a)@nu)+abs((d-a)@nu))/4)
    lo,hi=sorted([(a-c)@v,(b-c)@v]);overlap=max(0.,min(hi,lg)-max(lo,0.))
    iou=float(overlap/(lg+hi-lo-overlap))
    endpoint=float(min(np.linalg.norm(a-c)+np.linalg.norm(b-d),np.linalg.norm(a-d)+np.linalg.norm(b-c))/2)
    return {'eligible':angle<=5. and normal<=.02 and iou>=.5,
            'angle_deg':angle,'normal_m':normal,'iou':iou,'endpoint_mean_m':endpoint}

def matching(pred,refs):
    stats={(gi,pi):geometry(p,g) for gi,g in enumerate(refs) for pi,p in enumerate(pred)}
    eligible={k:v['endpoint_mean_m'] for k,v in stats.items() if v['eligible']}
    # An unmatched penalty exceeds the maximum possible total eligible cost,
    # so cardinality has strict priority over endpoint distance.
    penalty=(min(len(pred),len(refs))+1)*(max(eligible.values(),default=0.)+1.)
    def solve(gs,ps):
        if not gs:return 0,0.,{}
        cost=np.full((len(gs),len(ps)+len(gs)),penalty)
        cost[:,:len(ps)]=penalty*3
        for r,gi in enumerate(gs):
            for c,pi in enumerate(ps):
                if (gi,pi) in eligible:cost[r,c]=eligible[gi,pi]
        ii,jj=linear_sum_assignment(cost)
        pairs={gs[i]:ps[j] for i,j in zip(ii,jj) if j<len(ps) and (gs[i],ps[j]) in eligible}
        return len(pairs),math.fsum(eligible[k] for k in pairs.items()),pairs
    gs=list(range(len(refs)));ps=list(range(len(pred)))
    target_n,target_cost,_=solve(gs,ps)
    ans={}
    # Lexicographic reference ID then prediction ID, with unmatched last.
    # Re-solving the residual assignment avoids epsilon perturbing costs.
    for gi in gs:
        remaining=[g for g in gs if g>gi]
        choices=[p for p in ps if (gi,p) in eligible]+[None]
        for pi in choices:
            rest=[p for p in ps if p!=pi]
            n,c,_=solve(remaining,rest)
            own=0. if pi is None else eligible[gi,pi]
            if n+(pi is not None)==target_n and math.isclose(c+own,target_cost,rel_tol=1e-13,abs_tol=1e-12):
                if pi is not None:
                    ans[gi]=pi;ps.remove(pi);target_n-=1
                target_cost-=own
                break
        else:raise AssertionError('No canonical optimal assignment')
    return ans,stats

def distances(points,pred):
    x=np.asarray(points);a,b=np.asarray(pred['p1']),np.asarray(pred['p2']);v=b-a
    t=np.clip((x-a)@v/(v@v),0.,1.)
    return np.linalg.norm(x-a-t[:,None]*v,axis=1)

def discover_frames(data_dir, labels_dir):
    records = []
    for dataset, count in (("Intel", 20), ("R2000", 10)):
        pdfs = sorted((labels_dir / dataset).glob("*.pdf"))
        raws = {p.stem: p for p in (data_dir / dataset).glob("*.json")}
        labels = {p.name.removesuffix(".segments.json"): p for p in (labels_dir / dataset).glob("*.segments.json")}
        names = {p.stem for p in pdfs}
        if len(names) != count or names != set(raws) or names != set(labels):
            raise ValueError(f"{dataset}: expected {count} matching raw JSON/PDF/annotation files")
        for pdf in pdfs:
            records.append((str(raws[pdf.stem]), str(labels[pdf.stem]), str(pdf)))
    # Process the slower real-world frames first.
    return sorted(records, key=lambda r: (Path(r[0]).parent.name != "R2000", Path(r[0]).stem))

def evaluate_frame(record):
    raw_path, label_path, pdf_path = map(Path, record)
    data, annotation = read_json(raw_path), read_json(label_path)
    assert data["name"] == annotation["frame"] == raw_path.stem
    assert data["dataset"] == annotation["dataset"]
    assert annotation["raw_json_sha256"] == sha256(raw_path)
    assert annotation["pdf_sha256"] == sha256(pdf_path)
    assert annotation["annotation_status"] == "human_reviewed_reference_confirmed_by_user"
    refs = sorted(annotation["segments"], key=lambda s: s["id"])
    assert [s["id"] for s in refs] == list(range(1, len(refs) + 1))
    geometry_records = [{k: s[k] for k in ("id", "p1", "p2", "n_points", "length")} for s in refs]
    reference_sha = hashlib.sha256(json.dumps(geometry_records, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    assert reference_sha == annotation["reference_geometry_sha256"]
    samples = {}
    for g in refs:
        assert g["human_review_status"] == "reviewed"
        length = float(np.linalg.norm(np.asarray(g["p2"]) - g["p1"]))
        assert abs(length - g["length"]) < 1e-10
        assert g["n_points"] >= 12 and length >= .30
        samples[g["id"]] = np.linspace(g["p1"], g["p2"], int(np.ceil(length / .01)) + 1)
    frame = {"frame": data["name"], "dataset": data["dataset"], "G": len(refs), "eval": {}}
    for method in METHODS:
        result = run_method(data, method)
        predictions = result["effective_segments"]
        pairs, _ = matching(predictions, refs)
        matches = []
        for gi, pi in sorted(pairs.items()):
            rr = distances(samples[refs[gi]["id"]], predictions[pi])
            matches.append({"reference_id": refs[gi]["id"], "prediction_index": pi,
                            "N_eval": len(rr), "sum_sq": float(rr @ rr), "MaxRes": float(rr.max())})
        tp = len(matches)
        frame["eval"][method] = {
            "P_all": len(result["segments"]), "P": len(predictions),
            "TP": tp, "FP": len(predictions) - tp, "FN": len(refs) - tp,
            "matches": matches, "seconds": result["seconds"]}
    return frame

def aggregate(frames):
    totals = {m: {k: 0 for k in ("TP", "FP", "FN", "P", "P_all", "N_eval", "sum_sq", "MaxRes")} for m in METHODS}
    common_count = 0
    for frame in frames:
        maps = {m: {v["reference_id"]: v for v in frame["eval"][m]["matches"]} for m in METHODS}
        common = set.intersection(*(set(maps[m]) for m in METHODS))
        common_count += len(common)
        for method in METHODS:
            total = totals[method]
            for key in ("TP", "FP", "FN", "P", "P_all"):
                total[key] += frame["eval"][method][key]
            for reference_id in sorted(common):
                for key in ("N_eval", "sum_sq"):
                    total[key] += maps[method][reference_id][key]
                total["MaxRes"] = max(total["MaxRes"], maps[method][reference_id]["MaxRes"])
    reference_count = sum(f["G"] for f in frames)
    for total in totals.values():
        tp, fp, fn = total["TP"], total["FP"], total["FN"]
        assert tp + fn == reference_count and tp + fp == total["P"]
        total["Precision"] = 100 * tp / (tp + fp) if tp + fp else 0.
        total["Recall"] = 100 * tp / (tp + fn) if tp + fn else 0.
        total["F1"] = 200 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.
        total["RMSE"] = math.sqrt(total["sum_sq"] / total["N_eval"]) if total["N_eval"] else None
        if not total["N_eval"]:
            total["MaxRes"] = None
    return {"frames": len(frames), "G": reference_count, "NC": common_count,
            "common_percentage": 100 * common_count / reference_count if reference_count else 0.,
            "metrics": totals}

def main(default_method="Full"):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=HERE / "raw_scans")
    parser.add_argument("--labels-dir", type=Path, default=HERE / "annotated_scans")
    parser.add_argument("--workers", type=int, default=min(6, os.cpu_count() or 1))
    parser.add_argument("--input", type=Path, help="Fit one raw JSON frame and print predictions")
    parser.add_argument("--method", choices=METHODS, default=default_method)
    parser.add_argument("--all", action="store_true", help="Recompute all four methods on all 30 frames (default without --input)")
    parser.add_argument("--json", action="store_true", help="Print final JSON, including frame-level matching results")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    if args.input and args.all:
        parser.error("--input and --all are mutually exclusive")
    if sha256(HERE / "Full_core_frozen.py") != CORE_SHA256:
        raise RuntimeError("The frozen Full core has changed")
    if args.input:
        data = read_json(args.input)
        print(json.dumps({"frame": data["name"], "method": args.method, **run_method(data, args.method)}, ensure_ascii=False))
        return
    records = discover_frames(args.data_dir.resolve(), args.labels_dir.resolve())
    started = time.monotonic()
    frames = []
    if args.workers == 1:
        for record in records:
            frames.append(evaluate_frame(record))
            print(f"Completed {len(frames)}/30 frames: {frames[-1]['frame']}", file=sys.stderr, flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(evaluate_frame, record) for record in records]
            for future in as_completed(futures):
                frames.append(future.result())
                print(f"Completed {len(frames)}/30 frames: {frames[-1]['frame']}", file=sys.stderr, flush=True)
    frames.sort(key=lambda f: f["frame"])
    results = {scope: aggregate(fs) for scope, fs in (
        ("Combined", frames),
        ("Intel", [f for f in frames if f["dataset"] == "Intel"]),
        ("R2000", [f for f in frames if f["dataset"] == "R2000"]))}
    if args.json:
        print(json.dumps({"results": results, "per_frame": frames, "elapsed_seconds": time.monotonic() - started}, ensure_ascii=False))
        return
    for scope, result in results.items():
        print(f"\n{scope}: frames={result['frames']}, G={result['G']}, NC={result['NC']}, N_eval={result['metrics']['Full']['N_eval']}")
        print("Method | TP | FP | FN | Precision (%) | Recall (%) | F1 (%) | RMSE (m) | MaxRes (m)")
        for method in METHODS:
            t = result["metrics"][method]
            fields = [f"{t[k]:.2f}" for k in ("Precision", "Recall", "F1")]
            fields += ["N/A" if t[k] is None else f"{t[k]:.6f}" for k in ("RMSE", "MaxRes")]
            print(f"{method} | {t['TP']} | {t['FP']} | {t['FN']} | " + " | ".join(fields))

if __name__ == "__main__":
    main()
