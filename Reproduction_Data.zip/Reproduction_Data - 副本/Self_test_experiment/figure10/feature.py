#!/usr/bin/env python3
"""Figure 10 Full source with consistent final acceptance and candidate recovery.

Run with --input single_frame.json. The seven illustrated boundaries are fitted
from the point cloud; no archived figure geometry or fixed endpoints are read.
Final acceptance uses at least 12 support points and 0.30 m by default.
"""
import argparse
import json
import os
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

MPLCONFIG_DIR = Path(__file__).resolve().with_name(".mplconfig")
MPLCONFIG_DIR.mkdir(exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(MPLCONFIG_DIR))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


EPS = 1e-12


plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 14,
    "axes.labelsize": 24,
    "axes.titlesize": 34,
    "legend.fontsize": 22,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "axes.linewidth": 1.1,
    "figure.facecolor": "#ffffff",
    "savefig.facecolor": "#ffffff",
})


@dataclass
class LineFit:
    mu: np.ndarray
    direction: np.ndarray
    rms: float
    max_res: float
    straightness: float


@dataclass
class Segment:
    id: int = 0
    idx_start: int = 0
    idx_end: int = 0
    p1: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=np.float64))
    p2: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=np.float64))
    length: float = 0.0
    rms: float = 0.0
    max_res: float = 0.0
    straightness: float = 0.0
    feature: float = 0.0
    n_points: int = 0
    is_feature: bool = False
    is_fragment: bool = False
    merged_from: List[Tuple[int, int]] = field(default_factory=list)


def load_points(path: Path) -> np.ndarray:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    pts = data.get("points", [])
    arr = np.array([[float(p["x"]), float(p["y"])] for p in pts], dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] != 2:
        raise ValueError("Invalid points format in JSON.")
    if len(arr) < 2:
        raise ValueError("Not enough points to fit segments.")
    return arr


def load_angle_increment_hint(path: Path) -> Optional[float]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    metadata = data.get("metadata", {})
    for key in ("recommended_angle_increment_rad", "angle_increment_rad", "laser_angle_increment_rad"):
        if key in metadata:
            value = float(metadata[key])
            if value > 0.0:
                return value
    return None


def _metadata_point_xy(obj: dict) -> np.ndarray:
    return np.array([float(obj["x"]), float(obj["y"])], dtype=np.float64)


def load_frame_layouts(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    frames = data.get("metadata", {}).get("frames", [])
    if not isinstance(frames, list):
        return []

    layouts: List[dict] = []
    for item in frames:
        if not isinstance(item, dict):
            continue
        try:
            start = int(item["point_start"])
            count = int(item["point_count"])
            source_center = _metadata_point_xy(item["source_center"])
            layout_offset = _metadata_point_xy(item["layout_offset"])
        except (KeyError, TypeError, ValueError):
            continue
        if start < 0 or count <= 1:
            continue

        angle_increment = item.get("angle_increment_rad", None)
        layouts.append({
            "frame_id": int(item.get("frame_id", len(layouts) + 1)),
            "point_start": start,
            "point_count": count,
            "source_center": source_center,
            "layout_offset": layout_offset,
            "angle_increment_rad": float(angle_increment) if angle_increment is not None else None,
        })
    return layouts


def normalize(v: np.ndarray) -> np.ndarray:
    return v / (np.linalg.norm(v) + EPS)


def median(values: Sequence[float]) -> float:
    if len(values) == 0:
        return 0.0
    return float(np.median(np.asarray(values, dtype=np.float64)))


def mad(values: Sequence[float]) -> float:
    if len(values) == 0:
        return 0.0
    arr = np.asarray(values, dtype=np.float64)
    med = np.median(arr)
    return float(np.median(np.abs(arr - med)))


def fit_line_tls_core(points: np.ndarray, weights: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if len(points) == 0:
        raise ValueError("No points provided for TLS fitting.")

    if weights is None:
        weights = np.ones(len(points), dtype=np.float64)

    wsum = float(np.sum(weights))
    mu = np.sum(points * weights[:, None], axis=0) / max(wsum, EPS)
    q = points - mu
    cov = (q * weights[:, None]).T @ q / max(wsum, EPS)
    eigvals, eigvecs = np.linalg.eigh(cov)
    idx = int(np.argmax(eigvals))
    direction = normalize(eigvecs[:, idx])
    if direction[0] < 0.0 or (abs(direction[0]) < 1e-12 and direction[1] < 0.0):
        direction = -direction
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    residual = q @ normal
    return mu, direction, residual, eigvals


def fit_line_tls_huber(points: np.ndarray, huber_delta: float, huber_iters: int) -> LineFit:
    n = len(points)
    weights = np.ones(n, dtype=np.float64)

    mu = np.zeros(2, dtype=np.float64)
    direction = np.array([1.0, 0.0], dtype=np.float64)
    residual = np.zeros(n, dtype=np.float64)
    eigvals = np.zeros(2, dtype=np.float64)

    if huber_delta <= 0.0 or huber_iters <= 0:
        mu, direction, residual, eigvals = fit_line_tls_core(points)
    else:
        for _ in range(huber_iters):
            mu, direction, residual, eigvals = fit_line_tls_core(points, weights=weights)
            abs_res = np.abs(residual)
            weights = np.where(abs_res <= huber_delta, 1.0, huber_delta / (abs_res + EPS))

        mu, direction, residual, eigvals = fit_line_tls_core(points, weights=weights)

    rms = float(np.sqrt(np.mean(residual ** 2)))
    max_res = float(np.max(np.abs(residual)))
    eigvals = np.sort(eigvals)[::-1]
    lam1 = float(max(eigvals[0], 0.0))
    lam2 = float(max(eigvals[1], 0.0))
    straightness = 1.0 - lam2 / (lam1 + lam2 + EPS)
    return LineFit(mu=mu, direction=direction, rms=rms, max_res=max_res, straightness=float(straightness))


ORIGINAL_FIT_LINE_TLS_HUBER = fit_line_tls_huber


def gap_thr_m(r: float, angle_increment: float, gap0_m: float, cgap: float) -> float:
    return max(gap0_m + cgap * max(r, 0.05) * angle_increment, gap0_m * 3.0)


def mean_gap_thr_m(r: float, angle_increment: float, gap0_m: float, cmean: float) -> float:
    return max(gap0_m + cmean * max(r, 0.05) * angle_increment, gap0_m * 2.4)


def merge_gap_thr_m(r: float, angle_increment: float, merge_gap0_m: float, merge_cgap: float) -> float:
    return merge_gap0_m + merge_cgap * max(r, 0.05) * angle_increment


def merge_perp_thr_m(r: float, merge_perp_base_m: float, merge_perp_cr: float) -> float:
    return merge_perp_base_m + merge_perp_cr * max(r, 0.05)


def estimate_noise_ratio_from_points(points: np.ndarray, median_range: float, angle_increment: float) -> float:
    if len(points) < 3 or angle_increment <= 0.0:
        return 0.0
    ranges = np.linalg.norm(points, axis=1)
    radial_steps = np.abs(np.diff(ranges))
    if len(radial_steps) == 0:
        return 0.0
    exp_gap = max(median_range, 0.05) * angle_increment + 1e-6
    noise_mad = 1.4826 * mad(radial_steps)
    return float(np.clip(noise_mad / exp_gap, 0.0, 3.0))


def adaptive_min_len_m(
    median_range: float,
    noise_ratio: float,
    min_len_m: float,
    adaptive_min_len_enable: bool,
    adaptive_min_len_ref_range_m: float,
    adaptive_min_len_dist_exp: float,
    adaptive_min_len_noise_gain: float,
    adaptive_min_len_scale_min: float,
    adaptive_min_len_scale_max: float,
) -> float:
    if not adaptive_min_len_enable:
        return min_len_m
    rr = max(median_range, 0.05)
    ref_range = max(adaptive_min_len_ref_range_m, 0.05)
    dist_scale = np.power(ref_range / rr, adaptive_min_len_dist_exp)
    noise_scale = 1.0 + adaptive_min_len_noise_gain * max(0.0, noise_ratio)
    scale = np.clip(dist_scale * noise_scale, adaptive_min_len_scale_min, adaptive_min_len_scale_max)
    return float(min_len_m * scale)


def adaptive_short_feature_min_len_m(
    median_range: float,
    noise_ratio: float,
    args: argparse.Namespace,
) -> float:
    if not args.adaptive_min_len_enable:
        return args.min_len_m

    rr = max(median_range, 0.05)
    ref_range = max(args.adaptive_min_len_ref_range_m, 0.05)
    dist_scale = np.power(rr / ref_range, max(1.0, args.adaptive_min_len_dist_exp + 0.55))
    noise_scale = 1.0 + 0.01 * max(0.0, noise_ratio)
    base = args.min_len_m * dist_scale * noise_scale
    return float(np.clip(base, max(args.frag_min_len_m, 0.11), args.min_len_m * 0.96))


def short_feature_candidate_ok(
    seg: Segment,
    median_range: float,
    noise_ratio: float,
    args: argparse.Namespace,
) -> bool:
    if not args.adaptive_min_len_enable or seg.n_points < args.min_pts or seg.length >= args.min_len_m:
        return False

    short_min_len = adaptive_short_feature_min_len_m(median_range, noise_ratio, args)
    if seg.length < short_min_len:
        return False

    _, thr_rms, thr_max, _ = segment_quality_thresholds(np.array([median_range], dtype=np.float64), args)
    straight_thr = max(args.frag_straightness_min, args.straightness_min + 0.01)
    return (
        seg.rms <= thr_rms * 1.10
        and seg.max_res <= thr_max * 1.08
        and seg.straightness >= straight_thr
    )


def point_to_line_distance(point: np.ndarray, mu: np.ndarray, direction: np.ndarray) -> float:
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    return float(abs((point - mu) @ normal))


def prune_small_noise_runs(points: np.ndarray, angle_increment: float, args: argparse.Namespace) -> np.ndarray:
    if len(points) <= 2:
        return points

    keep = np.ones(len(points), dtype=bool)
    run_start = 0

    def maybe_prune(run_end: int) -> None:
        nonlocal keep, run_start
        count = run_end - run_start + 1
        if count <= 0:
            return
        if count > args.preclean_small_run_max_pts:
            return

        run_pts = points[run_start:run_end + 1]
        fit = fit_line_tls_huber(run_pts, huber_delta=0.0, huber_iters=0)
        seg_length = float(np.linalg.norm(run_pts[-1] - run_pts[0]))
        if seg_length <= args.preclean_small_run_max_len_m or fit.straightness <= args.preclean_small_run_straightness:
            keep[run_start:run_end + 1] = False

    for i in range(len(points) - 1):
        r_local = 0.5 * (np.linalg.norm(points[i]) + np.linalg.norm(points[i + 1]))
        gap = float(np.linalg.norm(points[i + 1] - points[i]))
        if gap > gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap) * args.preclean_run_gap_scale:
            maybe_prune(i)
            run_start = i + 1
    maybe_prune(len(points) - 1)

    pruned = points[keep]
    if len(pruned) >= 2:
        return pruned
    return points


def preprocess_points(points: np.ndarray, angle_increment: float, args: argparse.Namespace) -> np.ndarray:
    if not args.preclean_enable or len(points) < max(7, 2 * args.preclean_window + 3):
        return points

    filtered = points.copy()
    for _ in range(max(1, args.preclean_passes)):
        if len(filtered) < max(7, 2 * args.preclean_window + 3):
            break

        ranges = np.linalg.norm(filtered, axis=1)
        keep = np.ones(len(filtered), dtype=bool)

        for i in range(1, len(filtered) - 1):
            left = max(0, i - args.preclean_window)
            right = min(len(filtered), i + args.preclean_window + 1)
            d_prev = float(np.linalg.norm(filtered[i] - filtered[i - 1]))
            d_next = float(np.linalg.norm(filtered[i + 1] - filtered[i]))
            r_local = max(float(ranges[i]), 0.05)
            run_gap_base = gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap) * args.preclean_run_gap_scale
            if d_prev > run_gap_base:
                left = i
            if d_next > run_gap_base:
                right = i + 1

            while left < i and float(np.linalg.norm(filtered[left + 1] - filtered[left])) > run_gap_base:
                left += 1
            while right > i + 1 and float(np.linalg.norm(filtered[right - 1] - filtered[right - 2])) > run_gap_base:
                right -= 1

            if right - left < max(4, args.preclean_window + 2):
                continue

            local = filtered[left:right]
            local_idx = i - left
            neigh = np.concatenate([local[:local_idx], local[local_idx + 1:]], axis=0)
            if len(neigh) < 3:
                continue

            mu, direction, _, _ = fit_line_tls_core(neigh)
            residual = point_to_line_distance(filtered[i], mu, direction)
            local_ranges = np.linalg.norm(neigh, axis=1)
            r_med = median(local_ranges)
            gap_base = gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
            mean_gap_base = mean_gap_thr_m(r_med, angle_increment, args.gap0_m, args.cmean)
            radial_sigma = 1.4826 * mad(local_ranges)
            radial_dev = abs(float(ranges[i] - median(local_ranges)))

            isolated = (
                d_prev > gap_base * args.preclean_isolated_gap_scale
                and d_next > gap_base * args.preclean_isolated_gap_scale
            )
            bridge_break = (
                d_prev > gap_base * args.preclean_gap_scale
                or d_next > gap_base * args.preclean_gap_scale
            )
            deviated = residual > max(args.preclean_residual_abs_m, mean_gap_base * args.preclean_residual_scale)
            radial_bad = radial_dev > max(args.preclean_radial_abs_m, (radial_sigma + gap_base) * args.preclean_radial_scale)

            if isolated or (deviated and (bridge_break or radial_bad)):
                keep[i] = False

        if np.all(keep):
            break

        candidate = filtered[keep]
        if len(candidate) < 2:
            break

        candidate = prune_small_noise_runs(candidate, angle_increment, args)
        if len(candidate) == len(filtered):
            break
        filtered = candidate

    if len(filtered) >= 2:
        return filtered
    return points


def robust_refine_segment_points(
    seg_points: np.ndarray,
    huber_delta: float,
    huber_iters: int,
    args: Optional[argparse.Namespace],
) -> Tuple[np.ndarray, LineFit]:
    fit = fit_line_tls_huber(seg_points, huber_delta=huber_delta, huber_iters=huber_iters)
    if (
        args is None
        or not getattr(args, "preclean_enable", False)
        or huber_delta <= 0.0
        or huber_iters <= 0
        or fit_line_tls_huber is not ORIGINAL_FIT_LINE_TLS_HUBER
        or len(seg_points) < max(8, getattr(args, "min_pts", 8))
    ):
        return seg_points, fit

    normal = np.array([-fit.direction[1], fit.direction[0]], dtype=np.float64)
    residual = np.abs((seg_points - fit.mu) @ normal)
    med_res = float(np.median(residual))
    mad_res = 1.4826 * float(np.median(np.abs(residual - med_res)))
    keep_thr = max(0.010, med_res + 2.2 * max(mad_res, fit.rms))
    keep = residual <= keep_thr
    min_keep = max(getattr(args, "min_pts", 8), int(np.ceil(0.72 * len(seg_points))))
    if int(np.sum(keep)) < min_keep or int(np.sum(keep)) >= len(seg_points):
        return seg_points, fit

    refined_points = seg_points[keep]
    refined_fit = ORIGINAL_FIT_LINE_TLS_HUBER(refined_points, huber_delta=huber_delta, huber_iters=huber_iters)
    improved = (
        refined_fit.rms <= fit.rms * 0.90
        or refined_fit.max_res <= fit.max_res * 0.90
        or refined_fit.straightness >= fit.straightness + 0.002
    )
    if not improved:
        return seg_points, fit
    return refined_points, refined_fit


def full_feature_refine_enabled(args: Optional[argparse.Namespace]) -> bool:
    if args is None:
        return False
    return (
        getattr(args, "preclean_enable", False)
        and getattr(args, "adaptive_min_len_enable", False)
        and getattr(args, "merge_enable", False)
        and getattr(args, "global_map_merge_enable", False)
        and getattr(args, "huber_delta", 0.0) > 0.0
        and getattr(args, "huber_iters", 0) > 0
        and fit_line_tls_huber is ORIGINAL_FIT_LINE_TLS_HUBER
    )


def build_segment_from_points(
    seg_points: np.ndarray,
    idx_start: int,
    idx_end: int,
    huber_delta: float,
    huber_iters: int,
    args: Optional[argparse.Namespace] = None,
) -> Segment:
    use_points, fit = robust_refine_segment_points(seg_points, huber_delta, huber_iters, args)
    proj = (use_points - fit.mu) @ fit.direction
    p1 = fit.mu + np.min(proj) * fit.direction
    p2 = fit.mu + np.max(proj) * fit.direction
    return Segment(
        idx_start=idx_start,
        idx_end=idx_end,
        p1=p1,
        p2=p2,
        length=float(np.linalg.norm(p2 - p1)),
        rms=fit.rms,
        max_res=fit.max_res,
        straightness=fit.straightness,
        feature=float(fit.straightness * np.exp(-fit.rms / 0.02)),
        n_points=len(seg_points),
    )


def extend_high_quality_segment_support(
    points: np.ndarray,
    seg: Segment,
    angle_increment: float,
    args: argparse.Namespace,
) -> Segment:
    if not full_feature_refine_enabled(args):
        return seg
    if len(points) < 2 or seg.idx_start < 0 or seg.idx_end >= len(points):
        return seg
    if seg.length < max(args.min_len_m * 0.70, 0.18):
        return seg
    if seg.straightness < max(args.final_quality_straightness_min - 0.004, 0.996):
        return seg
    if seg.max_res > max(args.final_quality_max_res_m * 0.45, 0.020):
        return seg

    search_pad = max(args.min_pts + 14, 26)
    win_start = max(0, seg.idx_start - search_pad)
    win_end = min(len(points) - 1, seg.idx_end + search_pad)
    if win_end - win_start + 1 <= seg.n_points + 2:
        return seg

    center = 0.5 * (seg.p1 + seg.p2)
    direction = seg_dir(seg)
    normal = np.array([-direction[1], direction[0]], dtype=np.float64)
    win_idx = np.arange(win_start, win_end + 1)
    win_points = points[win_idx]
    proj = (win_points - center) @ direction
    perp = np.abs((win_points - center) @ normal)

    seg_proj = np.array([(seg.p1 - center) @ direction, (seg.p2 - center) @ direction], dtype=np.float64)
    tmin = float(np.min(seg_proj))
    tmax = float(np.max(seg_proj))
    proj_margin = float(np.clip(seg.length * 0.85 + 0.12, 0.20, 0.56))
    perp_thr = float(min(max(0.010, seg.max_res * 1.18, seg.rms * 3.0), 0.022))

    base_ranges = np.linalg.norm(points[seg.idx_start:seg.idx_end + 1], axis=1)
    r_med = median(base_ranges) if len(base_ranges) > 0 else 0.5 * (np.linalg.norm(seg.p1) + np.linalg.norm(seg.p2))
    gap_limit = max(0.055, gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap) * 2.8)

    support_mask = (
        (perp <= perp_thr)
        & (proj >= tmin - proj_margin)
        & (proj <= tmax + proj_margin)
    )
    support_idx = win_idx[support_mask]
    support_points = win_points[support_mask]
    if len(support_idx) <= seg.n_points + 2:
        return seg

    order = np.argsort(proj[support_mask])
    ordered_idx = support_idx[order]
    ordered_points = support_points[order]
    ordered_proj = proj[support_mask][order]
    keep = np.ones(len(ordered_idx), dtype=bool)
    for i in range(1, len(ordered_idx)):
        step_proj = float(abs(ordered_proj[i] - ordered_proj[i - 1]))
        step_xy = float(np.linalg.norm(ordered_points[i] - ordered_points[i - 1]))
        if step_proj > gap_limit and step_xy > gap_limit * 1.15:
            keep[i] = False

    support_idx = ordered_idx[keep]
    if len(support_idx) <= seg.n_points + 2:
        return seg

    proposal = build_segment_from_points(
        points[support_idx],
        int(support_idx[0]),
        int(support_idx[-1]),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    length_gain = proposal.length - seg.length
    if length_gain < max(0.035, seg.length * 0.12):
        return seg
    if proposal.rms > max(seg.rms * 1.45, seg.rms + 0.0035):
        return seg
    if proposal.max_res > max(seg.max_res * 1.50, seg.max_res + 0.0065):
        return seg
    if proposal.straightness < seg.straightness - 0.008:
        return seg

    proposal.id = seg.id
    proposal.feature = max(seg.feature, proposal.feature)
    proposal.is_feature = seg.is_feature
    proposal.is_fragment = seg.is_fragment
    proposal.merged_from = list(seg.merged_from)
    return proposal


def extract_endpoint_branch_candidates(
    run_points: np.ndarray,
    indices: np.ndarray,
    seg_start: int,
    seg_end: int,
    parent_seg: Segment,
    args: argparse.Namespace,
) -> List[Segment]:
    if seg_end - seg_start + 1 < max(args.frag_min_pts + 1, 4):
        return []

    branch_candidates: List[Segment] = []
    parent_dir = seg_dir(parent_seg)
    max_window = min(seg_end - seg_start + 1, max(args.frag_min_pts + 10, args.min_pts + 2))
    min_window = max(3, args.frag_min_pts)

    def try_side(side: str) -> Optional[Segment]:
        best_branch: Optional[Segment] = None
        best_score: Optional[Tuple[float, float, float]] = None

        for win in range(min_window, max_window + 1):
            if side == "left":
                sub_start = seg_start
                sub_end = seg_start + win - 1
                attach_point = parent_seg.p1
            else:
                sub_start = seg_end - win + 1
                sub_end = seg_end
                attach_point = parent_seg.p2

            if sub_start < seg_start or sub_end > seg_end or sub_end - sub_start + 1 < min_window:
                continue

            sub_points = run_points[sub_start:sub_end + 1]
            branch = build_segment_from_points(
                sub_points,
                int(indices[sub_start]),
                int(indices[sub_end]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            branch.is_fragment = True
            branch.is_feature = False

            branch_dir = seg_dir(branch)
            angle_deg = float(np.degrees(np.arccos(np.clip(abs(parent_dir @ branch_dir), -1.0, 1.0))))
            endpoint_attach = min(
                float(np.linalg.norm(branch.p1 - attach_point)),
                float(np.linalg.norm(branch.p2 - attach_point)),
            )

            if not (45.0 <= angle_deg <= 135.0):
                continue
            if branch.length < args.frag_min_len_m or branch.n_points < min_window:
                continue
            if branch.straightness < max(0.94, args.frag_straightness_min - 0.05):
                continue
            if branch.rms > (args.rms_a + args.rms_b * median(np.linalg.norm(sub_points, axis=1))) * 1.9:
                continue
            if endpoint_attach > max(args.merge_gap0_m * 1.6, 0.22):
                continue

            score = (branch.length, -abs(angle_deg - 90.0), branch.straightness, -branch.rms)
            if best_score is None or score > best_score:
                best_branch = branch
                best_score = score

        return best_branch

    left_branch = try_side("left")
    right_branch = try_side("right")
    if left_branch is not None:
        branch_candidates.append(left_branch)
    if right_branch is not None:
        branch_candidates.append(right_branch)
    return branch_candidates


def extend_branch_with_run_context(
    run_points: np.ndarray,
    indices: np.ndarray,
    seed_start: int,
    seed_end: int,
    search_start: int,
    search_end: int,
    attach_point: np.ndarray,
    parent_dir: np.ndarray,
    args: argparse.Namespace,
) -> Segment:
    seed_points = run_points[seed_start:seed_end + 1]
    seed_branch = build_segment_from_points(
        seed_points,
        int(indices[seed_start]),
        int(indices[seed_end]),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )

    if search_start > search_end:
        return seed_branch

    window_points = run_points[search_start:search_end + 1]
    window_indices = indices[search_start:search_end + 1]
    if len(window_points) < len(seed_points):
        return seed_branch

    branch_dir = seg_dir(seed_branch)
    normal = np.array([-branch_dir[1], branch_dir[0]], dtype=np.float64)
    origin = seed_branch.p1

    proj = (window_points - origin) @ branch_dir
    perp = np.abs((window_points - origin) @ normal)
    seed_proj = (seed_points - origin) @ branch_dir
    seed_lo = float(np.min(seed_proj))
    seed_hi = float(np.max(seed_proj))
    attach_proj = float((attach_point - origin) @ branch_dir)

    median_range = median(np.linalg.norm(seed_points, axis=1))
    perp_thr = max(merge_perp_thr_m(median_range, args.merge_perp_base_m, args.merge_perp_cr) * 2.5, 0.07)
    proj_gap = max(args.merge_gap0_m * 2.1, 0.15)
    back_tol = max(args.merge_gap0_m * 1.0, 0.06)

    keep = perp <= perp_thr
    if not np.any(keep):
        return seed_branch

    attach_on_low = abs(attach_proj - seed_lo) <= abs(attach_proj - seed_hi)
    lo = seed_lo
    hi = seed_hi

    for _ in range(16):
        if attach_on_low:
            candidate = keep & (proj >= seed_lo - back_tol) & (proj <= hi + proj_gap)
            if not np.any(candidate):
                break
            new_hi = float(np.max(proj[candidate]))
            if new_hi <= hi + 1e-6:
                break
            hi = new_hi
        else:
            candidate = keep & (proj >= lo - proj_gap) & (proj <= seed_hi + back_tol)
            if not np.any(candidate):
                break
            new_lo = float(np.min(proj[candidate]))
            if new_lo >= lo - 1e-6:
                break
            lo = new_lo

    if attach_on_low:
        candidate = keep & (proj >= seed_lo - back_tol) & (proj <= hi + 1e-9)
    else:
        candidate = keep & (proj >= lo - 1e-9) & (proj <= seed_hi + back_tol)

    selected_points = window_points[candidate]
    selected_indices = window_indices[candidate]
    if len(selected_points) <= len(seed_points):
        return seed_branch

    extended = build_segment_from_points(
        selected_points,
        int(np.min(selected_indices)),
        int(np.max(selected_indices)),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )

    angle_deg = float(np.degrees(np.arccos(np.clip(abs(seg_dir(extended) @ parent_dir), -1.0, 1.0))))
    attach_dist = min(
        float(np.linalg.norm(extended.p1 - attach_point)),
        float(np.linalg.norm(extended.p2 - attach_point)),
    )

    if not (45.0 <= angle_deg <= 135.0):
        return seed_branch
    if extended.straightness < max(0.90, args.frag_straightness_min - 0.09):
        return seed_branch
    if extended.rms > (args.rms_a + args.rms_b * median(np.linalg.norm(selected_points, axis=1))) * 2.4:
        return seed_branch
    if attach_dist > max(args.merge_gap0_m * 2.2, 0.28):
        return seed_branch
    if extended.length <= seed_branch.length + 0.01:
        return seed_branch

    extended.is_fragment = True
    extended.is_feature = False
    return extended


def split_corner_branches_from_segment(
    run_points: np.ndarray,
    indices: np.ndarray,
    seg_start: int,
    seg_end: int,
    parent_seg: Segment,
    args: argparse.Namespace,
) -> List[Segment]:
    if seg_end - seg_start + 1 < max(args.min_pts, 6):
        return []

    parent_dir = seg_dir(parent_seg)
    min_branch_pts = max(3, args.frag_min_pts - 1)
    max_branch_pts = min(max(args.frag_min_pts + 30, args.min_pts + 12), seg_end - seg_start)
    branch_candidates: List[Segment] = []

    def try_side(side: str) -> Optional[Segment]:
        best_branch: Optional[Segment] = None
        best_score: Optional[Tuple[float, float, float]] = None

        for branch_pts in range(min_branch_pts, max_branch_pts + 1):
            if side == "left":
                branch_start = seg_start
                branch_end = seg_start + branch_pts - 1
                trunk_start = branch_end
                trunk_end = seg_end
                attach_point = run_points[branch_end]
                search_start = max(0, seg_start - max(args.min_pts + 20, 52))
                search_end = min(len(run_points) - 1, branch_end + 5)
            else:
                branch_start = seg_end - branch_pts + 1
                branch_end = seg_end
                trunk_start = seg_start
                trunk_end = branch_start
                attach_point = run_points[branch_start]
                search_start = max(0, branch_start - 8)
                search_end = min(len(run_points) - 1, seg_end + max(args.min_pts + 30, 68))

            if branch_start < seg_start or branch_end > seg_end:
                continue
            if trunk_end - trunk_start + 1 < max(args.min_pts // 2, 4):
                continue

            branch_points = run_points[branch_start:branch_end + 1]
            trunk_points = run_points[trunk_start:trunk_end + 1]
            seed_branch = build_segment_from_points(
                branch_points,
                int(indices[branch_start]),
                int(indices[branch_end]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            seed_dir = seg_dir(seed_branch)
            parent_is_vertical = abs(parent_dir[1]) >= 0.9
            seed_is_horizontal = abs(seed_dir[0]) >= 0.94
            if side == "left" and parent_is_vertical and seed_is_horizontal:
                search_start = max(0, search_start - args.corner_branch_left_lookback_extra)
                search_end = min(len(run_points) - 1, search_end + 1)

            branch = seed_branch
            branch = extend_branch_with_run_context(
                run_points,
                indices,
                branch_start,
                branch_end,
                search_start,
                search_end,
                attach_point,
                parent_dir,
                args,
            )
            trunk = build_segment_from_points(
                trunk_points,
                int(indices[trunk_start]),
                int(indices[trunk_end]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )

            branch_dir = seg_dir(branch)
            trunk_dir = seg_dir(trunk)
            angle_deg = float(np.degrees(np.arccos(np.clip(abs(branch_dir @ trunk_dir), -1.0, 1.0))))
            attach_dist = min(
                float(np.linalg.norm(branch.p1 - attach_point)),
                float(np.linalg.norm(branch.p2 - attach_point)),
            )

            if not (45.0 <= angle_deg <= 135.0):
                continue
            if branch.length < max(args.frag_min_len_m, 0.04):
                continue
            if branch.n_points < min_branch_pts:
                continue
            if branch.straightness < max(0.93, args.frag_straightness_min - 0.06):
                continue
            if trunk.straightness < max(args.straightness_min - 0.07, 0.90):
                continue
            if attach_dist > 0.22:
                continue

            branch.is_fragment = True
            branch.is_feature = False
            score = (branch.length, -abs(angle_deg - 90.0), branch.straightness - branch.rms)
            if best_score is None or score > best_score:
                best_branch = branch
                best_score = score

        return best_branch

    left_branch = try_side("left")
    right_branch = try_side("right")
    if left_branch is not None:
        branch_candidates.append(left_branch)
    if right_branch is not None:
        branch_candidates.append(right_branch)
    return branch_candidates


def segment_quality_thresholds(seg_ranges: np.ndarray, args: argparse.Namespace) -> Tuple[float, float, float, float]:
    med_r = median(seg_ranges)
    thr_rms = args.rms_a + args.rms_b * med_r
    thr_max = args.max_a + args.max_b * med_r
    straight_thr = args.straightness_min - np.clip(args.grow_straightness_relax, 0.0, 0.20)
    return med_r, thr_rms, thr_max, straight_thr


def extend_segment_in_run(
    run_points: np.ndarray,
    start: int,
    end: int,
    angle_increment: float,
    args: argparse.Namespace,
) -> Tuple[int, int]:
    if start < 0 or end >= len(run_points) or start >= end:
        return start, end

    rms_relax = max(1.0, args.grow_rms_relax) * 1.15
    max_relax = max(1.0, args.grow_max_relax) * 1.20
    straight_bonus = 0.015
    gap_relax = 1.18
    bridge_steps = 5

    changed = True
    while changed:
        changed = False
        for side in ("left", "right"):
            best_candidate: Optional[Tuple[int, int]] = None
            best_score: Optional[Tuple[int, float]] = None

            for step in range(1, bridge_steps + 1):
                cand_start = start - step if side == "left" else start
                cand_end = end if side == "left" else end + step
                if cand_start < 0 or cand_end >= len(run_points):
                    continue

                boundary_a = run_points[cand_start]
                boundary_b = run_points[cand_start + 1] if side == "left" else run_points[cand_end - 1]
                r_local = 0.5 * (np.linalg.norm(boundary_a) + np.linalg.norm(boundary_b))
                gap = float(np.linalg.norm(boundary_a - boundary_b))
                if gap > gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap) * gap_relax * max(1.0, step * 0.9):
                    continue

                seg_points = run_points[cand_start:cand_end + 1]
                seg_ranges = np.linalg.norm(seg_points, axis=1)
                med_r, thr_rms, thr_max, straight_thr = segment_quality_thresholds(seg_ranges, args)

                dif = np.linalg.norm(np.diff(seg_points, axis=0), axis=1) if len(seg_points) >= 2 else np.array([])
                if len(dif) == 0:
                    continue
                if (
                    float(np.mean(dif)) > mean_gap_thr_m(med_r, angle_increment, args.gap0_m, args.cmean) * gap_relax * max(1.0, step * 0.9)
                    or float(np.max(dif)) > gap_thr_m(med_r, angle_increment, args.gap0_m, args.cgap) * gap_relax * max(1.0, step * 1.2)
                ):
                    continue

                fit = fit_line_tls_huber(seg_points, args.huber_delta, args.huber_iters)
                if (
                    fit.rms > thr_rms * rms_relax
                    or fit.max_res > thr_max * max_relax * max(1.0, step * 1.15)
                    or fit.straightness < (straight_thr - straight_bonus)
                ):
                    continue

                candidate_score = (cand_end - cand_start + 1, fit.straightness - fit.rms)
                if best_score is None or candidate_score > best_score:
                    best_candidate = (cand_start, cand_end)
                    best_score = candidate_score

            if best_candidate is not None:
                start, end = best_candidate
                changed = True
    return start, end


def build_candidate_from_window(
    run_points: np.ndarray,
    indices: np.ndarray,
    r_all: np.ndarray,
    start: int,
    end: int,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[Segment]:
    if start < 0 or end >= len(run_points) or end - start + 1 <= 1:
        return None

    seg_points = run_points[start:end + 1]
    dif = np.linalg.norm(np.diff(seg_points, axis=0), axis=1) if len(seg_points) >= 2 else np.array([])
    if len(dif) == 0:
        return None

    r_med = median(r_all[start:end + 1])
    mean_gap = float(np.mean(dif))
    max_gap = float(np.max(dif))
    if (
        mean_gap > mean_gap_thr_m(r_med, angle_increment, args.gap0_m, args.cmean)
        or max_gap > gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
    ):
        return None

    seg = build_segment_from_points(
        seg_points,
        int(indices[start]),
        int(indices[end]),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    noise_ratio = estimate_noise_ratio_from_points(seg_points, r_med, angle_increment)
    min_len_local = adaptive_min_len_m(
        median_range=r_med,
        noise_ratio=noise_ratio,
        min_len_m=args.min_len_m,
        adaptive_min_len_enable=args.adaptive_min_len_enable,
        adaptive_min_len_ref_range_m=args.adaptive_min_len_ref_range_m,
        adaptive_min_len_dist_exp=args.adaptive_min_len_dist_exp,
        adaptive_min_len_noise_gain=args.adaptive_min_len_noise_gain,
        adaptive_min_len_scale_min=args.adaptive_min_len_scale_min,
        adaptive_min_len_scale_max=args.adaptive_min_len_scale_max,
    )

    seg.is_feature = seg.n_points >= args.min_pts and (
        seg.length >= min_len_local or short_feature_candidate_ok(seg, r_med, noise_ratio, args)
    )
    seg.is_fragment = False
    if (
        args.frag_enable
        and seg.n_points >= args.frag_min_pts
        and seg.length >= args.frag_min_len_m
        and seg.straightness >= args.frag_straightness_min
    ):
        seg.feature = float(seg.straightness * np.exp(-seg.rms / args.frag_rms_scale))
        seg.is_fragment = True

    if not (seg.is_feature or seg.is_fragment):
        return None
    return seg


def extract_candidates_from_run(
    run_points: np.ndarray,
    indices: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> List[Segment]:
    candidates: List[Segment] = []
    min_pts = args.min_pts
    frag_enable = args.frag_enable
    frag_min_pts = args.frag_min_pts
    grow_min_pts = frag_min_pts if frag_enable else min_pts

    r_all = np.linalg.norm(run_points, axis=1)
    n = len(run_points)
    j = 0

    while j < n - 1:
        i = j
        accepted = False

        while i + 1 < n:
            r_local = 0.5 * (r_all[i] + r_all[i + 1])
            gap = float(np.linalg.norm(run_points[i + 1] - run_points[i]))
            if gap > gap_thr_m(r_local, angle_increment, args.gap0_m, args.cgap):
                break

            i += 1
            if i - j + 1 >= grow_min_pts:
                seg_points = run_points[j:i + 1]
                fit = fit_line_tls_huber(seg_points, args.huber_delta, args.huber_iters)
                med_r = median(r_all[j:i + 1])
                thr_rms = args.rms_a + args.rms_b * med_r
                thr_max = args.max_a + args.max_b * med_r

                if (
                    fit.rms > thr_rms * max(1.0, args.grow_rms_relax)
                    or fit.max_res > thr_max * max(1.0, args.grow_max_relax)
                    or fit.straightness < (args.straightness_min - np.clip(args.grow_straightness_relax, 0.0, 0.20))
                ):
                    i -= 1
                    break

        end = i
        if end - j + 1 >= grow_min_pts:
            ext_start, ext_end = extend_segment_in_run(run_points, j, end, angle_increment, args)
            trial_windows = [(ext_start, ext_end)]
            if (j, end) != (ext_start, ext_end):
                trial_windows.append((j, end))

            best_seg: Optional[Segment] = None
            best_window: Optional[Tuple[int, int]] = None
            best_score: Optional[Tuple[int, int, float, float, float]] = None
            for cand_start, cand_end in trial_windows:
                seg = build_candidate_from_window(run_points, indices, r_all, cand_start, cand_end, angle_increment, args)
                if seg is None:
                    continue
                score = (int(seg.is_feature), int(seg.is_fragment), seg.length, seg.straightness, -seg.rms)
                if best_score is None or score > best_score:
                    best_seg = seg
                    best_window = (cand_start, cand_end)
                    best_score = score

            if best_seg is not None and best_window is not None:
                win_start, win_end = best_window
                candidates.append(best_seg)
                accepted = True
                candidates.extend(
                    extract_endpoint_branch_candidates(
                        run_points,
                        indices,
                        win_start,
                        win_end,
                        best_seg,
                        args,
                    )
                )
                candidates.extend(
                    split_corner_branches_from_segment(
                        run_points,
                        indices,
                        win_start,
                        win_end,
                        best_seg,
                        args,
                    )
                )

        if accepted:
            j = end + 1
        else:
            j += 1

    candidates.sort(key=lambda s: (s.idx_start, s.idx_end))
    return candidates


def extract_all_candidates(points: np.ndarray, angle_increment: float, args: argparse.Namespace) -> List[Segment]:
    indices = np.arange(len(points), dtype=np.int64)
    if len(indices) == 0:
        return []

    runs: List[Tuple[int, int]] = []
    s = int(indices[0])
    p = int(indices[0])
    for ii in indices[1:]:
        ii = int(ii)
        if ii == p + 1:
            p = ii
        else:
            runs.append((s, p))
            s = ii
            p = ii
    runs.append((s, p))

    all_candidates: List[Segment] = []
    for rs, re in runs:
        run_points = points[rs:re + 1]
        run_indices = indices[rs:re + 1]
        all_candidates.extend(extract_candidates_from_run(run_points, run_indices, angle_increment, args))

    all_candidates.sort(key=lambda s: (s.idx_start, s.idx_end))
    return all_candidates


def seg_dir(seg: Segment) -> np.ndarray:
    return normalize(seg.p2 - seg.p1)


def segment_midpoint(seg: Segment) -> np.ndarray:
    return 0.5 * (seg.p1 + seg.p2)


def segment_mid_angle_deg(seg: Segment) -> float:
    mid = segment_midpoint(seg)
    return float(np.degrees(np.mod(np.arctan2(mid[1], mid[0]), 2.0 * np.pi)))


def segment_midpoint_distance(seg1: Segment, seg2: Segment) -> float:
    return float(np.linalg.norm(segment_midpoint(seg1) - segment_midpoint(seg2)))


def segment_included_angle_deg(seg1: Segment, seg2: Segment) -> float:
    d1 = seg_dir(seg1)
    d2 = seg_dir(seg2)
    dot = float(np.clip(abs(d1 @ d2), -1.0, 1.0))
    return float(np.degrees(np.arccos(dot)))


def segment_endpoint_min_distance(seg1: Segment, seg2: Segment) -> float:
    distances = (
        np.linalg.norm(seg1.p1 - seg2.p1),
        np.linalg.norm(seg1.p1 - seg2.p2),
        np.linalg.norm(seg1.p2 - seg2.p1),
        np.linalg.norm(seg1.p2 - seg2.p2),
    )
    return float(min(distances))


def support_overlap_ratio(seg1: Segment, seg2: Segment) -> float:
    lo = max(seg1.idx_start, seg2.idx_start)
    hi = min(seg1.idx_end, seg2.idx_end)
    if hi < lo:
        return 0.0
    overlap = hi - lo + 1
    shorter = max(1, min(seg1.idx_end - seg1.idx_start + 1, seg2.idx_end - seg2.idx_start + 1))
    return float(overlap / shorter)


def segment_endpoint_to_endpoint_distance(seg1: Segment, seg2: Segment) -> float:
    return segment_endpoint_min_distance(seg1, seg2)


def segment_support_axis_distance(seg1: Segment, seg2: Segment) -> float:
    d1 = seg_dir(seg1)
    d2 = seg_dir(seg2)

    axis = d1 if abs(d1 @ d2) >= 0.0 else -d1
    origin = segment_midpoint(seg1)

    proj1 = sorted((float((seg1.p1 - origin) @ axis), float((seg1.p2 - origin) @ axis)))
    proj2 = sorted((float((seg2.p1 - origin) @ axis), float((seg2.p2 - origin) @ axis)))

    if proj1[1] < proj2[0]:
        return proj2[0] - proj1[1]
    if proj2[1] < proj1[0]:
        return proj1[0] - proj2[1]
    return 0.0


def sort_segments_by_mid_angle(segments: List[Segment]) -> List[Segment]:
    segments.sort(key=lambda s: (segment_mid_angle_deg(s), s.idx_start, s.idx_end))
    for idx, seg in enumerate(segments, start=1):
        seg.id = idx
    return segments


def is_better_segment_for_dedup(lhs: Segment, rhs: Segment) -> bool:
    if abs(lhs.straightness - rhs.straightness) > 1e-9:
        return lhs.straightness > rhs.straightness
    if abs(lhs.rms - rhs.rms) > 1e-9:
        return lhs.rms < rhs.rms
    if abs(lhs.max_res - rhs.max_res) > 1e-9:
        return lhs.max_res < rhs.max_res
    if abs(lhs.length - rhs.length) > 1e-9:
        return lhs.length > rhs.length
    return lhs.n_points >= rhs.n_points


def deduplicate_segments(segments: List[Segment]) -> List[Segment]:
    if len(segments) <= 1:
        return segments

    removed = [False] * len(segments)
    for i in range(len(segments)):
        if removed[i]:
            continue
        for j in range(i + 1, len(segments)):
            if removed[j]:
                continue
            angle_deg = segment_included_angle_deg(segments[i], segments[j])
            midpoint_dist = segment_midpoint_distance(segments[i], segments[j])
            # A contained subsegment can have a distant midpoint while reusing
            # the same scan support. Do not retain it as a second feature.
            same_support = (
                support_overlap_ratio(segments[i], segments[j]) >= 0.90
                and segment_normal_offset(segments[i], segments[j]) <= 0.02
            )
            if angle_deg >= 10.0 or (midpoint_dist >= 0.15 and not same_support):
                continue

            support_gap = segment_support_axis_distance(segments[i], segments[j])
            if support_gap > 0.05:
                continue

            if is_better_segment_for_dedup(segments[j], segments[i]):
                removed[i] = True
                break
            removed[j] = True

    deduped = [seg for seg, flag in zip(segments, removed) if not flag]
    deduped.sort(key=lambda s: (s.idx_start, s.idx_end))
    for idx, seg in enumerate(deduped, start=1):
        seg.id = idx
    return deduped


def try_merge_two_segments(
    seg1: Segment,
    seg2: Segment,
    points: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[Segment]:
    idx_gap = seg2.idx_start - seg1.idx_end
    if idx_gap < 0 or idx_gap > args.merge_max_index_gap:
        return None

    p1a = seg1.p1.copy()
    p1b = seg1.p2.copy()
    p2a = seg2.p1.copy()
    p2b = seg2.p2.copy()

    d1 = seg_dir(seg1)
    d2 = seg_dir(seg2)

    merge_scale = 1.0
    if args.adaptive_merge_enable:
        ref_range = max(args.adaptive_merge_ref_range_m, 0.05)
        r_mid = 0.5 * (np.linalg.norm(p1b) + np.linalg.norm(p2a))
        dist_ratio = float(np.clip(r_mid / ref_range, 0.5, 4.0))

        lo = max(seg1.idx_start, seg1.idx_end - 2)
        hi = min(seg2.idx_end, seg2.idx_start + 2)
        boundary_points = points[lo:hi + 1] if hi >= lo else np.empty((0, 2), dtype=np.float64)
        noise_ratio = estimate_noise_ratio_from_points(boundary_points, max(r_mid, 0.05), angle_increment)

        merge_scale = float(np.clip(
            1.0 + args.adaptive_merge_dist_gain * max(0.0, dist_ratio - 1.0) + args.adaptive_merge_noise_gain * noise_ratio,
            args.adaptive_merge_scale_min,
            args.adaptive_merge_scale_max,
        ))

    cos_thr = float(np.cos(np.deg2rad(args.merge_angle_deg * merge_scale * max(1.0, args.merge_relax_factor))))
    dot = float(d1 @ d2)
    if abs(dot) < cos_thr:
        return None

    if dot < 0.0:
        d2 = -d2
        p2a, p2b = p2b, p2a

    r_ref = 0.25 * (np.linalg.norm(p1a) + np.linalg.norm(p1b) + np.linalg.norm(p2a) + np.linalg.norm(p2b))
    mid2 = 0.5 * (p2a + p2b)
    n1 = np.array([-d1[1], d1[0]], dtype=np.float64)
    perp_dist = abs(float((mid2 - p1a) @ n1))
    if perp_dist > merge_perp_thr_m(r_ref, args.merge_perp_base_m, args.merge_perp_cr) * merge_scale * max(1.0, args.merge_relax_factor):
        return None

    t1a = float(p1a @ d1)
    t1b = float(p1b @ d1)
    end1 = p1a if t1a > t1b else p1b

    t2a = float(p2a @ d1)
    t2b = float(p2b @ d1)
    start2 = p2a if t2a < t2b else p2b

    gap_along = max(0.0, float((start2 - end1) @ d1))
    if gap_along > merge_gap_thr_m(r_ref, angle_increment, args.merge_gap0_m, args.merge_cgap) * merge_scale * max(1.0, args.merge_relax_factor):
        return None

    merged_points = points[seg1.idx_start:seg2.idx_end + 1]
    if len(merged_points) < args.merge_min_pts:
        return None

    merged = build_segment_from_points(merged_points, seg1.idx_start, seg2.idx_end, args.huber_delta, args.huber_iters, args=args)
    if merged.length < 0.03:
        return None
    # Reject a poor merge before it consumes valid source candidates. Filtering
    # only the merged output cannot recover the original wall boundaries.
    if args.final_quality_enable and not segment_fit_passes_final_quality(merged, args):
        return None

    dif = np.linalg.norm(np.diff(merged_points, axis=0), axis=1) if len(merged_points) >= 2 else np.array([])
    if len(dif) > 0:
        max_allowed = 2.0 * merge_gap_thr_m(r_ref, angle_increment, args.merge_gap0_m, args.merge_cgap) * merge_scale * max(1.0, args.merge_relax_factor)
        if float(np.max(dif)) > max_allowed:
            return None

    ranges = np.linalg.norm(merged_points, axis=1)
    r_med = median(ranges) if len(ranges) > 0 else max(r_ref, 0.05)
    noise_ratio = estimate_noise_ratio_from_points(merged_points, r_med, angle_increment)
    min_len_local = adaptive_min_len_m(
        median_range=r_med,
        noise_ratio=noise_ratio,
        min_len_m=args.min_len_m,
        adaptive_min_len_enable=args.adaptive_min_len_enable,
        adaptive_min_len_ref_range_m=args.adaptive_min_len_ref_range_m,
        adaptive_min_len_dist_exp=args.adaptive_min_len_dist_exp,
        adaptive_min_len_noise_gain=args.adaptive_min_len_noise_gain,
        adaptive_min_len_scale_min=args.adaptive_min_len_scale_min,
        adaptive_min_len_scale_max=args.adaptive_min_len_scale_max,
    )

    merged.is_feature = merged.n_points >= args.min_pts and merged.length >= min_len_local
    merged.is_fragment = not merged.is_feature
    merged.merged_from = [(seg1.idx_start, seg1.idx_end), (seg2.idx_start, seg2.idx_end)]
    return merged


def merge_and_extend_candidates(points: np.ndarray, candidates: List[Segment], angle_increment: float, args: argparse.Namespace) -> List[Segment]:
    if not candidates:
        return []

    cand = sorted(candidates, key=lambda s: (s.idx_start, s.idx_end))
    merged: List[Segment] = []
    i = 0

    while i < len(cand):
        cur = cand[i]
        j = i + 1
        changed = False

        while j < len(cand):
            if cand[j].idx_start - cur.idx_end > args.merge_max_index_gap:
                break
            merged_candidate = try_merge_two_segments(cur, cand[j], points, angle_increment, args)
            if merged_candidate is not None:
                cur = merged_candidate
                changed = True
            j += 1

        merged.append(cur)

        if changed:
            k = i + 1
            while k < len(cand) and cand[k].idx_start <= cur.idx_end:
                k += 1
            i = k
        else:
            i += 1

    features: List[Segment] = []
    next_id = 1
    for seg in merged:
        if seg.is_feature:
            seg.id = next_id
            next_id += 1
            features.append(seg)

    features.sort(key=lambda s: (s.idx_start, s.idx_end))
    return features


def recover_salient_fragments(candidates: List[Segment], features: List[Segment], args: argparse.Namespace) -> List[Segment]:
    if not candidates:
        return features

    recovered = list(features)
    min_promoted_length = max(args.frag_min_len_m, min(args.min_len_m * 0.85, args.min_len_m - 0.01))
    min_promoted_points = max(args.frag_min_pts, args.min_pts // 2)
    corner_attach_thr = max(args.merge_gap0_m * 1.5, 0.12)
    orthogonal_attach_thr = max(args.merge_gap0_m * 1.2, 0.12)
    corner_branch_min_length = max(args.frag_min_len_m, min(args.min_len_m * 0.30, 0.07))
    corner_branch_min_points = max(3, args.frag_min_pts - 1)
    promoted_branch_min_length = max(corner_branch_min_length, min(args.min_len_m * 0.80, 0.16))

    fragment_pool = [
        seg for seg in candidates
        if seg.is_fragment and not seg.is_feature and seg.length >= corner_branch_min_length and seg.n_points >= corner_branch_min_points
    ]
    fragment_pool.sort(key=lambda s: (-s.straightness, s.rms, -s.length, -s.n_points))

    for frag in fragment_pool:
        duplicate = False
        attached_to_corner = False
        orthogonal_corner_branch = False

        for ref in recovered:
            if segment_included_angle_deg(frag, ref) < 10.0 and segment_midpoint_distance(frag, ref) < 0.15:
                if segment_support_axis_distance(frag, ref) <= 0.05:
                    duplicate = True
                    break
            angle_deg = segment_included_angle_deg(frag, ref)
            if support_overlap_ratio(frag, ref) > 0.75 and angle_deg < 12.0:
                duplicate = True
                break
            if segment_endpoint_min_distance(frag, ref) <= corner_attach_thr:
                attached_to_corner = True
            if 55.0 <= angle_deg <= 125.0 and segment_endpoint_to_endpoint_distance(frag, ref) <= orthogonal_attach_thr:
                orthogonal_corner_branch = True

        if duplicate:
            continue

        frag_range = 0.5 * (np.linalg.norm(frag.p1) + np.linalg.norm(frag.p2))
        strong_fragment = frag.length >= min_promoted_length and frag.n_points >= min_promoted_points
        short_feature_ok = short_feature_candidate_ok(frag, frag_range, 0.0, args)
        branch_ok = (
            orthogonal_corner_branch
            and frag.length >= promoted_branch_min_length
            and frag.n_points >= corner_branch_min_points
            and frag.straightness >= max(0.95, args.frag_straightness_min - 0.04, args.straightness_min - 0.04)
        )
        if (strong_fragment and (attached_to_corner or frag.length >= args.min_len_m)) or short_feature_ok:
            frag.is_feature = True
            frag.is_fragment = False
            recovered.append(frag)
            continue

        if branch_ok:
            frag.is_feature = True
            frag.is_fragment = False
            recovered.append(frag)

    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def segment_is_duplicate_like(candidate: Segment, refs: Sequence[Segment]) -> bool:
    for ref in refs:
        angle_deg = segment_included_angle_deg(candidate, ref)
        if angle_deg >= 10.0:
            continue
        if support_overlap_ratio(candidate, ref) > 0.60:
            return True
        if (
            segment_midpoint_distance(candidate, ref) < 0.15
            and segment_support_axis_distance(candidate, ref) <= 0.05
        ):
            return True
    return False


def segment_normal_offset(seg1: Segment, seg2: Segment) -> float:
    d = seg_dir(seg1)
    n = np.array([-d[1], d[0]], dtype=np.float64)
    c1 = 0.5 * (seg1.p1 + seg1.p2)
    c2 = 0.5 * (seg2.p1 + seg2.p2)
    return float(abs((c2 - c1) @ n))


def recover_collinear_corner_fragments(
    points: np.ndarray,
    candidates: Sequence[Segment],
    refs: Sequence[Segment],
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.corner_fragment_recover_enable:
        return []

    pool = [
        seg for seg in candidates
        if seg.length >= args.corner_fragment_seed_min_len_m
        and seg.n_points >= args.corner_fragment_seed_min_pts
        and seg.straightness >= args.corner_fragment_seed_straightness_min
    ]
    pool.sort(key=lambda s: (s.idx_start, s.idx_end))

    recovered: List[Segment] = []
    for i in range(len(pool)):
        for j in range(i + 1, len(pool)):
            s1, s2 = pool[i], pool[j]
            if s2.idx_start < s1.idx_start:
                s1, s2 = s2, s1

            idx_gap = s2.idx_start - s1.idx_end
            if idx_gap < 0 or idx_gap > args.corner_fragment_max_index_gap:
                continue
            if segment_included_angle_deg(s1, s2) > args.corner_fragment_angle_deg:
                continue
            if segment_normal_offset(s1, s2) > args.corner_fragment_normal_offset_m:
                continue
            if segment_endpoint_to_endpoint_distance(s1, s2) > args.corner_fragment_endpoint_gap_m:
                continue

            seed_idx = np.unique(np.concatenate([
                np.arange(s1.idx_start, s1.idx_end + 1),
                np.arange(s2.idx_start, s2.idx_end + 1),
            ]))
            if len(seed_idx) < args.min_pts:
                continue

            seed = build_segment_from_points(
                points[seed_idx],
                int(seed_idx[0]),
                int(seed_idx[-1]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            direction = seg_dir(seed)
            normal = np.array([-direction[1], direction[0]], dtype=np.float64)
            center = 0.5 * (seed.p1 + seed.p2)
            seed_proj = (points[seed_idx] - center) @ direction
            tmin, tmax = float(np.min(seed_proj)), float(np.max(seed_proj))

            win_start = max(0, int(seed_idx[0]) - args.corner_fragment_context_pts)
            win_end = min(len(points) - 1, int(seed_idx[-1]) + args.corner_fragment_context_pts)
            win_idx = np.arange(win_start, win_end + 1)
            win_points = points[win_idx]
            residual = np.abs((win_points - center) @ normal)
            proj = (win_points - center) @ direction

            support = win_idx[
                (residual <= args.corner_fragment_collect_dist_m)
                & (proj >= tmin - args.corner_fragment_projection_margin_m)
                & (proj <= tmax + args.corner_fragment_projection_margin_m)
            ]
            if len(support) < args.min_pts:
                continue

            for _ in range(max(1, args.corner_fragment_refine_iters)):
                proposal = build_segment_from_points(
                    points[support],
                    int(support[0]),
                    int(support[-1]),
                    args.huber_delta,
                    args.huber_iters,
                    args=args,
                )
                direction = seg_dir(proposal)
                normal = np.array([-direction[1], direction[0]], dtype=np.float64)
                center = 0.5 * (proposal.p1 + proposal.p2)
                residual = np.abs((points[support] - center) @ normal)
                refined = support[residual <= args.corner_fragment_refine_dist_m]
                if len(refined) < args.min_pts:
                    break
                if len(refined) == len(support):
                    support = refined
                    break
                support = refined

            proposal = build_segment_from_points(
                points[support],
                int(support[0]),
                int(support[-1]),
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            proposal.is_fragment = False
            proposal.is_feature = True

            if proposal.length < args.corner_fragment_min_len_m:
                continue
            if proposal.n_points < args.min_pts:
                continue
            if proposal.rms > args.final_quality_rms_m:
                continue
            if proposal.max_res > args.final_quality_max_res_m:
                continue
            if proposal.straightness < args.corner_fragment_straightness_min:
                continue
            if segment_is_duplicate_like(proposal, refs) or segment_is_duplicate_like(proposal, recovered):
                continue

            recovered.append(proposal)

    return recovered


def recover_dense_vertical_runs(
    points: np.ndarray,
    refs: Sequence[Segment],
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.dense_vertical_recover_enable or len(points) < args.dense_vertical_min_pts:
        return []

    proposals: List[Segment] = []
    max_window = min(args.dense_vertical_max_pts, len(points))
    for start in range(0, len(points) - args.dense_vertical_min_pts + 1):
        for count in range(args.dense_vertical_min_pts, max_window + 1):
            end = start + count - 1
            if end >= len(points):
                break

            seg = build_segment_from_points(
                points[start:end + 1],
                start,
                end,
                args.huber_delta,
                args.huber_iters,
                args=args,
            )
            if seg.length < args.dense_vertical_min_len_m or seg.length > args.dense_vertical_max_len_m:
                continue
            if abs(seg_dir(seg)[1]) < args.dense_vertical_abs_dir_y_min:
                continue
            if seg.rms > args.dense_vertical_rms_m:
                continue
            if seg.max_res > args.dense_vertical_max_res_m:
                continue
            if seg.straightness < args.dense_vertical_straightness_min:
                continue
            if segment_is_duplicate_like(seg, refs) or segment_is_duplicate_like(seg, proposals):
                continue

            seg.is_fragment = False
            seg.is_feature = True
            proposals.append(seg)

    proposals.sort(key=lambda s: (s.length, s.n_points, -s.rms), reverse=True)
    kept: List[Segment] = []
    for seg in proposals:
        if segment_is_duplicate_like(seg, kept):
            continue
        kept.append(seg)
        if len(kept) >= args.dense_vertical_max_segments:
            break
    return kept


def try_recover_fragment_chain(
    seg1: Segment,
    seg2: Segment,
    points: np.ndarray,
    angle_increment: float,
    args: argparse.Namespace,
) -> Optional[Segment]:
    if seg2.idx_start < seg1.idx_start:
        seg1, seg2 = seg2, seg1

    if seg1.idx_end >= seg2.idx_start:
        return None
    if seg2.idx_end - seg1.idx_start + 1 > args.frag_chain_max_span_pts:
        return None

    angle_deg = segment_included_angle_deg(seg1, seg2)
    if angle_deg > args.frag_chain_angle_deg:
        return None
    if segment_endpoint_to_endpoint_distance(seg1, seg2) > args.frag_chain_endpoint_gap_m:
        return None
    if segment_support_axis_distance(seg1, seg2) > args.frag_chain_support_gap_m:
        return None

    merged_points = points[seg1.idx_start:seg2.idx_end + 1]
    if len(merged_points) < args.frag_chain_min_pts:
        return None

    dif = np.linalg.norm(np.diff(merged_points, axis=0), axis=1) if len(merged_points) >= 2 else np.array([])
    if len(dif) == 0:
        return None

    r_med = median(np.linalg.norm(merged_points, axis=1))
    max_gap_allowed = args.frag_chain_gap_relax * gap_thr_m(r_med, angle_increment, args.gap0_m, args.cgap)
    if float(np.max(dif)) > max_gap_allowed:
        return None

    merged = build_segment_from_points(
        merged_points,
        seg1.idx_start,
        seg2.idx_end,
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    thr_rms = args.rms_a + args.rms_b * r_med
    thr_max = args.max_a + args.max_b * r_med
    straight_thr = max(args.frag_straightness_min, args.straightness_min - 0.01)

    if merged.length < args.frag_chain_min_len_m:
        return None
    if merged.rms > thr_rms * args.frag_chain_rms_relax:
        return None
    if merged.max_res > thr_max * args.frag_chain_max_relax:
        return None
    if merged.straightness < straight_thr:
        return None

    merged.is_feature = True
    merged.is_fragment = False
    merged.merged_from = [(seg1.idx_start, seg1.idx_end), (seg2.idx_start, seg2.idx_end)]
    return merged


def recover_fragment_chains(
    points: np.ndarray,
    candidates: List[Segment],
    features: List[Segment],
    angle_increment: float,
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.frag_chain_enable:
        return features

    fragment_pool = [
        seg
        for seg in candidates
        if seg.is_fragment and not seg.is_feature and seg.n_points >= args.frag_min_pts
    ]
    if len(fragment_pool) < 2:
        return features

    recovered = list(features)
    proposals: List[Segment] = []

    for i in range(len(fragment_pool)):
        for j in range(i + 1, len(fragment_pool)):
            proposal = try_recover_fragment_chain(fragment_pool[i], fragment_pool[j], points, angle_increment, args)
            if proposal is None:
                continue
            if segment_is_duplicate_like(proposal, recovered) or segment_is_duplicate_like(proposal, proposals):
                continue
            proposals.append(proposal)

    proposals.sort(key=lambda s: (-s.length, -s.straightness, s.rms, -s.n_points))
    for proposal in proposals:
        if segment_is_duplicate_like(proposal, recovered):
            continue
        recovered.append(proposal)

    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def attach_collinear_fragments_to_features(
    candidates: List[Segment],
    features: List[Segment],
    args: argparse.Namespace,
) -> List[Segment]:
    if not args.global_map_merge_enable or not features:
        return features

    fragment_pool = [
        seg
        for seg in candidates
        if seg.is_fragment
        and not seg.is_feature
        and seg.n_points >= args.frag_min_pts
        and seg.length >= max(args.frag_min_len_m, 0.05)
    ]
    if not fragment_pool:
        return features

    recovered = list(features)
    changed = True
    while changed:
        changed = False
        best_feature_idx = -1
        best_fragment_idx = -1
        best_attempt: Optional[Tuple[Segment, float, float]] = None
        best_score: Optional[Tuple[float, float, float, float, float]] = None

        for feat_idx, feat in enumerate(recovered):
            for frag_idx, frag in enumerate(fragment_pool):
                attempt = try_global_merge_two_segments(feat, frag, args)
                if attempt is None:
                    continue

                merged, gap_m, angle_deg = attempt
                length_gain = merged.length - feat.length
                if length_gain < max(0.05, 0.35 * frag.length):
                    continue

                score = (
                    length_gain,
                    -gap_m,
                    -angle_deg,
                    merged.straightness,
                    -merged.rms,
                )
                if best_score is None or score > best_score:
                    best_feature_idx = feat_idx
                    best_fragment_idx = frag_idx
                    best_attempt = attempt
                    best_score = score

        if best_attempt is None:
            break

        merged, _, _ = best_attempt
        recovered[best_feature_idx] = merged
        fragment_pool.pop(best_fragment_idx)
        changed = True

    recovered.sort(key=lambda s: (s.idx_start, s.idx_end))
    return recovered


def try_global_merge_two_segments(seg1: Segment, seg2: Segment, args: argparse.Namespace) -> Optional[Tuple[Segment, float, float]]:
    a1 = seg1.p1.copy()
    b1 = seg1.p2.copy()
    a2 = seg2.p1.copy()
    b2 = seg2.p2.copy()

    d1 = normalize(b1 - a1)
    d2 = normalize(b2 - a2)

    dot = float(d1 @ d2)
    if dot < 0.0:
        d2 = -d2
        a2, b2 = b2, a2
        dot = -dot

    dot = float(np.clip(dot, -1.0, 1.0))
    angle_deg = float(np.degrees(np.arccos(dot)))
    if angle_deg > args.global_map_merge_angle_deg:
        return None

    n1 = np.array([-d1[1], d1[0]], dtype=np.float64)
    perp_a2 = abs(float((a2 - a1) @ n1))
    perp_b2 = abs(float((b2 - a1) @ n1))
    perp_mid2 = abs(float((0.5 * (a2 + b2) - a1) @ n1))
    perp_err = max(perp_a2, perp_b2, perp_mid2)
    if perp_err > args.global_map_merge_perp_m:
        return None

    t1a = float(a1 @ d1)
    t1b = float(b1 @ d1)
    t2a = float(a2 @ d1)
    t2b = float(b2 @ d1)

    s1, e1 = min(t1a, t1b), max(t1a, t1b)
    s2, e2 = min(t2a, t2b), max(t2a, t2b)
    overlap = min(e1, e2) - max(s1, s2)
    gap_m = 0.0 if overlap >= -args.global_map_merge_overlap_tol_m else -overlap
    if gap_m > args.global_map_merge_endpoint_gap_m:
        return None

    merge_pts = np.vstack([seg1.p1, seg1.p2, seg2.p1, seg2.p2])
    merged = build_segment_from_points(
        merge_pts,
        min(seg1.idx_start, seg2.idx_start),
        max(seg1.idx_end, seg2.idx_end),
        args.huber_delta,
        args.huber_iters,
        args=args,
    )
    merged.n_points = max(merged.n_points, seg1.n_points + seg2.n_points)
    merged.feature = max(seg1.feature, seg2.feature)
    merged.is_feature = merged.length >= args.global_map_merge_min_len_m
    merged.is_fragment = not merged.is_feature
    if merged.length < args.global_map_merge_min_len_m:
        return None

    merged_from = list(seg1.merged_from) if seg1.merged_from else [(seg1.idx_start, seg1.idx_end)]
    merged_from.extend(seg2.merged_from if seg2.merged_from else [(seg2.idx_start, seg2.idx_end)])
    merged.merged_from = sorted(set(merged_from))
    return merged, gap_m, angle_deg


def stitch_collinear_segments_global(segments: List[Segment], args: argparse.Namespace) -> List[Segment]:
    if not args.global_map_merge_enable or len(segments) <= 1:
        return segments

    segs = list(segments)
    for _ in range(max(1, args.global_map_merge_max_passes)):
        changed = False
        while True:
            best_i = -1
            best_j = -1
            best_result: Optional[Tuple[Segment, float, float]] = None

            for i in range(len(segs)):
                for j in range(i + 1, len(segs)):
                    attempt = try_global_merge_two_segments(segs[i], segs[j], args)
                    if attempt is None:
                        continue
                    merged, gap_m, angle_deg = attempt
                    if best_result is None:
                        best_i, best_j, best_result = i, j, attempt
                        continue

                    best_merged, best_gap, best_angle = best_result
                    better = (
                        gap_m < best_gap - 1e-9
                        or (abs(gap_m - best_gap) <= 1e-9 and angle_deg < best_angle - 1e-9)
                        or (
                            abs(gap_m - best_gap) <= 1e-9
                            and abs(angle_deg - best_angle) <= 1e-9
                            and merged.length > best_merged.length + 1e-9
                        )
                    )
                    if better:
                        best_i, best_j, best_result = i, j, attempt

            if best_result is None:
                break

            merged, _, _ = best_result
            if best_i > best_j:
                best_i, best_j = best_j, best_i
            segs.pop(best_j)
            segs.pop(best_i)
            segs.append(merged)
            changed = True

        if not changed:
            break
        segs = sort_segments_by_mid_angle(deduplicate_segments(segs))

    segs = sort_segments_by_mid_angle(deduplicate_segments(segs))
    return segs


def estimate_angle_increment(points: np.ndarray) -> float:
    bearings = np.unwrap(np.arctan2(points[:, 1], points[:, 0]))
    diffs = np.abs(np.diff(bearings))
    diffs = diffs[np.isfinite(diffs) & (diffs > 1e-6)]
    if len(diffs) == 0:
        return np.deg2rad(0.5)
    upper = float(np.percentile(diffs, 80))
    filtered = diffs[diffs <= max(upper, 1e-6)]
    if len(filtered) == 0:
        filtered = diffs
    return float(np.median(filtered))


def segment_fit_passes_final_quality(seg: Segment, args: argparse.Namespace) -> bool:
    return (
        seg.rms <= args.final_quality_rms_m
        and seg.max_res <= args.final_quality_max_res_m
        and seg.straightness >= args.final_quality_straightness_min
    )


def finalize_segments(segments: List[Segment], args: argparse.Namespace) -> List[Segment]:
    if args.final_quality_enable:
        segments = [seg for seg in segments if (
            seg.n_points >= max(args.min_pts, args.final_quality_min_points)
            and seg.length >= args.final_quality_min_len_m
            and segment_fit_passes_final_quality(seg, args)
        )]
        for seg in segments:
            seg.is_feature = True
            seg.is_fragment = False
    return sort_segments_by_mid_angle(deduplicate_segments(segments))


def extract_segments(points: np.ndarray, args: argparse.Namespace) -> Tuple[List[Segment], float]:
    angle_increment = float(args.angle_increment) if args.angle_increment is not None else estimate_angle_increment(points)
    points_for_extract = preprocess_points(points, angle_increment, args)
    candidates = extract_all_candidates(points_for_extract, angle_increment, args)

    if args.merge_enable:
        segments = merge_and_extend_candidates(points_for_extract, candidates, angle_increment, args)
    else:
        segments = []
        next_id = 1
        for seg in candidates:
            if seg.is_feature:
                seg.id = next_id
                next_id += 1
            segments.append(seg)
        segments.sort(key=lambda s: (s.idx_start, s.idx_end))

    segments = recover_salient_fragments(candidates, segments, args)
    segments = recover_fragment_chains(points_for_extract, candidates, segments, angle_increment, args)
    segments = attach_collinear_fragments_to_features(candidates, segments, args)
    if args.final_quality_enable:
        # Corner branches are initially labelled as fragments. Preserve those
        # that independently satisfy final acceptance before a shorter, cleaner
        # overlapping fragment can suppress them during deduplication.
        segments = finalize_segments(list(segments) + list(candidates), args)
    segments = sort_segments_by_mid_angle(segments)
    segments = deduplicate_segments(segments)
    segments = sort_segments_by_mid_angle(segments)
    segments = stitch_collinear_segments_global(segments, args)
    if full_feature_refine_enabled(args):
        segments = [
            extend_high_quality_segment_support(points_for_extract, seg, angle_increment, args)
            for seg in segments
        ]
        segments = sort_segments_by_mid_angle(deduplicate_segments(segments))
    # The final acceptance gate also applies to a single scan without layout
    # metadata; previously that branch returned short/low-quality fragments.
    return finalize_segments(segments, args), angle_increment


def extract_segments_from_input_layout(
    points: np.ndarray,
    input_path: Path,
    args: argparse.Namespace,
) -> Tuple[List[Segment], float, bool]:
    frame_layouts = load_frame_layouts(input_path)
    return extract_segments_from_layout(points, frame_layouts, args)


def extract_segments_from_layout(
    points: np.ndarray,
    frame_layouts: Sequence[dict],
    args: argparse.Namespace,
) -> Tuple[List[Segment], float, bool]:
    """Process already loaded frame metadata without performing file I/O."""
    if not frame_layouts:
        segments, angle_increment = extract_segments(points, args)
        return segments, angle_increment, False

    all_segments: List[Segment] = []
    angle_values: List[float] = []

    for frame in frame_layouts:
        start = int(frame["point_start"])
        count = int(frame["point_count"])
        end = start + count
        if start < 0 or end > len(points):
            continue

        global_frame_points = points[start:end]
        local_frame_points = (
            global_frame_points
            - frame["layout_offset"][None, :]
            + frame["source_center"][None, :]
        )
        if len(local_frame_points) < 2:
            continue

        frame_args = argparse.Namespace(**vars(args))
        if frame["angle_increment_rad"] is not None:
            frame_args.angle_increment = float(frame["angle_increment_rad"])

        frame_segments, angle_increment = extract_segments(local_frame_points, frame_args)
        angle_values.append(float(angle_increment))
        local_refs = [
            seg for seg in frame_segments
            if (
                seg.n_points >= frame_args.min_pts
                and seg.length >= frame_args.final_quality_min_len_m
                and seg.rms <= frame_args.final_quality_rms_m
                and seg.max_res <= frame_args.final_quality_max_res_m
                and seg.straightness >= frame_args.final_quality_straightness_min
            )
        ]
        local_candidates = extract_all_candidates(local_frame_points, angle_increment, frame_args)
        corner_recovered = recover_collinear_corner_fragments(
            local_frame_points,
            local_candidates,
            local_refs,
            frame_args,
        )
        dense_vertical_recovered = recover_dense_vertical_runs(
            local_frame_points,
            list(local_refs) + corner_recovered,
            frame_args,
        )
        frame_segments = list(frame_segments) + corner_recovered + dense_vertical_recovered

        for seg in frame_segments:
            mapped = replace(seg)
            mapped.p1 = seg.p1 - frame["source_center"] + frame["layout_offset"]
            mapped.p2 = seg.p2 - frame["source_center"] + frame["layout_offset"]
            mapped.idx_start = seg.idx_start + start
            mapped.idx_end = seg.idx_end + start
            mapped.merged_from = [
                (int(s) + start, int(e) + start)
                for s, e in seg.merged_from
            ]
            all_segments.append(mapped)

    all_segments = finalize_segments(all_segments, args)
    if angle_values:
        return all_segments, median(angle_values), True

    segments, angle_increment = extract_segments(points, args)
    return segments, angle_increment, False


def plot_segments(
    points: np.ndarray,
    segments: Sequence[Segment],
    out_path: Path,
    show_segments: bool,
    title: str,
    bottom_label: str = "",
) -> None:
    fig, ax = plt.subplots(figsize=(16.8, 9.8), dpi=720)
    point_size = 148.0 if len(points) <= 220 else 112.0
    line_width = 7.2 if show_segments else 0.0
    segment_color = "#d26900"
    ax.set_facecolor("#ffffff")
    ax.scatter(
        points[:, 0],
        points[:, 1],
        s=point_size,
        c="#0b1f5b",
        edgecolors="#111827",
        linewidths=1.55,
        alpha=0.98,
        label="Raw points",
        zorder=1,
        antialiased=True,
    )

    if show_segments:
        drawn = False
        for seg in segments:
            ax.plot(
                [seg.p1[0], seg.p2[0]],
                [seg.p1[1], seg.p2[1]],
                color=segment_color,
                linewidth=line_width,
                alpha=0.98,
                solid_capstyle="round",
                label="Extracted segments" if not drawn else None,
                zorder=3,
                antialiased=True,
            )
            ax.scatter(
                [seg.p1[0], seg.p2[0]],
                [seg.p1[1], seg.p2[1]],
                s=90.0,
                c=segment_color,
                edgecolors="#111827",
                linewidths=1.10,
                zorder=4,
            )
            drawn = True

    ax.set_xlabel("X (m)", fontsize=24, labelpad=10)
    ax.set_ylabel("Y (m)", fontsize=24, labelpad=10)
    if title:
        ax.set_title(title, fontsize=34, pad=18)
    ax.set_aspect("equal")
    ax.grid(True, linestyle="--", linewidth=0.8, alpha=0.36, zorder=0)
    ax.tick_params(axis="both", which="major", width=1.1, length=6, labelsize=20)
    for spine in ax.spines.values():
        spine.set_linewidth(1.1)

    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    y_min, y_max = np.min(points[:, 1]), np.max(points[:, 1])
    x_span = max(x_max - x_min, 1e-6)
    y_span = max(y_max - y_min, 1e-6)
    ax.set_xlim(x_min - 0.03 * x_span, x_max + 0.18 * x_span)
    ax.set_ylim(y_min - 0.05 * y_span, y_max + 0.05 * y_span)

    ax.legend(
        loc="lower right",
        bbox_to_anchor=(0.985, 0.06),
        borderaxespad=0.0,
        frameon=True,
        framealpha=0.94,
        edgecolor="#d0d0d0",
        fontsize=24,
        markerscale=1.45,
        borderpad=0.56,
        labelspacing=0.52,
        handlelength=2.45,
        handletextpad=0.72,
    )

    if bottom_label:
        fig.text(0.5, 0.025, bottom_label, ha="center", va="bottom", fontsize=34)

    fig.subplots_adjust(
        left=0.08,
        right=0.97,
        bottom=0.18 if bottom_label else 0.12,
        top=0.96 if not title else 0.90,
    )
    plt.savefig(out_path, dpi=720, bbox_inches="tight", pad_inches=0.03)
    plt.close()


def summary_metrics(segments: Sequence[Segment]) -> Tuple[float, float, float]:
    if not segments:
        return float("nan"), float("nan"), float("nan")
    weights = np.array([max(1, seg.n_points) for seg in segments], dtype=np.float64)
    total_w = float(np.sum(weights))
    weighted_rms = float(np.sum(np.array([seg.rms for seg in segments]) * weights) / max(total_w, 1.0))
    max_res = float(np.max([seg.max_res for seg in segments]))
    weighted_straightness = float(np.sum(np.array([seg.straightness for seg in segments]) * weights) / max(total_w, 1.0))
    return weighted_rms, max_res, weighted_straightness


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Feature extraction aligned with lidar_line_feature_node.cpp")
    p.add_argument("--input", default="map_points.json", help="Input point cloud JSON")
    p.add_argument("--output-png", default="feature.png", help="Output visualization image")
    p.add_argument("--angle-increment", type=float, default=None, help="Laser angle increment in radians; if omitted, estimate from ordered points")

    p.add_argument("--min-pts", type=int, default=8)
    p.add_argument("--min-len-m", type=float, default=0.20)
    p.add_argument("--preclean-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--preclean-passes", type=int, default=2)
    p.add_argument("--preclean-window", type=int, default=2)
    p.add_argument("--preclean-isolated-gap-scale", type=float, default=2.8)
    p.add_argument("--preclean-gap-scale", type=float, default=1.55)
    p.add_argument("--preclean-run-gap-scale", type=float, default=1.45)
    p.add_argument("--preclean-residual-scale", type=float, default=1.85)
    p.add_argument("--preclean-residual-abs-m", type=float, default=0.028)
    p.add_argument("--preclean-radial-scale", type=float, default=2.40)
    p.add_argument("--preclean-radial-abs-m", type=float, default=0.06)
    p.add_argument("--preclean-small-run-max-pts", type=int, default=4)
    p.add_argument("--preclean-small-run-max-len-m", type=float, default=0.06)
    p.add_argument("--preclean-small-run-straightness", type=float, default=0.90)
    p.add_argument("--adaptive-min-len-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--adaptive-min-len-ref-range-m", type=float, default=2.0)
    p.add_argument("--adaptive-min-len-dist-exp", type=float, default=0.45)
    p.add_argument("--adaptive-min-len-noise-gain", type=float, default=0.05)
    p.add_argument("--adaptive-min-len-scale-min", type=float, default=0.65)
    p.add_argument("--adaptive-min-len-scale-max", type=float, default=1.45)

    p.add_argument("--frag-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--frag-min-pts", type=int, default=4)
    p.add_argument("--frag-min-len-m", type=float, default=0.03)
    p.add_argument("--frag-straightness-min", type=float, default=0.985)
    p.add_argument("--frag-rms-scale", type=float, default=0.02)
    p.add_argument("--frag-chain-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--frag-chain-angle-deg", type=float, default=8.0)
    p.add_argument("--frag-chain-endpoint-gap-m", type=float, default=0.16)
    p.add_argument("--frag-chain-support-gap-m", type=float, default=0.05)
    p.add_argument("--frag-chain-max-span-pts", type=int, default=16)
    p.add_argument("--frag-chain-min-pts", type=int, default=8)
    p.add_argument("--frag-chain-min-len-m", type=float, default=0.15)
    p.add_argument("--frag-chain-gap-relax", type=float, default=2.10)
    p.add_argument("--frag-chain-rms-relax", type=float, default=1.60)
    p.add_argument("--frag-chain-max-relax", type=float, default=1.60)
    p.add_argument(
        "--corner-branch-left-lookback-extra",
        type=int,
        default=14,
        help="Extra points to search backward when splitting a left horizontal branch from a near-vertical segment",
    )

    p.add_argument("--gap0-m", type=float, default=0.01)
    p.add_argument("--cgap", type=float, default=4.0)
    p.add_argument("--cmean", type=float, default=2.5)

    p.add_argument("--merge-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--merge-angle-deg", type=float, default=8.0)
    p.add_argument("--merge-max-index-gap", type=int, default=50)
    p.add_argument("--merge-perp-base-m", type=float, default=0.03)
    p.add_argument("--merge-perp-cr", type=float, default=0.005)
    p.add_argument("--merge-gap0-m", type=float, default=0.10)
    p.add_argument("--merge-cgap", type=float, default=10.0)
    p.add_argument("--merge-min-pts", type=int, default=6)
    p.add_argument("--adaptive-merge-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--adaptive-merge-ref-range-m", type=float, default=2.0)
    p.add_argument("--adaptive-merge-noise-gain", type=float, default=0.25)
    p.add_argument("--adaptive-merge-dist-gain", type=float, default=0.12)
    p.add_argument("--adaptive-merge-scale-min", type=float, default=0.90)
    p.add_argument("--adaptive-merge-scale-max", type=float, default=1.70)

    p.add_argument("--huber-delta", type=float, default=0.02)
    p.add_argument("--huber-iters", type=int, default=6)

    p.add_argument("--rms-a", type=float, default=0.01)
    p.add_argument("--rms-b", type=float, default=0.003)
    p.add_argument("--max-a", type=float, default=0.03)
    p.add_argument("--max-b", type=float, default=0.006)
    p.add_argument("--straightness-min", type=float, default=0.97)
    p.add_argument("--grow-rms-relax", type=float, default=1.20)
    p.add_argument("--grow-max-relax", type=float, default=1.20)
    p.add_argument("--grow-straightness-relax", type=float, default=0.03)
    p.add_argument("--merge-relax-factor", type=float, default=1.25)

    p.add_argument("--global-map-merge-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--global-map-merge-angle-deg", type=float, default=6.0)
    p.add_argument("--global-map-merge-perp-m", type=float, default=0.05)
    p.add_argument("--global-map-merge-endpoint-gap-m", type=float, default=0.20)
    p.add_argument("--global-map-merge-overlap-tol-m", type=float, default=0.08)
    p.add_argument("--global-map-merge-min-len-m", type=float, default=0.20)
    p.add_argument("--global-map-merge-max-passes", type=int, default=4)

    p.add_argument("--final-quality-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--final-quality-min-points", type=int, default=12)
    p.add_argument("--final-quality-min-len-m", type=float, default=0.30)
    p.add_argument("--final-quality-rms-m", type=float, default=0.015)
    p.add_argument("--final-quality-max-res-m", type=float, default=0.045)
    p.add_argument("--final-quality-straightness-min", type=float, default=0.99)
    p.add_argument("--corner-fragment-recover-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--corner-fragment-seed-min-pts", type=int, default=5)
    p.add_argument("--corner-fragment-seed-min-len-m", type=float, default=0.25)
    p.add_argument("--corner-fragment-seed-straightness-min", type=float, default=0.985)
    p.add_argument("--corner-fragment-max-index-gap", type=int, default=18)
    p.add_argument("--corner-fragment-angle-deg", type=float, default=8.0)
    p.add_argument("--corner-fragment-endpoint-gap-m", type=float, default=0.34)
    p.add_argument("--corner-fragment-normal-offset-m", type=float, default=0.04)
    p.add_argument("--corner-fragment-context-pts", type=int, default=6)
    p.add_argument("--corner-fragment-collect-dist-m", type=float, default=0.055)
    p.add_argument("--corner-fragment-refine-dist-m", type=float, default=0.022)
    p.add_argument("--corner-fragment-projection-margin-m", type=float, default=0.45)
    p.add_argument("--corner-fragment-refine-iters", type=int, default=4)
    p.add_argument("--corner-fragment-min-len-m", type=float, default=1.0)
    p.add_argument("--corner-fragment-straightness-min", type=float, default=0.998)
    p.add_argument("--dense-vertical-recover-enable", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--dense-vertical-min-pts", type=int, default=8)
    p.add_argument("--dense-vertical-max-pts", type=int, default=18)
    p.add_argument("--dense-vertical-min-len-m", type=float, default=0.34)
    p.add_argument("--dense-vertical-max-len-m", type=float, default=0.80)
    p.add_argument("--dense-vertical-abs-dir-y-min", type=float, default=0.93)
    p.add_argument("--dense-vertical-rms-m", type=float, default=0.012)
    p.add_argument("--dense-vertical-max-res-m", type=float, default=0.020)
    p.add_argument("--dense-vertical-straightness-min", type=float, default=0.995)
    p.add_argument("--dense-vertical-max-segments", type=int, default=1)
    return p


def run_cli(args: argparse.Namespace) -> None:
    input_path = Path(args.input)
    if args.angle_increment is None:
        hinted_angle_increment = load_angle_increment_hint(input_path)
        if hinted_angle_increment is not None:
            args.angle_increment = hinted_angle_increment

    points = load_points(input_path)
    segments, angle_increment, used_frame_layout = extract_segments_from_input_layout(points, input_path, args)

    output_png_path = Path(args.output_png)
    points_png_path = output_png_path.with_name("points.png")

    plot_title = "UCG-LineFit Line Extraction result"
    points_title = "Original Point Cloud"
    plot_segments(points, segments, output_png_path, show_segments=True, title=plot_title)
    plot_segments(points, segments, points_png_path, show_segments=False, title=points_title)

    avg_rms, max_res, avg_straightness = summary_metrics(segments)

    print("Feature extraction completed")
    print(f"Number of points: {len(points)}")
    print(f"Number of segments: {len(segments)}")
    print(f"Angle increment used: {angle_increment:.8f} rad")
    print(f"Frame layout mode: {'enabled' if used_frame_layout else 'disabled'}")
    if segments:
        print("---- Segment metrics (sorted by midpoint angle) ----")
        for seg in segments:
            print(
                f"line_id={seg.id:02d}, angle={segment_mid_angle_deg(seg):7.2f} deg, "
                f"n={seg.n_points:4d}, length={seg.length:.4f} m, "
                f"RMS={seg.rms:.6f} m, max_res={seg.max_res:.6f} m, "
                f"straightness={seg.straightness:.6f}"
            )
        print("---- Summary metrics ----")
        print(f"Average point-to-line RMS error: {avg_rms:.6f} m")
        print(f"Maximum residual: {max_res:.6f} m")
        print(f"Average straightness: {avg_straightness:.6f}")
    else:
        print("No segments satisfied the thresholds. Please adjust the parameters and try again.")

    print(f"Visualization file: {output_png_path.resolve()}")
    print(f"Points-only visualization file: {points_png_path.resolve()}")


def main() -> None:
    args = build_parser().parse_args()
    run_cli(args)


if __name__ == "__main__":
    main()
