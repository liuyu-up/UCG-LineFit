#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gao et al. (2018) seeded region growing for ordered laser-scan JSON.

Run: python srg.py --input inter.json --output-png srg.png --output-svg srg.svg
Dependencies: numpy, matplotlib (no ROS or SciPy required).
Input: {"points": [{"x": 1.0, "y": 2.0}, ...]} in original scan order.

Source: https://github.com/NKU-MobFly-Robotics/laser-line-segment
Pinned commit: 52308dc4cd2b74d5bb1e73ef044f2371d5fedfe4
Paper: H. Gao, X. Zhang, Y. Fang, J. Yuan, A line segment extraction
algorithm using laser data based on seeded region growing, IJARS 15(1),
2018. DOI: 10.1177/1729881418755245.

Port mapping from src/line_feature.cpp:
  leastsquare -> TLSFitter.fit (orthogonal least squares)
  detectline -> seed_is_valid (orthogonal + bearing prediction gates)
  detectfulline -> grow_seed (forward growth then backward growth)
  cleanline -> clean_overlaps (overlapping collinear merge + reassignment)
  generate -> build_segment (project first/last supporting measurements)

Adaptations, deliberately documented rather than claiming bitwise parity:
* Normal-vector TLS replaces slope algebra, avoiding axis-aligned singularities
  and the upstream horizontal-line fitting defect. Prefix sufficient statistics
  provide constant-cost refitting, with a direct centered-fit fallback.
* Boundary points are retained; inclusive point counts replace upstream off-by-
  one tests. The default 12 points matches the effective acceptance count of the
  launch file's min_line_points=10 (right-left > 10).
* Original point order is preserved. Bearings come from each Cartesian point
  relative to --sensor-x/--sensor-y (default origin), since JSON has no LaserScan
  angles. A metadata.frames layout (as used by inter.json) is handled one scan at
  a time in its local sensor coordinates, then mapped back to display coordinates.
  Without that metadata, the input must be one ordered scan with a common origin.
* No gap presegmentation, robust Huber fitting, graph recovery, or extra
  nonoverlapping line merging is added. As in upstream, the prediction gate
  is applied to SEEDS ONLY, not to growing points.
* The final length gate is rechecked after overlap processing; invalid/empty
  supports and nonfinite input are handled explicitly.
* Plot settings match feature_frame5_6_2.png; only the method name/letter in the
  bottom caption changes. PNG, SVG and PDF use the same drawing routine.
* Metrics report both baseline definitions because those two supplied files
  do not use the same definition of 'straightness' or average RMS.

Upstream license retained below (BSD 2-Clause):
Copyright (c) 2017, Haiming Gao
Institute of Robotics and Automatic Information System
Laboratory of Intelligent Robotics, Nankai University
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""

import argparse
import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime
from pathlib import Path
from time import perf_counter
from typing import List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

EPS = 1e-12
SOURCE_URL = "https://github.com/NKU-MobFly-Robotics/laser-line-segment"
SOURCE_COMMIT = "52308dc4cd2b74d5bb1e73ef044f2371d5fedfe4"

plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 11,
    "axes.labelsize": 12,
    "axes.titlesize": 14,
    "legend.fontsize": 10,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "svg.fonttype": "path",
    "pdf.fonttype": 42,
})


@dataclass
class Parameters:
    # Baseline geometric thresholds; minimum length is adjusted for this experiment.
    least_thresh: float = 0.04
    predict_distance: float = 0.15
    seed_line_points: int = 10
    min_line_points: int = 12
    min_line_length: float = 0.5
    # Upstream cleanline() uses a fixed angle of 0.1 radians.
    overlap_angle_rad: float = 0.10
    sensor_x: float = 0.0
    sensor_y: float = 0.0


@dataclass
class Line:
    left: int
    right: int
    mu: np.ndarray
    direction: np.ndarray
    normal: np.ndarray
    eigvals: np.ndarray


@dataclass
class FittedSegment:
    line_id: int
    point_indices: np.ndarray
    p0: np.ndarray
    p1: np.ndarray
    direction: np.ndarray
    centroid: np.ndarray
    rms: float
    max_residual: float
    straightness: float
    length: float
    angle: float
    relative_rms: float
    frame_id: Optional[int] = None


def load_points(path: Path) -> np.ndarray:
    with path.open("r", encoding="utf-8-sig") as f:
        data = json.load(f)
    if not isinstance(data, dict) or not isinstance(data.get("points"), list):
        raise ValueError('Expected {"points": [{"x": ..., "y": ...}, ...]}')
    try:
        arr = np.asarray([[float(p["x"]), float(p["y"])]
                          for p in data["points"]], dtype=np.float64)
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("Each point must contain numeric x and y") from exc
    if arr.ndim != 2 or arr.shape[1] != 2 or len(arr) < 2:
        raise ValueError("At least two points are required")
    if not np.isfinite(arr).all():
        raise ValueError("Coordinates must be finite; keep valid points in scan order")
    return arr


def load_frame_layouts(path: Path) -> List[dict]:
    """Read optional per-scan layout metadata from an arranged visualization set."""
    with path.open("r", encoding="utf-8-sig") as f:
        data = json.load(f)
    raw_frames = data.get("metadata", {}).get("frames", [])
    if not isinstance(raw_frames, list):
        return []

    layouts: List[dict] = []
    for item in raw_frames:
        if not isinstance(item, dict):
            continue
        try:
            start = int(item["point_start"])
            count = int(item["point_count"])
            source_center = np.array(
                [float(item["source_center"]["x"]), float(item["source_center"]["y"])],
                dtype=np.float64,
            )
            layout_offset = np.array(
                [float(item["layout_offset"]["x"]), float(item["layout_offset"]["y"])],
                dtype=np.float64,
            )
        except (KeyError, TypeError, ValueError):
            continue
        if start < 0 or count < 2:
            continue
        layouts.append({
            "frame_id": int(item.get("frame_id", len(layouts) + 1)),
            "point_start": start,
            "point_count": count,
            "source_center": source_center,
            "layout_offset": layout_offset,
        })
    return layouts


class TLSFitter:
    """Prefix moments implement the incremental OLS fits in the C++ source."""
    def __init__(self, points: np.ndarray):
        self.points = points
        self.reference = points.mean(axis=0)
        centered = points - self.reference
        x, y = centered.T
        moments = np.column_stack((x, y, x*x, y*y, x*y))
        self.prefix = np.vstack((np.zeros((1, 5)), np.cumsum(moments, axis=0)))

    def fit(self, left: int, right: int) -> Line:
        if not 0 <= left < right < len(self.points):
            raise ValueError("TLS support needs at least two in-bounds points")
        count = right - left + 1
        sx, sy, sxx, syy, sxy = self.prefix[right+1] - self.prefix[left]
        mean = np.array([sx, sy]) / count
        cov = np.array([[sxx, sxy], [sxy, syy]]) / count - np.outer(mean, mean)
        eigvals, eigvecs = np.linalg.eigh(cov)
        mu = mean + self.reference
        # Cancellation can occur in far-away tiny supports; recenter locally.
        scale = max(abs(sxx / count) + abs(syy / count), 1.0)
        if eigvals[0] < -1e-10*scale or eigvals[-1] < 1e-10*scale:
            sub = self.points[left:right+1]
            mu = sub.mean(axis=0)
            xc = sub - mu
            eigvals, eigvecs = np.linalg.eigh(xc.T @ xc / count)
        direction = eigvecs[:, -1]
        if direction[0] < 0 or (abs(direction[0]) < EPS and direction[1] < 0):
            direction = -direction
        normal = np.array([-direction[1], direction[0]])
        return Line(left, right, mu, direction, normal, np.maximum(eigvals, 0.0))


def seed_is_valid(points: np.ndarray, model: Line, params: Parameters) -> bool:
    if model.eigvals[-1] <= EPS:
        return False
    sub = points[model.left:model.right+1]
    if np.any(np.abs((sub - model.mu) @ model.normal) > params.least_thresh):
        return False
    origin = np.array([params.sensor_x, params.sensor_y])
    rays = sub - origin
    ranges = np.linalg.norm(rays, axis=1)
    if np.any(ranges <= EPS):
        return False
    unit_rays = rays / ranges[:, None]
    denominator = unit_rays @ model.normal
    if np.any(np.abs(denominator) <= EPS):
        return False
    predicted_range = float((model.mu-origin) @ model.normal) / denominator
    if np.any(predicted_range <= 0):
        return False
    # Same ray => Euclidean prediction error equals absolute range error.
    return bool(np.all(np.abs(predicted_range-ranges) <= params.predict_distance))


def grow_seed(points: np.ndarray, fitter: TLSFitter,
              model: Line, params: Parameters) -> Line:
    left, right = model.left, model.right
    # The bearing/prediction gate is intentionally NOT applied here.
    while right+1 < len(points):
        if abs(float((points[right+1]-model.mu) @ model.normal)) >= params.least_thresh:
            break
        right += 1
        model = fitter.fit(left, right)
    while left > 0:
        if abs(float((points[left-1]-model.mu) @ model.normal)) >= params.least_thresh:
            break
        left -= 1
        model = fitter.fit(left, right)
    return fitter.fit(left, right)


def clean_overlaps(points: np.ndarray, fitter: TLSFitter,
                   models: List[Line], params: Parameters) -> List[Line]:
    # First merge ONLY overlapping intervals with nearly parallel lines.
    models = list(models)
    p = 0
    while p < len(models)-1:
        q = p+1
        while q < len(models):
            first, second = models[p], models[q]
            if first.right >= second.left and second.right >= first.left:
                angle = np.arccos(np.clip(abs(first.direction @ second.direction), 0, 1))
                if angle < params.overlap_angle_rad:
                    models[p] = fitter.fit(min(first.left, second.left),
                                           max(first.right, second.right))
                    del models[q]
                    continue
            q += 1
        p += 1

    # Then split shared points at the first point preferring the second model.
    # Mirrors cleanline() rather than adding a new global assignment optimizer.
    p = 0
    while p+1 < len(models):
        first, second = models[p], models[p+1]
        if first.right < second.left:
            p += 1
            continue
        overlap_end = min(first.right, second.right)
        sub = points[second.left:overlap_end+1]
        e1 = np.abs((sub-first.mu) @ first.normal)
        e2 = np.abs((sub-second.mu) @ second.normal)
        preferred = np.flatnonzero(e1 > e2)
        boundary = second.left + int(preferred[0]) if len(preferred) else overlap_end+1
        if boundary-first.left < 2:
            del models[p]
            p = max(0, p-1)
            continue
        models[p] = fitter.fit(first.left, boundary-1)
        if second.right-boundary+1 < 2:
            del models[p+1]
            continue
        models[p+1] = fitter.fit(boundary, second.right)
        p += 1
    return models


def build_segment(points: np.ndarray, model: Line) -> FittedSegment:
    idx = np.arange(model.left, model.right+1, dtype=np.int64)
    res = (points[idx]-model.mu) @ model.normal
    # Project FIRST and LAST supporting points, matching upstream generate().
    endpoints = points[[model.left, model.right]]
    projected = model.mu + np.outer((endpoints-model.mu) @ model.direction,
                                   model.direction)
    p0, p1 = projected
    length = float(np.linalg.norm(p1-p0))
    rms = float(np.sqrt(np.mean(res*res)))
    centroid = (p0+p1)/2
    eigsum = float(model.eigvals.sum())
    straightness = 1-float(model.eigvals[0])/eigsum if eigsum > EPS else 0.0
    return FittedSegment(0, idx, p0, p1, model.direction, centroid, rms,
                         float(np.max(np.abs(res))), straightness, length,
                         float(np.mod(np.arctan2(centroid[1], centroid[0]), 2*np.pi)),
                         rms/length if length > EPS else 0.0)


def srg_segments(points: np.ndarray, params: Parameters) -> List[FittedSegment]:
    fitter = TLSFitter(points)
    candidates = []
    start = 0
    while start+params.seed_line_points <= len(points):
        model = fitter.fit(start, start+params.seed_line_points-1)
        if not seed_is_valid(points, model, params):
            start += 1
            continue
        grown = grow_seed(points, fitter, model, params)
        if grown.right-grown.left+1 >= params.min_line_points:
            if np.linalg.norm(points[grown.right]-points[grown.left]) >= params.min_line_length:
                candidates.append(grown)
            # Mirrors the original skip even when rejected only by length.
            start = grown.right+1
        else:
            start += 1
    models = clean_overlaps(points, fitter, candidates, params)
    segments = []
    for model in models:
        if model.right-model.left+1 < params.min_line_points:
            continue
        if np.linalg.norm(points[model.right]-points[model.left]) < params.min_line_length:
            continue
        seg = build_segment(points, model)
        if seg.length >= params.min_line_length:
            segments.append(seg)
    segments.sort(key=lambda s: (s.angle, np.linalg.norm(s.centroid)))
    for line_id, seg in enumerate(segments, 1):
        seg.line_id = line_id
    return segments


def srg_segments_from_input_layout(
    points: np.ndarray,
    input_path: Path,
    params: Parameters,
) -> Tuple[List[FittedSegment], bool, int]:
    """Extract each source scan locally when points were translated for display.

    SRG's prediction gate is defined relative to the laser origin. Running it on
    the concatenated display coordinates would therefore be geometrically wrong.
    """
    layouts = load_frame_layouts(input_path)
    if not layouts:
        return srg_segments(points, params), False, 1

    all_segments: List[FittedSegment] = []
    for frame in layouts:
        start = int(frame["point_start"])
        end = start + int(frame["point_count"])
        if end > len(points):
            raise ValueError(
                f"Frame {frame['frame_id']} point range [{start}, {end}) exceeds input size"
            )

        source_center = frame["source_center"]
        layout_offset = frame["layout_offset"]
        global_frame_points = points[start:end]
        local_frame_points = global_frame_points - layout_offset + source_center

        for segment in srg_segments(local_frame_points, params):
            mapped_centroid = segment.centroid - source_center + layout_offset
            mapped = replace(
                segment,
                point_indices=segment.point_indices + start,
                p0=segment.p0 - source_center + layout_offset,
                p1=segment.p1 - source_center + layout_offset,
                centroid=mapped_centroid,
                angle=float(np.mod(np.arctan2(mapped_centroid[1], mapped_centroid[0]), 2*np.pi)),
                frame_id=int(frame["frame_id"]),
            )
            all_segments.append(mapped)

    all_segments.sort(key=lambda s: (s.angle, np.linalg.norm(s.centroid)))
    for line_id, segment in enumerate(all_segments, 1):
        segment.line_id = line_id
    return all_segments, True, len(layouts)



def plot_segments(
    points: np.ndarray,
    segments: Sequence[FittedSegment],
    out_path: Path,
    show_segments: bool = True,
    caption: str = "(e) SRG Line Extraction Result",
) -> None:
    fig, ax = plt.subplots(figsize=(16.8, 9.8), dpi=720)
    point_size = 148.0 if len(points) <= 220 else 112.0
    line_width = 7.2 if show_segments else 0.0
    segment_color = "#ff8c00"
    ax.set_facecolor("#ffffff")

    ax.scatter(
        points[:, 0],
        points[:, 1],
        s=point_size,
        c="#0b1f5b",
        edgecolors="#111827",
        linewidths=1.55,
        alpha=0.98,
        label="Raw points",
        zorder=1,
        antialiased=True,
    )

    if show_segments:
        drawn = False
        for seg in segments:
            ax.plot(
                [seg.p0[0], seg.p1[0]],
                [seg.p0[1], seg.p1[1]],
                color=segment_color,
                linewidth=line_width,
                alpha=0.98,
                solid_capstyle="round",
                label="Extracted segments" if not drawn else None,
                zorder=3,
                antialiased=True,
            )
            ax.scatter(
                [seg.p0[0], seg.p1[0]],
                [seg.p0[1], seg.p1[1]],
                s=90.0,
                c=segment_color,
                edgecolors="#111827",
                linewidths=1.10,
                zorder=4,
                antialiased=True,
            )
            drawn = True

    ax.set_xlabel("X (m)", fontsize=24, labelpad=10)
    ax.set_ylabel("Y (m)", fontsize=24, labelpad=10)
    ax.set_aspect("equal")
    ax.grid(True, linestyle="--", linewidth=0.8, alpha=0.36, zorder=0)
    ax.tick_params(axis="both", which="major", width=1.1, length=6, labelsize=20)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.1)

    x_min, x_max = np.min(points[:, 0]), np.max(points[:, 0])
    y_min, y_max = np.min(points[:, 1]), np.max(points[:, 1])
    x_span = max(x_max - x_min, 1e-6)
    y_span = max(y_max - y_min, 1e-6)
    ax.set_xlim(x_min - 0.03 * x_span, x_max + 0.18 * x_span)
    ax.set_ylim(y_min - 0.05 * y_span, y_max + 0.05 * y_span)

    if caption:
        fig.text(0.5, 0.181, caption, ha="center", va="bottom", fontsize=34)

    fig.subplots_adjust(left=0.08, right=0.97, bottom=0.18, top=0.96)
    fig.canvas.draw()
    tight_bbox = fig.get_tightbbox(fig.canvas.get_renderer()).padded(0.03)
    # The reference image retains a 55 px top margin at 720 dpi.
    output_bbox = matplotlib.transforms.Bbox.from_extents(
        tight_bbox.x0,
        tight_bbox.y0,
        tight_bbox.x1,
        tight_bbox.y1 + 55.0 / 720.0,
    )
    fig.savefig(out_path, dpi=720, bbox_inches=output_bbox, pad_inches=0.0, facecolor="#ffffff")
    plt.close()


def summary_metrics(segments: Sequence[FittedSegment]) -> dict:
    """RANSAC uses point-weighted metrics; IEPF uses segment means and RMS/L."""
    if not segments:
        return {key: None for key in ("avg_rms", "max_residual", "avg_straightness",
                                     "mean_rms_iepf", "mean_straightness_iepf")}
    n = np.asarray([len(s.point_indices) for s in segments], dtype=float)
    rms = np.asarray([s.rms for s in segments])
    return {
        "avg_rms": float(np.sqrt(np.sum(n*rms*rms)/n.sum())),
        "max_residual": float(max(s.max_residual for s in segments)),
        "avg_straightness": float(np.average([s.straightness for s in segments], weights=n)),
        "mean_rms_iepf": float(rms.mean()),
        "mean_straightness_iepf": float(np.mean([s.relative_rms for s in segments])),
    }


def append_result_json(path: Path, input_file: str,
                       segments: Sequence[FittedSegment], summary: dict,
                       params: Parameters, elapsed_ms: float,
                       used_frame_layout: bool = False,
                       frame_count: int = 1) -> None:
    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "input_file": input_file,
        "method": "SRG (Gao et al., 2018), Python port with documented fixes",
        "source_url": SOURCE_URL,
        "source_commit": SOURCE_COMMIT,
        "parameters": asdict(params),
        "runtime_ms": elapsed_ms,
        "runtime_scope": "TLS setup + seed detection + growth + overlap + endpoint/metric construction",
        "frame_layout_mode": "per-frame local extraction" if used_frame_layout else "single ordered scan",
        "frame_count": frame_count,
        "num_segments": len(segments),
        "summary": summary,
        "metric_definitions": {
            "avg_rms": "sqrt(sum(n_i * rms_i^2) / sum(n_i)); RANSAC definition",
            "max_residual": "maximum absolute point-to-infinite-line distance (m)",
            "avg_straightness": "point-weighted 1-lambda_min/(lambda_min+lambda_max); RANSAC definition",
            "mean_rms_iepf": "arithmetic mean of segment RMS (m); IEPF definition",
            "mean_straightness_iepf": "arithmetic mean of segment RMS/length; IEPF definition (smaller is better)",
        },
        "segments": [{
            "line_id": s.line_id,
            "frame_id": s.frame_id,
            "angle_deg": float(np.degrees(s.angle)),
            "centroid": {"x": float(s.centroid[0]), "y": float(s.centroid[1])},
            "p0": {"x": float(s.p0[0]), "y": float(s.p0[1])},
            "p1": {"x": float(s.p1[0]), "y": float(s.p1[1])},
            "length": s.length,
            "rms": s.rms,
            "max_residual": s.max_residual,
            "straightness": s.straightness,
            "relative_rms": s.relative_rms,
            "n_points": len(s.point_indices),
            "point_indices": s.point_indices.tolist(),
        } for s in segments],
    }
    if path.exists():
        with path.open("r", encoding="utf-8") as f:
            existing = json.load(f)
    else:
        existing = {"runs": []}
    if isinstance(existing, list):
        existing.append(record)
    elif isinstance(existing, dict):
        for key in ("runs", "history", "records", "frames"):
            if isinstance(existing.get(key), list):
                existing[key].append(record)
                break
        else:
            existing["runs"] = [record]
    else:
        raise ValueError("Existing result JSON must be an object or array")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(existing, f, ensure_ascii=False, indent=2, allow_nan=False)


# Defaults below are tuned on the 20-frame R2000 development set.
def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Gao 2018 SRG baseline for ordered map_points.json")
    p.add_argument("--input", default="map_points.json", help="Ordered Cartesian scan JSON (m)")
    p.add_argument("--output-png", "--output", dest="output_png", default="srg.png",
                   help="PNG preview path; styling matches feature_frame5_6_2.png")
    p.add_argument("--output-svg", default=None,
                   help="Optional SVG vector output using the identical drawing")
    p.add_argument("--output-pdf", default=None,
                   help="Optional PDF vector output using the identical drawing")
    p.add_argument("--output-json", default="srg.json", help="Append-mode segment/metrics JSON")
    p.add_argument("--points-png", default=None, help="Optional points-only PNG path")
    p.add_argument("--least-thresh", "--distance-threshold", dest="least_thresh", type=float,
                   default=0.04, help="Seed/growth orthogonal distance threshold (m)")
    p.add_argument("--predict-distance", type=float, default=0.15,
                   help="Seed-only beam intersection prediction error threshold (m)")
    p.add_argument("--seed-line-points", "--seed-points", dest="seed_line_points", type=int,
                   default=10, help="Consecutive seed window size")
    p.add_argument("--min-line-points", "--feature-min-points", dest="min_line_points", type=int,
                   default=12, help="Inclusive minimum support count (12 matches upstream launch acceptance)")
    p.add_argument("--min-line-length", "--min-length", "--feature-min-len",
                   dest="min_line_length", type=float, default=0.5,
                   help="Minimum segment length (m); default=0.5")
    p.add_argument("--overlap-angle-rad", type=float, default=0.10,
                   help="Merge angle for OVERLAPPING segments only (radians); upstream=0.10")
    p.add_argument("--sensor-x", type=float, default=0.0,
                   help="Sensor origin X (m), in each scan's local coordinates")
    p.add_argument("--sensor-y", type=float, default=0.0,
                   help="Sensor origin Y (m), in each scan's local coordinates")
    return p


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    params = Parameters(**{name: getattr(args, name) for name in Parameters.__dataclass_fields__})
    if params.seed_line_points < 2 or params.min_line_points < params.seed_line_points:
        parser.error("Require min-line-points >= seed-line-points >= 2")
    numeric = [params.least_thresh, params.predict_distance, params.min_line_length,
               params.overlap_angle_rad, params.sensor_x, params.sensor_y]
    if not np.isfinite(numeric).all():
        parser.error("Numeric parameters must be finite")
    if min(params.least_thresh, params.predict_distance, params.min_line_length) <= 0:
        parser.error("Distance thresholds and minimum length must be positive")
    if not 0 <= params.overlap_angle_rad <= np.pi/2:
        parser.error("overlap-angle-rad must be within [0, pi/2]")
    input_path = Path(args.input)
    outputs = [Path(args.output_png), Path(args.output_json)]
    if args.output_svg:
        outputs.append(Path(args.output_svg))
    if args.output_pdf:
        outputs.append(Path(args.output_pdf))
    if args.points_png:
        outputs.append(Path(args.points_png))
    all_paths = [input_path.resolve()] + [path.resolve() for path in outputs]
    if len(set(all_paths)) != len(all_paths):
        parser.error("Input and output paths must be distinct")
    try:
        points = load_points(input_path)
        started = perf_counter()
        segments, used_frame_layout, frame_count = srg_segments_from_input_layout(
            points, input_path, params
        )
        elapsed_ms = (perf_counter()-started)*1000
        summary = summary_metrics(segments)
        for path in outputs:
            path.parent.mkdir(parents=True, exist_ok=True)
        plot_segments(points, segments, Path(args.output_png))
        if args.output_svg:
            plot_segments(points, segments, Path(args.output_svg))
        if args.output_pdf:
            plot_segments(points, segments, Path(args.output_pdf))
        if args.points_png:
            plot_segments(
                points,
                segments,
                Path(args.points_png),
                show_segments=False,
                caption="(a) Original Point Cloud",
            )
        append_result_json(
            Path(args.output_json),
            args.input,
            segments,
            summary,
            params,
            elapsed_ms,
            used_frame_layout,
            frame_count,
        )
    except (OSError, ValueError, TypeError) as exc:
        parser.exit(1, f"SRG error: {exc}\n")

    print("SRG line fitting completed (Gao et al., 2018)")
    print(f"Number of points: {len(points)}")
    print(f"Number of segments: {len(segments)}")
    print(f"Frame layout mode: {'enabled' if used_frame_layout else 'disabled'} ({frame_count} frame(s))")
    print(f"Extraction runtime (excluding file I/O and plotting): {elapsed_ms:.3f} ms")
    if segments:
        print("---- Segment metrics (indexed counterclockwise from the origin) ----")
        for s in segments:
            print(f"line_id={s.line_id:02d}, angle={np.degrees(s.angle):7.2f} deg, "
                  f"n={len(s.point_indices):4d}, length={s.length:.4f} m, "
                  f"RMS={s.rms:.6f} m, max_res={s.max_residual:.6f} m, "
                  f"straightness={s.straightness:.6f}")
        print("---- RANSAC-compatible summary ----")
        print(f"Average point-to-line RMS error: {summary['avg_rms']:.6f} m")
        print(f"Maximum residual: {summary['max_residual']:.6f} m")
        print(f"Average straightness: {summary['avg_straightness']:.6f}")
        print("---- IEPF-compatible summary ----")
        print(f"Mean RMS error        : {summary['mean_rms_iepf']:.6f} m")
        print(f"Max residual error    : {summary['max_residual']:.6f} m")
        print(f"Mean straightness     : {summary['mean_straightness_iepf']:.6f} (RMS/length)")
    else:
        print("No segments satisfied the thresholds; JSON summary metrics are null.")
    print(f"Visualization file: {Path(args.output_png).resolve()}")
    if args.output_svg:
        print(f"SVG vector file: {Path(args.output_svg).resolve()}")
    if args.output_pdf:
        print(f"PDF vector file: {Path(args.output_pdf).resolve()}")
    if args.points_png:
        print(f"Points-only visualization file: {Path(args.points_png).resolve()}")
    print(f"Segment result file: {Path(args.output_json).resolve()}")


if __name__ == "__main__":
    main()
